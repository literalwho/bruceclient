package me.travis.wurstplus.event;

import me.travis.wurstplus.util.Wrapper;
import me.zero.alpine.type.Cancellable;

public class wurstplusEvent extends Cancellable {
   private wurstplusEvent.Era era;
   private final float partialTicks;

   public wurstplusEvent() {
      this.era = wurstplusEvent.Era.PRE;
      this.partialTicks = Wrapper.getMinecraft().func_184121_ak();
   }

   public wurstplusEvent.Era getEra() {
      return this.era;
   }

   public float getPartialTicks() {
      return this.partialTicks;
   }

   public static enum Era {
      PRE,
      PERI,
      POST;
   }
}
