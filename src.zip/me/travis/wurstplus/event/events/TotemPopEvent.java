package me.travis.wurstplus.event.events;

import me.travis.wurstplus.event.wurstplusEvent;
import net.minecraft.entity.Entity;

public class TotemPopEvent extends wurstplusEvent {
   private Entity entity;

   public TotemPopEvent(Entity entity) {
      this.entity = entity;
   }

   public Entity getEntity() {
      return this.entity;
   }
}
