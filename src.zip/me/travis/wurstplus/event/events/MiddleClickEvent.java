package me.travis.wurstplus.event.events;

import me.travis.wurstplus.event.wurstplusEvent;

public class MiddleClickEvent extends wurstplusEvent {
}
