package me.travis.wurstplus.event.events;

public class DisplaySizeChangedEvent {
}
