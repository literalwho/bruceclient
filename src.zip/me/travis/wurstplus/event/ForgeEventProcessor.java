package me.travis.wurstplus.event;

import me.travis.wurstplus.wurstplusMod;
import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.command.commands.PeekCommand;
import me.travis.wurstplus.event.events.DisplaySizeChangedEvent;
import me.travis.wurstplus.gui.UIRenderer;
import me.travis.wurstplus.gui.rgui.component.container.use.Frame;
import me.travis.wurstplus.gui.wurstplus.wurstplusGUI;
import me.travis.wurstplus.module.ModuleManager;
import me.travis.wurstplus.util.Wrapper;
import me.travis.wurstplus.util.wurstplusTessellator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.inventory.GuiShulkerBox;
import net.minecraft.entity.passive.AbstractHorse;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.client.event.PlayerSPPushOutOfBlocksEvent;
import net.minecraftforge.client.event.RenderBlockOverlayEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Post;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Pre;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent.Start;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent.LeftClickBlock;
import net.minecraftforge.event.world.ChunkEvent.Load;
import net.minecraftforge.event.world.ChunkEvent.Unload;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent.KeyInputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class ForgeEventProcessor {
   private int displayWidth;
   private int displayHeight;

   @SubscribeEvent
   public void onUpdate(LivingUpdateEvent event) {
      if (!event.isCanceled()) {
         if (Minecraft.func_71410_x().field_71443_c != this.displayWidth || Minecraft.func_71410_x().field_71440_d != this.displayHeight) {
            wurstplusMod.EVENT_BUS.post(new DisplaySizeChangedEvent());
            this.displayWidth = Minecraft.func_71410_x().field_71443_c;
            this.displayHeight = Minecraft.func_71410_x().field_71440_d;
            wurstplusMod.getInstance().getGuiManager().getChildren().stream().filter((component) -> {
               return component instanceof Frame;
            }).forEach((component) -> {
               wurstplusGUI.dock((Frame)component);
            });
         }

         if (PeekCommand.sb != null) {
            ScaledResolution scaledresolution = new ScaledResolution(Minecraft.func_71410_x());
            int i = scaledresolution.func_78326_a();
            int j = scaledresolution.func_78328_b();
            GuiShulkerBox gui = new GuiShulkerBox(Wrapper.getPlayer().field_71071_by, PeekCommand.sb);
            gui.func_146280_a(Wrapper.getMinecraft(), i, j);
            Minecraft.func_71410_x().func_147108_a(gui);
            PeekCommand.sb = null;
         }

      }
   }

   @SubscribeEvent
   public void onTick(ClientTickEvent event) {
      if (Wrapper.getPlayer() != null) {
         ModuleManager.onUpdate();
         wurstplusMod.getInstance().getGuiManager().callTick(wurstplusMod.getInstance().getGuiManager());
      }
   }

   @SubscribeEvent
   public void onWorldRender(RenderWorldLastEvent event) {
      if (!event.isCanceled()) {
         ModuleManager.onWorldRender(event);
      }
   }

   @SubscribeEvent
   public void onRenderPre(Pre event) {
      if (event.getType() == ElementType.BOSSINFO && ModuleManager.isModuleEnabled("BossStack")) {
         event.setCanceled(true);
      }

   }

   @SubscribeEvent
   public void onRender(Post event) {
      if (!event.isCanceled()) {
         ElementType target = ElementType.EXPERIENCE;
         if (!Wrapper.getPlayer().func_184812_l_() && Wrapper.getPlayer().func_184187_bx() instanceof AbstractHorse) {
            target = ElementType.HEALTHMOUNT;
         }

         if (event.getType() == target) {
            ModuleManager.onRender();
            GL11.glPushMatrix();
            UIRenderer.renderAndUpdateFrames();
            GL11.glPopMatrix();
            wurstplusTessellator.releaseGL();
         } else if (event.getType() == ElementType.BOSSINFO && ModuleManager.isModuleEnabled("BossStack")) {
         }

      }
   }

   @SubscribeEvent(
      priority = EventPriority.NORMAL,
      receiveCanceled = true
   )
   public void onKeyInput(KeyInputEvent event) {
      if (Keyboard.getEventKeyState()) {
         ModuleManager.onBind(Keyboard.getEventKey());
      }

   }

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public ClientChatEvent onChatSent(ClientChatEvent event) {
      if (event.getMessage().startsWith(Command.getCommandPrefix())) {
         event.setCanceled(true);

         try {
            Wrapper.getMinecraft().field_71456_v.func_146158_b().func_146239_a(event.getMessage());
            if (event.getMessage().length() > 1) {
               wurstplusMod.getInstance().commandManager.callCommand(event.getMessage().substring(Command.getCommandPrefix().length() - 1));
            } else {
               Command.sendChatMessage("Please enter a command.");
            }
         } catch (Exception var3) {
            var3.printStackTrace();
            Command.sendChatMessage("Error occured while running command! (" + var3.getMessage() + ")");
         }

         event.setMessage("");
      }

      return event;
   }

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public net.minecraftforge.client.event.RenderPlayerEvent.Pre onPlayerDrawn(net.minecraftforge.client.event.RenderPlayerEvent.Pre event) {
      wurstplusMod.EVENT_BUS.post(event);
      return event;
   }

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public net.minecraftforge.client.event.RenderPlayerEvent.Post onPlayerDrawn(net.minecraftforge.client.event.RenderPlayerEvent.Post event) {
      wurstplusMod.EVENT_BUS.post(event);
      return event;
   }

   @SubscribeEvent
   public void onChunkLoaded(Load event) {
      wurstplusMod.EVENT_BUS.post(event);
   }

   @SubscribeEvent
   public Unload onChunkLoaded(Unload event) {
      wurstplusMod.EVENT_BUS.post(event);
      return event;
   }

   @SubscribeEvent
   public InputUpdateEvent onInputUpdate(InputUpdateEvent event) {
      wurstplusMod.EVENT_BUS.post(event);
      return event;
   }

   @SubscribeEvent
   public Start onLivingEntityUseItemEventTick(Start entityUseItemEvent) {
      wurstplusMod.EVENT_BUS.post(entityUseItemEvent);
      return entityUseItemEvent;
   }

   @SubscribeEvent
   public LivingDamageEvent onLivingDamageEvent(LivingDamageEvent event) {
      wurstplusMod.EVENT_BUS.post(event);
      return event;
   }

   @SubscribeEvent
   public EntityJoinWorldEvent onEntityJoinWorldEvent(EntityJoinWorldEvent entityJoinWorldEvent) {
      wurstplusMod.EVENT_BUS.post(entityJoinWorldEvent);
      return entityJoinWorldEvent;
   }

   @SubscribeEvent
   public PlayerSPPushOutOfBlocksEvent onPlayerPush(PlayerSPPushOutOfBlocksEvent event) {
      wurstplusMod.EVENT_BUS.post(event);
      return event;
   }

   @SubscribeEvent
   public LeftClickBlock onLeftClickBlock(LeftClickBlock event) {
      wurstplusMod.EVENT_BUS.post(event);
      return event;
   }

   @SubscribeEvent
   public AttackEntityEvent onAttackEntity(AttackEntityEvent entityEvent) {
      wurstplusMod.EVENT_BUS.post(entityEvent);
      return entityEvent;
   }

   @SubscribeEvent
   public RenderBlockOverlayEvent onRenderBlockOverlay(RenderBlockOverlayEvent event) {
      wurstplusMod.EVENT_BUS.post(event);
      return event;
   }

   @SubscribeEvent
   public LivingDeathEvent kill(LivingDeathEvent event) {
      return event;
   }
}
