package me.travis.wurstplus.mixin.client;

import me.travis.wurstplus.module.ModuleManager;
import me.travis.wurstplus.util.ChatUtils;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({GuiNewChat.class})
public abstract class MixinGuiNewChat {
   @ModifyVariable(
      method = {"printChatMessageWithOptionalDeletion"},
      at = @At("HEAD")
   )
   private ITextComponent addTimestamp(ITextComponent componentIn) {
      if (ModuleManager.isModuleEnabled("ChatTimeStamps")) {
         TextComponentString newComponent = new TextComponentString(ChatUtils.getChatTimestamp());
         newComponent.func_150257_a(componentIn);
         return newComponent;
      } else {
         return componentIn;
      }
   }

   @Redirect(
      method = {"drawChat"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/GuiNewChat;drawRect(IIIII)V",
   ordinal = 0
)
   )
   private void overrideChatBackgroundColour(int left, int top, int right, int bottom, int color) {
      if (!ModuleManager.isModuleEnabled("RemoveChatBox")) {
         Gui.func_73734_a(left, top, right, bottom, color);
      }

   }
}
