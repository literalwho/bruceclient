package me.travis.wurstplus.mixin.client;

import java.util.UUID;
import javax.annotation.Nullable;
import me.travis.wurstplus.module.ModuleManager;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.util.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({AbstractClientPlayer.class})
public abstract class MixinAbstractClientPlayer {
   @Shadow
   @Nullable
   protected abstract NetworkPlayerInfo func_175155_b();

   @Inject(
      method = {"getLocationCape"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void getLocationCape(CallbackInfoReturnable callbackInfoReturnable) {
      if (ModuleManager.isModuleEnabled("Capes")) {
         NetworkPlayerInfo info = this.func_175155_b();
         UUID uuid = null;
         if (info != null) {
            uuid = this.func_175155_b().func_178845_a().getId();
         }

         callbackInfoReturnable.setReturnValue(new ResourceLocation("textures/cape.png"));
      } else {
         callbackInfoReturnable.setReturnValue(new ResourceLocation("textures/cape.png"));
      }

   }
}
