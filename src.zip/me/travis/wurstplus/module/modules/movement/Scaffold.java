package me.travis.wurstplus.module.modules.movement;

import java.util.function.Predicate;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.module.ModuleManager;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.travis.wurstplus.util.BlockInteractionHelper;
import me.travis.wurstplus.util.EntityUtil;
import me.travis.wurstplus.util.Wrapper;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.Block;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.BlockFalling;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.util.MovementInput;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

@Module.Info(
   name = "Scaffold",
   category = Module.Category.MOVEMENT
)
public class Scaffold extends Module {
   private Setting placeBlocks = this.register(Settings.b("Place Blocks", true));
   private Setting modeSetting;
   private Setting randomDelay;
   private Setting delayRange;
   private Setting ticks;
   private boolean shouldSlow;
   private static Scaffold INSTANCE;
   @EventHandler
   private Listener eventListener;

   public Scaffold() {
      this.modeSetting = this.register(Settings.enumBuilder(Scaffold.Mode.class).withName("Mode").withValue(Scaffold.Mode.LEGIT).build());
      this.randomDelay = this.register(Settings.booleanBuilder("Random Delay").withValue(false).withVisibility((v) -> {
         return ((Scaffold.Mode)this.modeSetting.getValue()).equals(Scaffold.Mode.LEGIT);
      }).build());
      this.delayRange = this.register(Settings.integerBuilder("Delay Range").withMinimum(0).withValue((int)6).withMaximum(10).withVisibility((v) -> {
         return ((Scaffold.Mode)this.modeSetting.getValue()).equals(Scaffold.Mode.LEGIT) && (Boolean)this.randomDelay.getValue();
      }).build());
      this.ticks = this.register(Settings.integerBuilder("Ticks").withMinimum(0).withMaximum(60).withValue((int)2).withVisibility((v) -> {
         return !((Scaffold.Mode)this.modeSetting.getValue()).equals(Scaffold.Mode.LEGIT);
      }).build());
      this.shouldSlow = false;
      this.eventListener = new Listener((event) -> {
         if (((Scaffold.Mode)this.modeSetting.getValue()).equals(Scaffold.Mode.LEGIT) && this.shouldSlow) {
            MovementInput var10000;
            if ((Boolean)this.randomDelay.getValue()) {
               var10000 = event.getMovementInput();
               var10000.field_78902_a *= 0.2F + this.getRandomInRange();
               var10000 = event.getMovementInput();
               var10000.field_192832_b *= 0.2F + this.getRandomInRange();
            } else {
               var10000 = event.getMovementInput();
               var10000.field_78902_a *= 0.2F;
               var10000 = event.getMovementInput();
               var10000.field_192832_b *= 0.2F;
            }
         }

      }, new Predicate[0]);
      INSTANCE = this;
   }

   public static boolean shouldScaffold() {
      return INSTANCE.isEnabled();
   }

   public void onUpdate() {
      if (mc.field_71439_g != null && !ModuleManager.isModuleEnabled("Freecam")) {
         this.shouldSlow = false;
         Vec3d vec3d = EntityUtil.getInterpolatedPos(mc.field_71439_g, (float)(Integer)this.ticks.getValue());
         if (((Scaffold.Mode)this.modeSetting.getValue()).equals(Scaffold.Mode.LEGIT)) {
            vec3d = EntityUtil.getInterpolatedPos(mc.field_71439_g, 0.0F);
         }

         BlockPos blockPos = (new BlockPos(vec3d)).func_177977_b();
         BlockPos belowBlockPos = blockPos.func_177977_b();
         BlockPos legitPos = new BlockPos(EntityUtil.getInterpolatedPos(mc.field_71439_g, 2.0F));
         if (((Scaffold.Mode)this.modeSetting.getValue()).equals(Scaffold.Mode.LEGIT) && Wrapper.getWorld().func_180495_p(legitPos.func_177977_b()).func_185904_a().func_76222_j() && mc.field_71439_g.field_70122_E) {
            this.shouldSlow = true;
            mc.field_71439_g.field_71158_b.field_78899_d = true;
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.START_SNEAKING));
         }

         if (Wrapper.getWorld().func_180495_p(blockPos).func_185904_a().func_76222_j()) {
            this.setSlotToBlocks(belowBlockPos);
            if (BlockInteractionHelper.checkForNeighbours(blockPos)) {
               if ((Boolean)this.placeBlocks.getValue()) {
                  BlockInteractionHelper.placeBlockScaffold(blockPos);
               }

               mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.STOP_SNEAKING));
               this.shouldSlow = false;
            }
         }
      }
   }

   private float getRandomInRange() {
      return 0.11F + (float)Math.random() * ((float)(Integer)this.delayRange.getValue() / 10.0F - 0.11F);
   }

   private void setSlotToBlocks(BlockPos belowBlockPos) {
      int newSlot = -1;

      int i;
      for(i = 0; i < 9; ++i) {
         ItemStack stack = Wrapper.getPlayer().field_71071_by.func_70301_a(i);
         if (stack != ItemStack.field_190927_a && stack.func_77973_b() instanceof ItemBlock) {
            Block block = ((ItemBlock)stack.func_77973_b()).func_179223_d();
            if (!BlockInteractionHelper.blackList.contains(block) && !(block instanceof BlockContainer) && Block.func_149634_a(stack.func_77973_b()).func_176223_P().func_185913_b() && (!(((ItemBlock)stack.func_77973_b()).func_179223_d() instanceof BlockFalling) || !Wrapper.getWorld().func_180495_p(belowBlockPos).func_185904_a().func_76222_j())) {
               newSlot = i;
               break;
            }
         }
      }

      i = 1;
      if (newSlot != -1) {
         i = Wrapper.getPlayer().field_71071_by.field_70461_c;
         Wrapper.getPlayer().field_71071_by.field_70461_c = newSlot;
      }

      Wrapper.getPlayer().field_71071_by.field_70461_c = i;
   }

   private static enum Mode {
      NEITHER,
      LEGIT;
   }
}
