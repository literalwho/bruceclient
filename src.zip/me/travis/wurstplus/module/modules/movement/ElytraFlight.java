package me.travis.wurstplus.module.modules.movement;

import java.util.Objects;
import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.util.math.MathHelper;

@Module.Info(
   name = "ElytraFlight",
   description = "Modifies elytras to fly at custom velocities and fall speeds",
   category = Module.Category.MOVEMENT
)
public class ElytraFlight extends Module {
   private Setting mode;
   private Setting defaultSetting;
   private Setting speedHighway;
   private Setting fallSpeed;
   private Setting fallSpeedHighway;
   private Setting upSpeedBoost;
   private Setting downSpeedBoost;

   public ElytraFlight() {
      this.mode = this.register(Settings.e("Mode", ElytraFlight.ElytraFlightMode.HIGHWAY));
      this.defaultSetting = this.register(Settings.b("Defaults", false));
      this.speedHighway = this.register(Settings.floatBuilder("Speed H").withValue((Number)1.8F).withVisibility((v) -> {
         return ((ElytraFlight.ElytraFlightMode)this.mode.getValue()).equals(ElytraFlight.ElytraFlightMode.HIGHWAY);
      }).build());
      this.fallSpeed = this.register(Settings.floatBuilder("Fall Speed").withValue((Number)-0.003F).withVisibility((v) -> {
         return !((ElytraFlight.ElytraFlightMode)this.mode.getValue()).equals(ElytraFlight.ElytraFlightMode.HIGHWAY);
      }).build());
      this.fallSpeedHighway = this.register(Settings.floatBuilder("Fall Speed H").withValue((Number)5.0000002E-5F).withVisibility((v) -> {
         return ((ElytraFlight.ElytraFlightMode)this.mode.getValue()).equals(ElytraFlight.ElytraFlightMode.HIGHWAY);
      }).build());
      this.upSpeedBoost = this.register(Settings.floatBuilder("Up Speed B").withValue((Number)0.08F).withVisibility((v) -> {
         return ((ElytraFlight.ElytraFlightMode)this.mode.getValue()).equals(ElytraFlight.ElytraFlightMode.BOOST);
      }).build());
      this.downSpeedBoost = this.register(Settings.floatBuilder("Down Speed B").withValue((Number)0.04F).withVisibility((v) -> {
         return ((ElytraFlight.ElytraFlightMode)this.mode.getValue()).equals(ElytraFlight.ElytraFlightMode.BOOST);
      }).build());
   }

   public void onUpdate() {
      if (mc.field_71439_g != null) {
         if ((Boolean)this.defaultSetting.getValue()) {
            this.speedHighway.setValue(1.8F);
            this.fallSpeed.setValue(-0.003F);
            this.fallSpeedHighway.setValue(5.0000002E-5F);
            this.upSpeedBoost.setValue(0.08F);
            this.downSpeedBoost.setValue(0.04F);
            this.defaultSetting.setValue(false);
            Command.sendChatMessage(this.getChatName() + " Set to defaults!");
            Command.sendChatMessage(this.getChatName() + " Close and reopen the " + this.getName() + " settings menu to see changes");
         }

         if (mc.field_71439_g.field_71075_bZ.field_75100_b) {
            if (((ElytraFlight.ElytraFlightMode)this.mode.getValue()).equals(ElytraFlight.ElytraFlightMode.HIGHWAY)) {
               mc.field_71439_g.func_70031_b(false);
               mc.field_71439_g.func_70016_h(0.0D, 0.0D, 0.0D);
               mc.field_71439_g.func_70107_b(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u - (double)(Float)this.fallSpeedHighway.getValue(), mc.field_71439_g.field_70161_v);
               mc.field_71439_g.field_71075_bZ.func_75092_a((Float)this.speedHighway.getValue());
            } else {
               mc.field_71439_g.func_70016_h(0.0D, 0.0D, 0.0D);
               mc.field_71439_g.field_71075_bZ.func_75092_a(0.915F);
               mc.field_71439_g.func_70107_b(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u - (double)(Float)this.fallSpeed.getValue(), mc.field_71439_g.field_70161_v);
            }
         }

         if (mc.field_71439_g.field_70122_E) {
            mc.field_71439_g.field_71075_bZ.field_75101_c = false;
         }

         if (mc.field_71439_g.func_184613_cA()) {
            switch((ElytraFlight.ElytraFlightMode)this.mode.getValue()) {
            case BOOST:
               if (mc.field_71439_g.func_70090_H()) {
                  ((NetHandlerPlayClient)Objects.requireNonNull(mc.func_147114_u())).func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.START_FALL_FLYING));
                  return;
               }

               EntityPlayerSP var10000;
               if (mc.field_71474_y.field_74314_A.func_151470_d()) {
                  var10000 = mc.field_71439_g;
                  var10000.field_70181_x += (double)(Float)this.upSpeedBoost.getValue();
               } else if (mc.field_71474_y.field_74311_E.func_151470_d()) {
                  var10000 = mc.field_71439_g;
                  var10000.field_70181_x -= (double)(Float)this.downSpeedBoost.getValue();
               }

               float yaw;
               if (mc.field_71474_y.field_74351_w.func_151470_d()) {
                  yaw = (float)Math.toRadians((double)mc.field_71439_g.field_70177_z);
                  var10000 = mc.field_71439_g;
                  var10000.field_70159_w -= (double)(MathHelper.func_76126_a(yaw) * 0.05F);
                  var10000 = mc.field_71439_g;
                  var10000.field_70179_y += (double)(MathHelper.func_76134_b(yaw) * 0.05F);
               } else if (mc.field_71474_y.field_74368_y.func_151470_d()) {
                  yaw = (float)Math.toRadians((double)mc.field_71439_g.field_70177_z);
                  var10000 = mc.field_71439_g;
                  var10000.field_70159_w += (double)(MathHelper.func_76126_a(yaw) * 0.05F);
                  var10000 = mc.field_71439_g;
                  var10000.field_70179_y -= (double)(MathHelper.func_76134_b(yaw) * 0.05F);
               }
               break;
            default:
               mc.field_71439_g.field_71075_bZ.func_75092_a(0.915F);
               mc.field_71439_g.field_71075_bZ.field_75100_b = true;
               if (mc.field_71439_g.field_71075_bZ.field_75098_d) {
                  return;
               }

               mc.field_71439_g.field_71075_bZ.field_75101_c = true;
            }

         }
      }
   }

   protected void onDisable() {
      mc.field_71439_g.field_71075_bZ.field_75100_b = false;
      mc.field_71439_g.field_71075_bZ.func_75092_a(0.05F);
      if (!mc.field_71439_g.field_71075_bZ.field_75098_d) {
         mc.field_71439_g.field_71075_bZ.field_75101_c = false;
      }
   }

   public static enum ElytraFlightMode {
      BOOST,
      FLY,
      HIGHWAY;
   }
}
