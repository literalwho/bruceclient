package me.travis.wurstplus.module.modules.chat;

import me.travis.wurstplus.module.Module;

@Module.Info(
   name = "RemoveChatBox",
   category = Module.Category.CHAT
)
public class RemoveChatBox extends Module {
}
