package me.travis.wurstplus.module.modules.chat;

import com.ibm.icu.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Iterator;
import java.util.Map;
import java.util.Queue;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.Predicate;
import me.travis.wurstplus.event.events.GuiScreenEvent;
import me.travis.wurstplus.event.events.PacketEvent;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.Block;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.init.Items;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketUpdateSign;
import net.minecraft.network.play.client.CPacketPlayerDigging.Action;
import net.minecraft.network.play.server.SPacketUseBed;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent.Finish;

@Module.Info(
   name = "Announcer",
   category = Module.Category.CHAT
)
public class Announcer extends Module {
   private static boolean isFirstRun = true;
   private static Queue messageQueue = new ConcurrentLinkedQueue();
   private static Map minedBlocks = new ConcurrentHashMap();
   private static Map placedBlocks = new ConcurrentHashMap();
   private static Map droppedItems = new ConcurrentHashMap();
   private static Map consumedItems = new ConcurrentHashMap();
   private static DecimalFormat df = new DecimalFormat();
   private static TimerTask timerTask;
   private static Timer timer;
   private static PacketEvent.Receive lastEventReceive;
   private static PacketEvent.Send lastEventSend;
   private static Finish lastLivingEntityUseFinishEvent;
   private static GuiScreenEvent.Displayed lastGuiScreenDisplayedEvent;
   private static String lastmessage = "";
   private static Vec3d thisTickPos;
   private static Vec3d lastTickPos;
   private static double distanceTraveled;
   private static float thisTickHealth;
   private static float lastTickHealth;
   private static float gainedHealth;
   private static float lostHealth;
   private Setting distance = this.register(Settings.b("Distance", true));
   private Setting mindistance = this.register(Settings.integerBuilder("Min Distance").withRange(1, 100).withValue((int)10).build());
   private Setting maxdistance = this.register(Settings.integerBuilder("Max Distance").withRange(100, 10000).withValue((int)150).build());
   private Setting blocks = this.register(Settings.b("Blocks", true));
   private Setting items = this.register(Settings.b("Items", true));
   private Setting playerheal = this.register(Settings.b("Player Heal", true));
   private Setting playerdamage = this.register(Settings.b("Player Damage", true));
   private Setting playerdeath = this.register(Settings.b("Death", true));
   private Setting greentext = this.register(Settings.b("Greentext", false));
   private Setting delay = this.register(Settings.integerBuilder("Send Delay").withRange(1, 20).withValue((int)2).build());
   private Setting queuesize = this.register(Settings.integerBuilder("Queue Size").withRange(1, 100).withValue((int)5).build());
   private Setting clearqueue = this.register(Settings.b("Clear Queue", false));
   private Setting distanceSet;
   private Setting mode;
   @EventHandler
   public Listener guiScreenEventDisplayedlistener;
   @EventHandler
   private Listener packetEventReceiveListener;
   @EventHandler
   private Listener packetEventSendListener;
   @EventHandler
   public Listener listener;

   public Announcer() {
      this.distanceSet = this.register(Settings.e("Unit of distance", Announcer.DistanceSetting.Feet));
      this.mode = this.register(Settings.e("Mode", Announcer.ChatSetting.Lata));
      this.guiScreenEventDisplayedlistener = new Listener((event) -> {
         if (!this.isDisabled() && mc.field_71439_g != null) {
            if (lastGuiScreenDisplayedEvent == null || !lastGuiScreenDisplayedEvent.equals(event)) {
               if ((Boolean)this.playerdeath.getValue() && event.getScreen() instanceof GuiGameOver) {
                  this.queueMessage("I appear to be not living");
               } else {
                  lastGuiScreenDisplayedEvent = event;
               }
            }
         }
      }, new Predicate[0]);
      this.packetEventReceiveListener = new Listener((event) -> {
         if (!this.isDisabled() && mc.field_71439_g != null) {
            if (lastEventReceive == null || !lastEventReceive.equals(event)) {
               if (event.getPacket() instanceof SPacketUseBed) {
                  this.queueMessage("Sleepy Time");
                  lastEventReceive = event;
               }
            }
         }
      }, new Predicate[0]);
      this.packetEventSendListener = new Listener((event) -> {
         if (!this.isDisabled() && mc.field_71439_g != null) {
            if (lastEventSend == null || !lastEventSend.equals(event)) {
               if (((Boolean)this.items.getValue() || (Boolean)this.blocks.getValue()) && event.getPacket() instanceof CPacketPlayerDigging) {
                  CPacketPlayerDigging p = (CPacketPlayerDigging)event.getPacket();
                  String name;
                  if ((Boolean)this.items.getValue() && mc.field_71439_g.func_184614_ca().func_77973_b() != Items.field_190931_a && (p.func_180762_c().equals(Action.DROP_ITEM) || p.func_180762_c().equals(Action.DROP_ALL_ITEMS))) {
                     name = mc.field_71439_g.field_71071_by.func_70448_g().func_82833_r();
                     if (droppedItems.containsKey(name)) {
                        droppedItems.put(name, (Integer)droppedItems.get(name) + 1);
                     } else {
                        droppedItems.put(name, 1);
                     }

                     lastEventSend = event;
                     return;
                  }

                  if ((Boolean)this.blocks.getValue() && p.func_180762_c().equals(Action.STOP_DESTROY_BLOCK)) {
                     name = mc.field_71441_e.func_180495_p(p.func_179715_a()).func_177230_c().func_149732_F();
                     if (minedBlocks.containsKey(name)) {
                        minedBlocks.put(name, (Integer)minedBlocks.get(name) + 1);
                     } else {
                        minedBlocks.put(name, 1);
                     }

                     lastEventSend = event;
                     return;
                  }
               } else {
                  if ((Boolean)this.items.getValue() && event.getPacket() instanceof CPacketUpdateSign) {
                     CPacketUpdateSign pxx = (CPacketUpdateSign)event.getPacket();
                     this.queueMessage("signs xd");
                     lastEventSend = event;
                     return;
                  }

                  if ((Boolean)this.blocks.getValue() && event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock) {
                     CPacketPlayerTryUseItemOnBlock px = (CPacketPlayerTryUseItemOnBlock)event.getPacket();
                     ItemStack itemStack = mc.field_71439_g.field_71071_by.func_70448_g();
                     if (itemStack.field_190928_g) {
                        lastEventSend = event;
                        return;
                     }

                     if (itemStack.func_77973_b() instanceof ItemBlock) {
                        String namex = mc.field_71439_g.field_71071_by.func_70448_g().func_82833_r();
                        if (placedBlocks.containsKey(namex)) {
                           placedBlocks.put(namex, (Integer)placedBlocks.get(namex) + 1);
                        } else {
                           placedBlocks.put(namex, 1);
                        }

                        lastEventSend = event;
                        return;
                     }
                  }
               }

            }
         }
      }, new Predicate[0]);
      this.listener = new Listener((event) -> {
         if (event.getEntity().equals(mc.field_71439_g) && event.getItem().func_77973_b() instanceof ItemFood) {
            String name = event.getItem().func_82833_r();
            if (consumedItems.containsKey(name)) {
               consumedItems.put(name, (Integer)consumedItems.get(name) + 1);
            } else {
               consumedItems.put(name, 1);
            }

            lastLivingEntityUseFinishEvent = event;
         }
      }, new Predicate[0]);
   }

   public void onEnable() {
      timer = new Timer();
      if (mc.field_71439_g == null) {
         this.disable();
      } else {
         df = new DecimalFormat("#.#");
         df.setRoundingMode(RoundingMode.CEILING);
         timerTask = new TimerTask() {
            public void run() {
               Announcer.this.sendMessageCycle();
            }
         };
         timer.schedule(timerTask, 0L, (long)((Integer)this.delay.getValue() * 1000));
      }
   }

   public void onDisable() {
      timer.cancel();
      timer.purge();
      messageQueue.clear();
   }

   public void onUpdate() {
      if (!this.isDisabled() && mc.field_71439_g != null) {
         if ((Boolean)this.clearqueue.getValue()) {
            this.clearqueue.setValue(false);
            messageQueue.clear();
         }

         this.getGameTickData();
      }
   }

   private void getGameTickData() {
      if ((Boolean)this.distance.getValue()) {
         lastTickPos = thisTickPos;
         thisTickPos = mc.field_71439_g.func_174791_d();
         distanceTraveled += thisTickPos.func_72438_d(lastTickPos);
      }

      if ((Boolean)this.playerheal.getValue() || (Boolean)this.playerdamage.getValue()) {
         lastTickHealth = thisTickHealth;
         thisTickHealth = mc.field_71439_g.func_110143_aJ() + mc.field_71439_g.func_110139_bj();
         float healthDiff = thisTickHealth - lastTickHealth;
         if (healthDiff < 0.0F) {
            lostHealth += healthDiff * -1.0F;
         } else {
            gainedHealth += healthDiff;
         }
      }

   }

   private void composeGameTickData() {
      if (isFirstRun) {
         isFirstRun = false;
         this.clearTickData();
      } else {
         if ((Boolean)this.distance.getValue() && distanceTraveled >= 1.0D) {
            if (distanceTraveled < (double)((Integer)this.delay.getValue() * (Integer)this.mindistance.getValue())) {
               return;
            }

            if (distanceTraveled > (double)((Integer)this.delay.getValue() * (Integer)this.maxdistance.getValue())) {
               distanceTraveled = 0.0D;
               return;
            }

            CharSequence sb = new StringBuilder();
            if (this.mode.getValue() == Announcer.ChatSetting.Lata) {
               ((StringBuilder)sb).append("lol i traveled  ");
            } else {
               ((StringBuilder)sb).append("i wanna kms l0l, traveled ");
            }

            if (this.distanceSet.getValue() == Announcer.DistanceSetting.Feet) {
               ((StringBuilder)sb).append(round(distanceTraveled * 3.2808D, 2));
               if ((double)((int)distanceTraveled) == 1.0D) {
                  ((StringBuilder)sb).append(" Foot :D");
               } else {
                  ((StringBuilder)sb).append(" Feet :D");
               }
            } else if (this.distanceSet.getValue() == Announcer.DistanceSetting.Yards) {
               ((StringBuilder)sb).append(round(distanceTraveled * 1.0936D, 2));
               if ((double)((int)distanceTraveled) == 1.0D) {
                  ((StringBuilder)sb).append(" Yard :D");
               } else {
                  ((StringBuilder)sb).append(" Yards :D");
               }
            } else if (this.distanceSet.getValue() == Announcer.DistanceSetting.Inches) {
               ((StringBuilder)sb).append(round(distanceTraveled * 39.37D, 2));
               if ((double)((int)distanceTraveled) == 1.0D) {
                  ((StringBuilder)sb).append(" Inch :D");
               } else {
                  ((StringBuilder)sb).append(" Inches :D");
               }
            } else {
               ((StringBuilder)sb).append(round(distanceTraveled, 2));
               if ((double)((int)distanceTraveled) == 1.0D) {
                  ((StringBuilder)sb).append(" Block :D");
               } else {
                  ((StringBuilder)sb).append(" Blocks :D");
               }
            }

            this.queueMessage(((StringBuilder)sb).toString());
            distanceTraveled = 0.0D;
         }

         String sb;
         if ((Boolean)this.playerdamage.getValue() && lostHealth != 0.0F) {
            sb = "Bruce Willis just lost " + df.format((double)lostHealth) + " bitches D:";
            this.queueMessage((String)sb);
            lostHealth = 0.0F;
         }

         if ((Boolean)this.playerheal.getValue() && gainedHealth != 0.0F) {
            sb = "Bruce Willis now has " + df.format((double)gainedHealth) + " more bitches :D";
            this.queueMessage((String)sb);
            gainedHealth = 0.0F;
         }

      }
   }

   private void composeEventData() {
      Iterator var1 = minedBlocks.entrySet().iterator();

      Entry kv;
      while(var1.hasNext()) {
         kv = (Entry)var1.next();
         this.queueMessage("We be mining " + kv.getValue() + " " + (String)kv.getKey() + " bitcoin out here");
         minedBlocks.remove(kv.getKey());
      }

      var1 = placedBlocks.entrySet().iterator();

      while(var1.hasNext()) {
         kv = (Entry)var1.next();
         this.queueMessage("Bruce placed " + kv.getValue() + " " + (String)kv.getKey() + " out here");
         placedBlocks.remove(kv.getKey());
      }

      var1 = droppedItems.entrySet().iterator();

      while(var1.hasNext()) {
         kv = (Entry)var1.next();
         this.queueMessage("I just dropped " + kv.getValue() + " " + (String)kv.getKey() + ", whoops!");
         droppedItems.remove(kv.getKey());
      }

      var1 = consumedItems.entrySet().iterator();

      while(var1.hasNext()) {
         kv = (Entry)var1.next();
         this.queueMessage("I just ate  " + kv.getValue() + " " + (String)kv.getKey() + ", would've wanted chicken nuggets but ok.");
         consumedItems.remove(kv.getKey());
      }

   }

   public void sendMessageCycle() {
      if (!this.isDisabled() && mc.field_71439_g != null) {
         this.composeGameTickData();
         this.composeEventData();
         Iterator iterator = messageQueue.iterator();
         if (iterator.hasNext()) {
            String message = (String)iterator.next();
            this.sendMessage(message);
            messageQueue.remove(message);
         }
      }
   }

   private void sendMessage(String s) {
      StringBuilder sb = new StringBuilder();
      if ((Boolean)this.greentext.getValue()) {
         sb.append("> ");
      }

      sb.append(s);
      mc.field_71439_g.field_71174_a.func_147297_a(new CPacketChatMessage(sb.toString().replaceAll("§", "")));
   }

   private void clearTickData() {
      Vec3d pos;
      lastTickPos = pos = mc.field_71439_g.func_174791_d();
      thisTickPos = pos;
      distanceTraveled = 0.0D;
      float health;
      lastTickHealth = health = mc.field_71439_g.func_110143_aJ() + mc.field_71439_g.func_110139_bj();
      thisTickHealth = health;
      lostHealth = 0.0F;
      gainedHealth = 0.0F;
   }

   private Block getBlock(BlockPos pos) {
      return mc.field_71441_e.func_180495_p(pos).func_177230_c();
   }

   private void queueMessage(String message) {
      if (messageQueue.size() <= (Integer)this.queuesize.getValue()) {
         messageQueue.add(message);
      }
   }

   public static double round(double unrounded, int precision) {
      BigDecimal bd = new BigDecimal(unrounded);
      BigDecimal rounded = bd.setScale(precision, 4);
      return rounded.doubleValue();
   }

   public static enum DistanceSetting {
      Feet,
      Meters,
      Yards,
      Inches;
   }

   public static enum ChatSetting {
      Lata,
      aha;
   }
}
