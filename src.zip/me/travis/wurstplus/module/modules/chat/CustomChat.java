package me.travis.wurstplus.module.modules.chat;

import java.util.function.Predicate;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.play.client.CPacketChatMessage;

@Module.Info(
   name = "CustomChat",
   category = Module.Category.CHAT
)
public class CustomChat extends Module {
   private Setting mode;
   private Setting commands;
   private Setting twoBMode;
   public String wurstplus_SUFFIX;
   @EventHandler
   public Listener listener;

   public CustomChat() {
      this.mode = this.register(Settings.e("Mode", CustomChat.ChatSetting.Wurst));
      this.commands = this.register(Settings.b("Commands", false));
      this.twoBMode = this.register(Settings.b("2B Mode", false));
      this.listener = new Listener((event) -> {
         if (this.mode.getValue() == CustomChat.ChatSetting.Wurst) {
            this.wurstplus_SUFFIX = (Boolean)this.twoBMode.getValue() ? " | bruce client mode" : " ⍖ ⒷⓇⓊⒸⒺ ⒸⓁⒾⒺⓃⓉ";
         }

         if (event.getPacket() instanceof CPacketChatMessage) {
            String s = ((CPacketChatMessage)event.getPacket()).func_149439_c();
            if (s.startsWith("/") && !(Boolean)this.commands.getValue()) {
               return;
            }

            s = s + this.wurstplus_SUFFIX;
            if (s.length() >= 256) {
               s = s.substring(0, 256);
            }

            ((CPacketChatMessage)event.getPacket()).field_149440_a = s;
         }

      }, new Predicate[0]);
   }

   public Boolean getCommand() {
      return (Boolean)this.commands.getValue();
   }

   public static enum ChatSetting {
      Wurst;
   }
}
