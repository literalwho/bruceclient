package me.travis.wurstplus.module.modules.chat;

import java.util.Iterator;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.travis.wurstplus.util.EntityUtil;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.client.CPacketUseEntity.Action;

@Module.Info(
   name = "AutoGG",
   category = Module.Category.CHAT
)
public class AutoGG extends Module {
   private ConcurrentHashMap targetedPlayers = null;
   private Setting toxicMode = this.register(Settings.b("ToxicMode", false));
   private Setting clientName = this.register(Settings.b("ClientName", true));
   private Setting timeoutTicks = this.register(Settings.i("TimeoutTicks", 20));
   @EventHandler
   public Listener sendListener = new Listener((event) -> {
      if (mc.field_71439_g != null) {
         if (this.targetedPlayers == null) {
            this.targetedPlayers = new ConcurrentHashMap();
         }

         if (event.getPacket() instanceof CPacketUseEntity) {
            CPacketUseEntity cPacketUseEntity = (CPacketUseEntity)event.getPacket();
            if (cPacketUseEntity.func_149565_c().equals(Action.ATTACK)) {
               Entity targetEntity = cPacketUseEntity.func_149564_a(mc.field_71441_e);
               if (EntityUtil.isPlayer(targetEntity)) {
                  this.addTargetedPlayer(targetEntity.func_70005_c_());
               }
            }
         }
      }
   }, new Predicate[0]);
   @EventHandler
   public Listener livingDeathEventListener = new Listener((event) -> {
      if (mc.field_71439_g != null) {
         if (this.targetedPlayers == null) {
            this.targetedPlayers = new ConcurrentHashMap();
         }

         EntityLivingBase entity = event.getEntityLiving();
         if (entity != null) {
            if (EntityUtil.isPlayer(entity)) {
               EntityPlayer player = (EntityPlayer)entity;
               if (player.func_110143_aJ() <= 0.0F) {
                  String name = player.func_70005_c_();
                  if (this.shouldAnnounce(name)) {
                     this.doAnnounce(name);
                  }

               }
            }
         }
      }
   }, new Predicate[0]);

   public void onEnable() {
      this.targetedPlayers = new ConcurrentHashMap();
   }

   public void onDisable() {
      this.targetedPlayers = null;
   }

   public void onUpdate() {
      if (!this.isDisabled() && mc.field_71439_g != null) {
         if (this.targetedPlayers == null) {
            this.targetedPlayers = new ConcurrentHashMap();
         }

         Iterator var1 = mc.field_71441_e.func_72910_y().iterator();

         while(var1.hasNext()) {
            Entity entity = (Entity)var1.next();
            if (EntityUtil.isPlayer(entity)) {
               EntityPlayer player = (EntityPlayer)entity;
               if (player.func_110143_aJ() <= 0.0F) {
                  String name = player.func_70005_c_();
                  if (this.shouldAnnounce(name)) {
                     this.doAnnounce(name);
                     break;
                  }
               }
            }
         }

         this.targetedPlayers.forEach((namex, timeout) -> {
            if (timeout <= 0) {
               this.targetedPlayers.remove(namex);
            } else {
               this.targetedPlayers.put(namex, timeout - 1);
            }

         });
      }
   }

   private boolean shouldAnnounce(String name) {
      return this.targetedPlayers.containsKey(name);
   }

   private void doAnnounce(String name) {
      this.targetedPlayers.remove(name);
      StringBuilder message = new StringBuilder();
      if ((Boolean)this.toxicMode.getValue()) {
         message.append("oo aa me 32k you... mad?");
      } else {
         message.append("this is sad... i just clowned you ");
      }

      message.append(name);
      message.append("!");
      if ((Boolean)this.clientName.getValue()) {
         message.append(" ");
         message.append("Bruce Client");
         message.append(" ");
      }

      String messageSanitized = message.toString().replaceAll("§", "");
      if (messageSanitized.length() > 255) {
         messageSanitized = messageSanitized.substring(0, 255);
      }

      mc.field_71439_g.field_71174_a.func_147297_a(new CPacketChatMessage(messageSanitized));
   }

   public void addTargetedPlayer(String name) {
      if (!Objects.equals(name, mc.field_71439_g.func_70005_c_())) {
         if (this.targetedPlayers == null) {
            this.targetedPlayers = new ConcurrentHashMap();
         }

         this.targetedPlayers.put(name, this.timeoutTicks.getValue());
      }
   }
}
