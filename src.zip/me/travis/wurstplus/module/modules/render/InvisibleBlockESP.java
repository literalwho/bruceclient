package me.travis.wurstplus.module.modules.render;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import me.travis.wurstplus.event.events.RenderEvent;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.travis.wurstplus.util.KamiTessellator;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;

@Module.Info(
   name = "InvisibleBlockESP",
   description = "Highlights invisible blocks such as string and barriers",
   category = Module.Category.RENDER
)
public class InvisibleBlockESP extends Module {
   private Setting rangeXZ = this.register(Settings.integerBuilder("Range XZ").withMinimum(1).withMaximum(25).withValue((int)15).build());
   private Setting rangeY = this.register(Settings.integerBuilder("Range Y").withMinimum(1).withMaximum(25).withValue((int)15).build());
   private Setting barrierSetting = this.register(Settings.b("Barrier", true));
   private Setting stringSetting = this.register(Settings.b("String", true));
   private List barriers = new ArrayList();
   private List string = new ArrayList();

   public void onUpdate() {
      this.barriers.clear();
      this.string.clear();
      Iterable blocks = BlockPos.func_177980_a(mc.field_71439_g.func_180425_c().func_177982_a(-(Integer)this.rangeXZ.getValue(), -(Integer)this.rangeY.getValue(), -(Integer)this.rangeXZ.getValue()), mc.field_71439_g.func_180425_c().func_177982_a((Integer)this.rangeXZ.getValue(), (Integer)this.rangeY.getValue(), (Integer)this.rangeXZ.getValue()));
      Iterator var2 = blocks.iterator();

      while(var2.hasNext()) {
         BlockPos pos = (BlockPos)var2.next();
         if ((Boolean)this.barrierSetting.getValue() && mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_180401_cv) {
            this.barriers.add(pos);
         }

         if ((Boolean)this.stringSetting.getValue() && mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150473_bD) {
            this.string.add(pos);
         }
      }

   }

   public void onWorldRender(RenderEvent event) {
      KamiTessellator.prepare(7);
      this.barriers.forEach((pos) -> {
         KamiTessellator.drawBox(pos, 587154487, 63);
      });
      this.string.forEach((pos) -> {
         KamiTessellator.drawHalfBox(pos, 582004988, 63);
      });
      KamiTessellator.release();
   }
}
