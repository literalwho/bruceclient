package me.travis.wurstplus.module.modules.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import me.travis.wurstplus.event.events.RenderEvent;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.travis.wurstplus.util.ColourHolder;
import me.travis.wurstplus.util.EntityUtil;
import me.travis.wurstplus.util.Friends;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

@Module.Info(
   name = "Nametags",
   description = "Draws descriptive nametags above entities",
   category = Module.Category.RENDER
)
public class Nametags extends Module {
   private Setting players = this.register(Settings.b("Players", true));
   private Setting animals = this.register(Settings.b("Animals", false));
   private Setting mobs = this.register(Settings.b("Mobs", false));
   private Setting range = this.register(Settings.d("Range", 200.0D));
   private Setting scale = this.register(Settings.floatBuilder("Scale").withMinimum(0.5F).withMaximum(10.0F).withValue((Number)2.5F).build());
   private Setting health = this.register(Settings.b("Health", true));
   private Setting armor = this.register(Settings.b("Armor", true));
   RenderItem itemRenderer;
   static final Minecraft mc = Minecraft.func_71410_x();

   public Nametags() {
      this.itemRenderer = mc.func_175599_af();
   }

   public void onWorldRender(RenderEvent event) {
      if (mc.func_175598_ae().field_78733_k != null) {
         GlStateManager.func_179098_w();
         GlStateManager.func_179140_f();
         GlStateManager.func_179097_i();
         Minecraft.func_71410_x().field_71441_e.field_72996_f.stream().filter(EntityUtil::isLiving).filter((entity) -> {
            return !EntityUtil.isFakeLocalPlayer(entity);
         }).filter((entity) -> {
            return entity instanceof EntityPlayer ? (Boolean)this.players.getValue() && mc.field_71439_g != entity : (EntityUtil.isPassive(entity) ? (Boolean)this.animals.getValue() : (Boolean)this.mobs.getValue());
         }).filter((entity) -> {
            return (double)mc.field_71439_g.func_70032_d(entity) < (Double)this.range.getValue();
         }).sorted(Comparator.comparing((entity) -> {
            return -mc.field_71439_g.func_70032_d(entity);
         })).forEach(this::drawNametag);
         GlStateManager.func_179090_x();
         RenderHelper.func_74518_a();
         GlStateManager.func_179145_e();
         GlStateManager.func_179126_j();
      }
   }

   private void drawNametag(Entity entityIn) {
      GlStateManager.func_179094_E();
      Vec3d interp = EntityUtil.getInterpolatedRenderPos(entityIn, mc.func_184121_ak());
      float yAdd = entityIn.field_70131_O + 0.5F - (entityIn.func_70093_af() ? 0.25F : 0.0F);
      double x = interp.field_72450_a;
      double y = interp.field_72448_b + (double)yAdd;
      double z = interp.field_72449_c;
      float viewerYaw = mc.func_175598_ae().field_78735_i;
      float viewerPitch = mc.func_175598_ae().field_78732_j;
      boolean isThirdPersonFrontal = mc.func_175598_ae().field_78733_k.field_74320_O == 2;
      GlStateManager.func_179137_b(x, y, z);
      GlStateManager.func_179114_b(-viewerYaw, 0.0F, 1.0F, 0.0F);
      GlStateManager.func_179114_b((float)(isThirdPersonFrontal ? -1 : 1) * viewerPitch, 1.0F, 0.0F, 0.0F);
      float f = mc.field_71439_g.func_70032_d(entityIn);
      float m = f / 8.0F * (float)Math.pow(1.258925437927246D, (double)(Float)this.scale.getValue());
      GlStateManager.func_179152_a(m, m, m);
      FontRenderer fontRendererIn = mc.field_71466_p;
      GlStateManager.func_179152_a(-0.025F, -0.025F, 0.025F);
      String str = entityIn.func_70005_c_() + ((Boolean)this.health.getValue() ? " §a" + Math.round(((EntityLivingBase)entityIn).func_110143_aJ() + (entityIn instanceof EntityPlayer ? ((EntityPlayer)entityIn).func_110139_bj() : 0.0F)) : "");
      int i = fontRendererIn.func_78256_a(str) / 2;
      GlStateManager.func_179147_l();
      GlStateManager.func_187428_a(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.func_179090_x();
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      GlStateManager.func_179097_i();
      GL11.glTranslatef(0.0F, -20.0F, 0.0F);
      bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b((double)(-i - 1), 8.0D, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.5F).func_181675_d();
      bufferbuilder.func_181662_b((double)(-i - 1), 19.0D, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.5F).func_181675_d();
      bufferbuilder.func_181662_b((double)(i + 1), 19.0D, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.5F).func_181675_d();
      bufferbuilder.func_181662_b((double)(i + 1), 8.0D, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.5F).func_181675_d();
      tessellator.func_78381_a();
      bufferbuilder.func_181668_a(2, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b((double)(-i - 1), 8.0D, 0.0D).func_181666_a(0.1F, 0.1F, 0.1F, 0.1F).func_181675_d();
      bufferbuilder.func_181662_b((double)(-i - 1), 19.0D, 0.0D).func_181666_a(0.1F, 0.1F, 0.1F, 0.1F).func_181675_d();
      bufferbuilder.func_181662_b((double)(i + 1), 19.0D, 0.0D).func_181666_a(0.1F, 0.1F, 0.1F, 0.1F).func_181675_d();
      bufferbuilder.func_181662_b((double)(i + 1), 8.0D, 0.0D).func_181666_a(0.1F, 0.1F, 0.1F, 0.1F).func_181675_d();
      tessellator.func_78381_a();
      GlStateManager.func_179098_w();
      GlStateManager.func_187432_a(0.0F, 1.0F, 0.0F);
      if (!entityIn.func_70093_af()) {
         fontRendererIn.func_78276_b(str, -i, 10, entityIn instanceof EntityPlayer ? (Friends.isFriend(entityIn.func_70005_c_()) ? '뿿' : 16777215) : 16777215);
      } else {
         fontRendererIn.func_78276_b(str, -i, 10, 16755200);
      }

      if (entityIn instanceof EntityPlayer && (Boolean)this.armor.getValue()) {
         this.renderArmor((EntityPlayer)entityIn, 0, -(fontRendererIn.field_78288_b + 1) - 20);
      }

      GlStateManager.func_187432_a(0.0F, 0.0F, 0.0F);
      GL11.glTranslatef(0.0F, 20.0F, 0.0F);
      GlStateManager.func_179152_a(-40.0F, -40.0F, 40.0F);
      GlStateManager.func_179126_j();
      GlStateManager.func_179121_F();
   }

   public void renderArmor(EntityPlayer player, int x, int y) {
      InventoryPlayer items = player.field_71071_by;
      ItemStack inHand = player.func_184614_ca();
      ItemStack boots = items.func_70440_f(0);
      ItemStack leggings = items.func_70440_f(1);
      ItemStack body = items.func_70440_f(2);
      ItemStack helm = items.func_70440_f(3);
      ItemStack offHand = player.func_184592_cb();
      ItemStack[] stuff = null;
      if (inHand != null && offHand != null) {
         stuff = new ItemStack[]{inHand, helm, body, leggings, boots, offHand};
      } else if (inHand != null && offHand == null) {
         stuff = new ItemStack[]{inHand, helm, body, leggings, boots};
      } else if (inHand == null && offHand != null) {
         stuff = new ItemStack[]{helm, body, leggings, boots, offHand};
      } else {
         stuff = new ItemStack[]{helm, body, leggings, boots};
      }

      List stacks = new ArrayList();
      ItemStack[] array = stuff;
      int length = stuff.length;

      int width;
      for(width = 0; width < length; ++width) {
         ItemStack i = array[width];
         if (i != null && i.func_77973_b() != null) {
            stacks.add(i);
         }
      }

      width = 16 * stacks.size() / 2;
      x -= width;
      GlStateManager.func_179097_i();

      for(Iterator var18 = stacks.iterator(); var18.hasNext(); x += 16) {
         ItemStack stack = (ItemStack)var18.next();
         this.renderItem(stack, x, y);
      }

      GlStateManager.func_179126_j();
   }

   public void renderItem(ItemStack stack, int x, int y) {
      FontRenderer fontRenderer = mc.field_71466_p;
      RenderItem renderItem = mc.func_175599_af();
      Nametags.EnchantEntry[] enchants = new Nametags.EnchantEntry[]{new Nametags.EnchantEntry(Enchantments.field_180310_c, "Pro"), new Nametags.EnchantEntry(Enchantments.field_92091_k, "Thr"), new Nametags.EnchantEntry(Enchantments.field_185302_k, "Sha"), new Nametags.EnchantEntry(Enchantments.field_77334_n, "Fia"), new Nametags.EnchantEntry(Enchantments.field_180313_o, "Knb"), new Nametags.EnchantEntry(Enchantments.field_185307_s, "Unb"), new Nametags.EnchantEntry(Enchantments.field_185309_u, "Pow"), new Nametags.EnchantEntry(Enchantments.field_77329_d, "Fpr"), new Nametags.EnchantEntry(Enchantments.field_180309_e, "Fea"), new Nametags.EnchantEntry(Enchantments.field_185297_d, "Bla"), new Nametags.EnchantEntry(Enchantments.field_180308_g, "Ppr"), new Nametags.EnchantEntry(Enchantments.field_185298_f, "Res"), new Nametags.EnchantEntry(Enchantments.field_185299_g, "Aqu"), new Nametags.EnchantEntry(Enchantments.field_185300_i, "Dep"), new Nametags.EnchantEntry(Enchantments.field_185301_j, "Fro"), new Nametags.EnchantEntry(Enchantments.field_190941_k, "Bin"), new Nametags.EnchantEntry(Enchantments.field_185303_l, "Smi"), new Nametags.EnchantEntry(Enchantments.field_180312_n, "Ban"), new Nametags.EnchantEntry(Enchantments.field_185304_p, "Loo"), new Nametags.EnchantEntry(Enchantments.field_191530_r, "Swe"), new Nametags.EnchantEntry(Enchantments.field_185305_q, "Eff"), new Nametags.EnchantEntry(Enchantments.field_185306_r, "Sil"), new Nametags.EnchantEntry(Enchantments.field_185308_t, "For"), new Nametags.EnchantEntry(Enchantments.field_185311_w, "Fla"), new Nametags.EnchantEntry(Enchantments.field_151370_z, "Luc"), new Nametags.EnchantEntry(Enchantments.field_151369_A, "Lur"), new Nametags.EnchantEntry(Enchantments.field_185296_A, "Men"), new Nametags.EnchantEntry(Enchantments.field_190940_C, "Van"), new Nametags.EnchantEntry(Enchantments.field_185310_v, "Pun")};
      GlStateManager.func_179094_E();
      GlStateManager.func_179094_E();
      float scale1 = 0.3F;
      GlStateManager.func_179109_b((float)(x - 3), (float)(y + 8), 0.0F);
      GlStateManager.func_179152_a(0.3F, 0.3F, 0.3F);
      GlStateManager.func_179121_F();
      RenderHelper.func_74520_c();
      renderItem.field_77023_b = -100.0F;
      GlStateManager.func_179097_i();
      renderItem.func_175042_a(stack, x, y);
      renderItem.func_180453_a(fontRenderer, stack, x, y, (String)null);
      GlStateManager.func_179126_j();
      GlStateManager.func_179152_a(0.75F, 0.75F, 0.75F);
      if (stack.func_77984_f()) {
         this.drawDamage(stack, x, y);
      }

      GlStateManager.func_179152_a(1.33F, 1.33F, 1.33F);
      Nametags.EnchantEntry[] array = enchants;
      int length = enchants.length;

      for(int i = 0; i < length; ++i) {
         Nametags.EnchantEntry enchant = array[i];
         int level = EnchantmentHelper.func_77506_a(enchant.getEnchant(), stack);
         String levelDisplay = "" + level;
         if (level > 10) {
            levelDisplay = "10+";
         }

         if (level > 0) {
            float scale2 = 0.32F;
            GlStateManager.func_179109_b((float)(x - 1), (float)(y + 2), 0.0F);
            GlStateManager.func_179152_a(0.42F, 0.42F, 0.42F);
            GlStateManager.func_179097_i();
            GlStateManager.func_179140_f();
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
            fontRenderer.func_175065_a("§f" + enchant.getName() + " " + levelDisplay, (float)(20 - fontRenderer.func_78256_a("§f" + enchant.getName() + " " + levelDisplay) / 2), 0.0F, Color.WHITE.getRGB(), true);
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
            GlStateManager.func_179145_e();
            GlStateManager.func_179126_j();
            GlStateManager.func_179152_a(2.42F, 2.42F, 2.42F);
            GlStateManager.func_179109_b((float)(-x + 1), (float)(-y), 0.0F);
            y += (int)((float)(fontRenderer.field_78288_b + 3) * 0.28F);
         }
      }

      renderItem.field_77023_b = 0.0F;
      RenderHelper.func_74518_a();
      GlStateManager.func_179141_d();
      GlStateManager.func_179084_k();
      GlStateManager.func_179140_f();
      GlStateManager.func_179121_F();
   }

   public void drawDamage(ItemStack itemstack, int x, int y) {
      float green = ((float)itemstack.func_77958_k() - (float)itemstack.func_77952_i()) / (float)itemstack.func_77958_k();
      float red = 1.0F - green;
      int dmg = 100 - (int)(red * 100.0F);
      GlStateManager.func_179097_i();
      mc.field_71466_p.func_175063_a(dmg + "", (float)(x + 8 - mc.field_71466_p.func_78256_a(dmg + "") / 2), (float)(y - 11), ColourHolder.toHex((int)(red * 255.0F), (int)(green * 255.0F), 0));
      GlStateManager.func_179126_j();
   }

   public static class EnchantEntry {
      private Enchantment enchant;
      private String name;

      public EnchantEntry(Enchantment enchant, String name) {
         this.enchant = enchant;
         this.name = name;
      }

      public Enchantment getEnchant() {
         return this.enchant;
      }

      public String getName() {
         return this.name;
      }
   }
}
