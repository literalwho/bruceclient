package me.travis.wurstplus.module.modules.render;

import me.travis.wurstplus.module.Module;

@Module.Info(
   name = "NoWeather",
   description = "Removes Weather",
   category = Module.Category.RENDER
)
public class NoWeather extends Module {
   public void onUpdate() {
      if (!this.isDisabled()) {
         if (mc.field_71441_e.func_72896_J()) {
            mc.field_71441_e.func_72894_k(0.0F);
         }

         if (mc.field_71441_e.func_72911_I()) {
            mc.field_71441_e.func_147442_i(0.0F);
         }

      }
   }
}
