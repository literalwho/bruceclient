package me.travis.wurstplus.module.modules.render;

import me.travis.wurstplus.module.Module;

@Module.Info(
   name = "CameraClip",
   category = Module.Category.RENDER
)
public class CameraClip extends Module {
}
