package me.travis.wurstplus.module.modules.render;

import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.travis.wurstplus.util.Invdraw;

@Module.Info(
   name = "Show INV",
   category = Module.Category.RENDER
)
public class InvPreview extends Module {
   private Setting xSetting = this.register(Settings.i("X Coord", 784));
   private Setting ySetting = this.register(Settings.i("Y Coord", 46));

   public void onRender() {
      if (this.isEnabled()) {
         Invdraw i = new Invdraw();
         i.drawInventory((Integer)this.xSetting.getValue(), (Integer)this.ySetting.getValue(), mc.field_71439_g);
      }
   }
}
