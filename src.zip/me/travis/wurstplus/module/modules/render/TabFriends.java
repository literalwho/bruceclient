package me.travis.wurstplus.module.modules.render;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.util.Friends;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.scoreboard.ScorePlayerTeam;

@Module.Info(
   name = "TabFriends",
   category = Module.Category.RENDER
)
public class TabFriends extends Module {
   public static TabFriends INSTANCE;

   public TabFriends() {
      INSTANCE = this;
   }

   public static String getPlayerName(NetworkPlayerInfo networkPlayerInfoIn) {
      String dname = networkPlayerInfoIn.func_178854_k() != null ? networkPlayerInfoIn.func_178854_k().func_150254_d() : ScorePlayerTeam.func_96667_a(networkPlayerInfoIn.func_178850_i(), networkPlayerInfoIn.func_178845_a().getName());
      return Friends.isFriend(dname) ? ChatFormatting.GOLD.toString() + dname : dname;
   }
}
