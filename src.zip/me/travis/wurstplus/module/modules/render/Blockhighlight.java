package me.travis.wurstplus.module.modules.render;

import java.awt.Color;
import me.travis.wurstplus.event.events.RenderEvent;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.travis.wurstplus.util.wurstplusTessellator;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

@Module.Info(
   name = "Block Highlight",
   category = Module.Category.RENDER
)
public class Blockhighlight extends Module {
   private Setting width = this.register(Settings.floatBuilder("Width").withMinimum(0.0F).withValue((Number)2.5F).build());
   private Setting rainbow = this.register(Settings.b("RainbowMode", false));
   private Setting red = this.register(Settings.integerBuilder("Red").withRange(0, 255).withValue((int)255).withVisibility((o) -> {
      return !(Boolean)this.rainbow.getValue();
   }).build());
   private Setting green = this.register(Settings.integerBuilder("Green").withRange(0, 255).withValue((int)255).withVisibility((o) -> {
      return !(Boolean)this.rainbow.getValue();
   }).build());
   private Setting blue = this.register(Settings.integerBuilder("Blue").withRange(0, 255).withValue((int)255).withVisibility((o) -> {
      return !(Boolean)this.rainbow.getValue();
   }).build());
   private Setting satuation = this.register(Settings.floatBuilder("Saturation").withRange(0.0F, 1.0F).withValue((Number)0.6F).withVisibility((o) -> {
      return (Boolean)this.rainbow.getValue();
   }).build());
   private Setting brightness = this.register(Settings.floatBuilder("Brightness").withRange(0.0F, 1.0F).withValue((Number)0.6F).withVisibility((o) -> {
      return (Boolean)this.rainbow.getValue();
   }).build());
   private Setting speed = this.register(Settings.integerBuilder("Speed").withRange(0, 10).withValue((int)2).withVisibility((o) -> {
      return (Boolean)this.rainbow.getValue();
   }).build());
   private Setting alpha = this.register(Settings.integerBuilder("Transparency").withRange(0, 255).withValue((int)70).build());
   private Setting renderMode;
   private BlockPos renderBlock;
   private float hue;
   private Color rgbc;

   public Blockhighlight() {
      this.renderMode = this.register(Settings.e("Render Mode", Blockhighlight.RenderMode.SOLID));
   }

   public void onWorldRender(RenderEvent event) {
      if (this.renderBlock != null && !(mc.field_71441_e.func_180495_p(this.renderBlock).func_177230_c() instanceof BlockAir) && !(mc.field_71441_e.func_180495_p(this.renderBlock).func_177230_c() instanceof BlockLiquid)) {
         if ((Boolean)this.rainbow.getValue()) {
            this.rgbc = Color.getHSBColor(this.hue, (Float)this.satuation.getValue(), (Float)this.brightness.getValue());
            this.drawBlock(this.renderBlock, this.rgbc.getRed(), this.rgbc.getGreen(), this.rgbc.getBlue());
            if (this.hue + (float)(Integer)this.speed.getValue() / 200.0F > 1.0F) {
               this.hue = 0.0F;
            } else {
               this.hue += (float)(Integer)this.speed.getValue() / 200.0F;
            }
         } else {
            this.drawBlock(this.renderBlock, (Integer)this.red.getValue(), (Integer)this.green.getValue(), (Integer)this.blue.getValue());
         }
      }

   }

   private void drawBlock(BlockPos blockPos, int r, int g, int b) {
      Color color = new Color(r, g, b, (Integer)this.alpha.getValue());
      wurstplusTessellator.prepare(7);
      if (((Blockhighlight.RenderMode)this.renderMode.getValue()).equals(Blockhighlight.RenderMode.UP)) {
         wurstplusTessellator.drawBox(blockPos, color.getRGB(), 2);
      } else if (((Blockhighlight.RenderMode)this.renderMode.getValue()).equals(Blockhighlight.RenderMode.SOLID)) {
         wurstplusTessellator.drawBox(blockPos, color.getRGB(), 63);
      } else {
         IBlockState iBlockState2;
         Vec3d interp2;
         if (((Blockhighlight.RenderMode)this.renderMode.getValue()).equals(Blockhighlight.RenderMode.OUTLINE)) {
            iBlockState2 = mc.field_71441_e.func_180495_p(this.renderBlock);
            interp2 = interpolateEntity(mc.field_71439_g, mc.func_184121_ak());
            wurstplusTessellator.drawBoundingBox(iBlockState2.func_185918_c(mc.field_71441_e, this.renderBlock).func_72317_d(-interp2.field_72450_a, -interp2.field_72448_b, -interp2.field_72449_c), (Float)this.width.getValue(), r, g, b, (Integer)this.alpha.getValue());
         } else {
            iBlockState2 = mc.field_71441_e.func_180495_p(this.renderBlock);
            interp2 = interpolateEntity(mc.field_71439_g, mc.func_184121_ak());
            wurstplusTessellator.drawFullBox(iBlockState2.func_185918_c(mc.field_71441_e, this.renderBlock).func_72317_d(-interp2.field_72450_a, -interp2.field_72448_b, -interp2.field_72449_c), this.renderBlock, (Float)this.width.getValue(), r, g, b, (Integer)this.alpha.getValue());
         }
      }

      wurstplusTessellator.release();
   }

   public void onUpdate() {
      if (mc.field_71439_g != null && !this.isDisabled()) {
         try {
            this.renderBlock = new BlockPos((double)mc.field_71476_x.func_178782_a().func_177958_n(), (double)mc.field_71476_x.func_178782_a().func_177956_o(), (double)mc.field_71476_x.func_178782_a().func_177952_p());
         } catch (Exception var2) {
         }
      }
   }

   public static Vec3d interpolateEntity(Entity entity, float time) {
      return new Vec3d(entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)time, entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)time, entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)time);
   }

   public void onEnable() {
      this.hue = 0.0F;
   }

   public void onDisable() {
      this.renderBlock = null;
   }

   private static enum RenderMode {
      SOLID,
      OUTLINE,
      UP,
      FULL;
   }
}
