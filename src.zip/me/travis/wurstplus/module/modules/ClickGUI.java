package me.travis.wurstplus.module.modules;

import me.travis.wurstplus.gui.wurstplus.DisplayGuiScreen;
import me.travis.wurstplus.module.Module;

@Module.Info(
   name = "clickGUI",
   description = "Opens the Click GUI",
   category = Module.Category.HIDDEN
)
public class ClickGUI extends Module {
   public ClickGUI() {
      this.getBind().setKey(21);
   }

   protected void onEnable() {
      if (!(mc.field_71462_r instanceof DisplayGuiScreen)) {
         mc.func_147108_a(new DisplayGuiScreen(mc.field_71462_r));
      }

      this.disable();
   }
}
