package me.travis.wurstplus.module.modules.combat;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.travis.wurstplus.util.BlockInteractionHelper;
import me.travis.wurstplus.util.EntityUtil;
import me.travis.wurstplus.util.Friends;
import me.travis.wurstplus.util.Wrapper;
import net.minecraft.block.BlockObsidian;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

@Module.Info(
   name = "AutoTrap",
   category = Module.Category.COMBAT
)
public class AutoTrap extends Module {
   private final Vec3d[] offsetsDefault = new Vec3d[]{new Vec3d(0.0D, 0.0D, -1.0D), new Vec3d(1.0D, 0.0D, 0.0D), new Vec3d(0.0D, 0.0D, 1.0D), new Vec3d(-1.0D, 0.0D, 0.0D), new Vec3d(0.0D, 1.0D, -1.0D), new Vec3d(1.0D, 1.0D, 0.0D), new Vec3d(0.0D, 1.0D, 1.0D), new Vec3d(-1.0D, 1.0D, 0.0D), new Vec3d(0.0D, 2.0D, -1.0D), new Vec3d(1.0D, 2.0D, 0.0D), new Vec3d(0.0D, 2.0D, 1.0D), new Vec3d(-1.0D, 2.0D, 0.0D), new Vec3d(0.0D, 3.0D, -1.0D), new Vec3d(0.0D, 3.0D, 1.0D), new Vec3d(1.0D, 3.0D, 0.0D), new Vec3d(-1.0D, 3.0D, 0.0D), new Vec3d(0.0D, 3.0D, 0.0D)};
   private final Vec3d[] offsetsExtra = new Vec3d[]{new Vec3d(0.0D, 0.0D, -1.0D), new Vec3d(1.0D, 0.0D, 0.0D), new Vec3d(0.0D, 0.0D, 1.0D), new Vec3d(-1.0D, 0.0D, 0.0D), new Vec3d(0.0D, 1.0D, -1.0D), new Vec3d(1.0D, 1.0D, 0.0D), new Vec3d(0.0D, 1.0D, 1.0D), new Vec3d(-1.0D, 1.0D, 0.0D), new Vec3d(0.0D, 2.0D, -1.0D), new Vec3d(1.0D, 2.0D, 0.0D), new Vec3d(0.0D, 2.0D, 1.0D), new Vec3d(-1.0D, 2.0D, 0.0D), new Vec3d(0.0D, 3.0D, -1.0D), new Vec3d(0.0D, 3.0D, 0.0D), new Vec3d(0.0D, 4.0D, 0.0D)};
   private Setting range = this.register(Settings.d("Range", 5.5D));
   private Setting blockPerTick = this.register(Settings.i("Blocks per Tick", 4));
   private Setting rotate = this.register(Settings.b("Rotate", true));
   private Setting extrablock = this.register(Settings.b("Extra Block", true));
   private Setting chad = this.register(Settings.b("Chad Mode", false));
   private Setting announceUsage = this.register(Settings.b("Announce Usage", true));
   private EntityPlayer closestTarget;
   private String lastTickTargetName;
   private int playerHotbarSlot = -1;
   private int lastHotbarSlot = -1;
   private boolean isSneaking = false;
   private int offsetStep = 0;
   private boolean firstRun;
   private double yHeight;
   private double xPos;
   private double zPos;

   protected void onEnable() {
      if (mc.field_71439_g == null) {
         this.disable();
      } else {
         this.yHeight = (double)((int)Math.ceil(mc.field_71439_g.field_70163_u));
         this.xPos = (double)((int)Math.ceil(mc.field_71439_g.field_70165_t));
         this.zPos = (double)((int)Math.ceil(mc.field_71439_g.field_70161_v));
         this.firstRun = true;
         this.playerHotbarSlot = Wrapper.getPlayer().field_71071_by.field_70461_c;
         this.lastHotbarSlot = -1;
      }
   }

   protected void onDisable() {
      if (mc.field_71439_g != null) {
         if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
            Wrapper.getPlayer().field_71071_by.field_70461_c = this.playerHotbarSlot;
         }

         if (this.isSneaking) {
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.STOP_SNEAKING));
            this.isSneaking = false;
         }

         this.playerHotbarSlot = -1;
         this.lastHotbarSlot = -1;
         if ((Boolean)this.announceUsage.getValue()) {
            Command.sendChatMessage("we aint §l§4trapping§r no more");
         }

      }
   }

   public void onUpdate() {
      if (mc.field_71439_g != null) {
         if ((Boolean)this.chad.getValue() && (Math.ceil(mc.field_71439_g.field_70163_u) != this.yHeight || Math.ceil(mc.field_71439_g.field_70165_t) != this.xPos || Math.ceil(mc.field_71439_g.field_70163_u) != this.zPos)) {
            Command.sendChatMessage("c: " + Math.ceil(mc.field_71439_g.field_70165_t) + " " + Math.ceil(mc.field_71439_g.field_70163_u) + " " + Math.ceil(mc.field_71439_g.field_70161_v));
            Command.sendChatMessage("d: " + this.xPos + " " + this.yHeight + " " + this.zPos);
            this.disable();
         }

         this.findClosestTarget();
         if (this.closestTarget == null) {
            if (this.firstRun) {
               this.firstRun = false;
               if ((Boolean)this.announceUsage.getValue()) {
                  Command.sendChatMessage("we §l§2trapping§r");
               }
            }

         } else {
            if (this.firstRun) {
               this.firstRun = false;
               this.lastTickTargetName = this.closestTarget.func_70005_c_();
            } else if (!this.lastTickTargetName.equals(this.closestTarget.func_70005_c_())) {
               this.lastTickTargetName = this.closestTarget.func_70005_c_();
               this.offsetStep = 0;
            }

            ArrayList placeTargets = new ArrayList();
            if ((Boolean)this.extrablock.getValue()) {
               Collections.addAll(placeTargets, this.offsetsExtra);
            } else {
               Collections.addAll(placeTargets, this.offsetsDefault);
            }

            int blocksPlaced;
            for(blocksPlaced = 0; blocksPlaced < (Integer)this.blockPerTick.getValue(); ++this.offsetStep) {
               if (this.offsetStep >= placeTargets.size()) {
                  this.offsetStep = 0;
                  break;
               }

               BlockPos offsetPos = new BlockPos((Vec3d)placeTargets.get(this.offsetStep));
               BlockPos targetPos = (new BlockPos(this.closestTarget.func_174791_d())).func_177977_b().func_177982_a(offsetPos.field_177962_a, offsetPos.field_177960_b, offsetPos.field_177961_c);
               boolean shouldTryToPlace = true;
               if (!Wrapper.getWorld().func_180495_p(targetPos).func_185904_a().func_76222_j()) {
                  shouldTryToPlace = false;
               }

               Iterator var6 = mc.field_71441_e.func_72839_b((Entity)null, new AxisAlignedBB(targetPos)).iterator();

               while(var6.hasNext()) {
                  Entity entity = (Entity)var6.next();
                  if (!(entity instanceof EntityItem) && !(entity instanceof EntityXPOrb)) {
                     shouldTryToPlace = false;
                     break;
                  }
               }

               if (shouldTryToPlace && this.placeBlock(targetPos)) {
                  ++blocksPlaced;
               }
            }

            if (blocksPlaced > 0) {
               if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
                  Wrapper.getPlayer().field_71071_by.field_70461_c = this.playerHotbarSlot;
                  this.lastHotbarSlot = this.playerHotbarSlot;
               }

               if (this.isSneaking) {
                  mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.STOP_SNEAKING));
                  this.isSneaking = false;
               }
            }

         }
      }
   }

   private boolean placeBlock(BlockPos pos) {
      if (!mc.field_71441_e.func_180495_p(pos).func_185904_a().func_76222_j()) {
         return false;
      } else if (!BlockInteractionHelper.checkForNeighbours(pos)) {
         return false;
      } else {
         Vec3d eyesPos = new Vec3d(Wrapper.getPlayer().field_70165_t, Wrapper.getPlayer().field_70163_u + (double)Wrapper.getPlayer().func_70047_e(), Wrapper.getPlayer().field_70161_v);
         EnumFacing[] var3 = EnumFacing.values();
         int var4 = var3.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            EnumFacing side = var3[var5];
            BlockPos neighbor = pos.func_177972_a(side);
            EnumFacing side2 = side.func_176734_d();
            Vec3d hitVec;
            if (mc.field_71441_e.func_180495_p(neighbor).func_177230_c().func_176209_a(mc.field_71441_e.func_180495_p(neighbor), false) && eyesPos.func_72438_d(hitVec = (new Vec3d(neighbor)).func_72441_c(0.5D, 0.5D, 0.5D).func_178787_e((new Vec3d(side2.func_176730_m())).func_186678_a(0.5D))) <= (Double)this.range.getValue()) {
               int obiSlot = this.findObiInHotbar();
               if (obiSlot == -1) {
                  this.disable();
                  return false;
               }

               if (this.lastHotbarSlot != obiSlot) {
                  Wrapper.getPlayer().field_71071_by.field_70461_c = obiSlot;
                  this.lastHotbarSlot = obiSlot;
               }

               if (BlockInteractionHelper.blackList.contains(mc.field_71441_e.func_180495_p(neighbor).func_177230_c())) {
                  mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.START_SNEAKING));
                  this.isSneaking = true;
               }

               if ((Boolean)this.rotate.getValue()) {
                  BlockInteractionHelper.faceVectorPacketInstant(hitVec);
               }

               mc.field_71442_b.func_187099_a(mc.field_71439_g, mc.field_71441_e, neighbor, side2, hitVec, EnumHand.MAIN_HAND);
               mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
               return true;
            }
         }

         return false;
      }
   }

   private int findObiInHotbar() {
      int slot = -1;

      for(int i = 1; i < 10; ++i) {
         ItemStack stack = Wrapper.getPlayer().field_71071_by.func_70301_a(i);
         if (stack != ItemStack.field_190927_a && stack.func_77973_b() instanceof ItemBlock && ((ItemBlock)stack.func_77973_b()).func_179223_d() instanceof BlockObsidian) {
            slot = i;
            break;
         }
      }

      return slot;
   }

   private void findClosestTarget() {
      List entities = new ArrayList();
      entities.addAll((Collection)mc.field_71441_e.field_73010_i.stream().filter((entityPlayer) -> {
         return !Friends.isFriend(entityPlayer.func_70005_c_());
      }).collect(Collectors.toList()));
      this.closestTarget = null;
      Iterator var2 = entities.iterator();

      while(var2.hasNext()) {
         EntityPlayer target = (EntityPlayer)var2.next();
         if (target.func_70005_c_() != mc.field_71439_g.func_70005_c_() && !Friends.isFriend(target.func_70005_c_()) && EntityUtil.isLiving(target) && target.func_110143_aJ() > 0.0F) {
            if (this.closestTarget == null) {
               this.closestTarget = target;
            } else if (Wrapper.getPlayer().func_70032_d(target) < Wrapper.getPlayer().func_70032_d(this.closestTarget)) {
               this.closestTarget = target;
            }
         }
      }

   }
}
