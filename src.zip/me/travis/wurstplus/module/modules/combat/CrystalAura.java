package me.travis.wurstplus.module.modules.combat;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.event.events.RenderEvent;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.module.ModuleManager;
import me.travis.wurstplus.module.modules.chat.AutoEZ;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.travis.wurstplus.util.BlockInteractionHelper;
import me.travis.wurstplus.util.EntityUtil;
import me.travis.wurstplus.util.Friends;
import me.travis.wurstplus.util.wurstplusTessellator;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.CombatRules;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Explosion;

@Module.Info(
   name = "AutoCrystal2",
   category = Module.Category.CrystalPVP
)
public class CrystalAura extends Module {
   private Setting place = this.register(Settings.b("Place", true));
   private Setting explode = this.register(Settings.b("Explode", true));
   private Setting experamental = this.register(Settings.b("Experamental", true));
   private Setting autoSwitch = this.register(Settings.b("Auto Switch", true));
   private Setting antiWeakness = this.register(Settings.b("Anti Weakness", true));
   private Setting spoofRotations = this.register(Settings.b("Spoof Rotations", false));
   private Setting cancelMining = this.register(Settings.b("Cancel Mining", false));
   private Setting fastMode = this.register(Settings.b("Fast Mode", false));
   private Setting fuckedMode = this.register(Settings.b("Fucked Detector", false));
   private Setting debug = this.register(Settings.b("Debug Messages", false));
   private Setting hitTickDelay = this.register(Settings.integerBuilder("Delay").withMinimum(0).withValue((int)4).withMaximum(6).build());
   private Setting hitRange = this.register(Settings.doubleBuilder("Hit Range").withMinimum(0.0D).withValue((Number)5.5D).build());
   private Setting placeRange = this.register(Settings.doubleBuilder("Place Range").withMinimum(0.0D).withValue((Number)3.5D).build());
   private Setting minDamage = this.register(Settings.doubleBuilder("Min Damage").withMinimum(0.0D).withValue((Number)2.0D).withMaximum(20.0D).build());
   private Setting maxSelf = this.register(Settings.doubleBuilder("Max Self").withMinimum(0.0D).withValue((Number)8.0D).withMaximum(20.0D).build());
   private Setting rainbow = this.register(Settings.b("RainbowMode", false));
   private Setting red = this.register(Settings.integerBuilder("Red").withRange(0, 255).withValue((int)255).withVisibility((o) -> {
      return !(Boolean)this.rainbow.getValue();
   }).build());
   private Setting green = this.register(Settings.integerBuilder("Green").withRange(0, 255).withValue((int)255).withVisibility((o) -> {
      return !(Boolean)this.rainbow.getValue();
   }).build());
   private Setting blue = this.register(Settings.integerBuilder("Blue").withRange(0, 255).withValue((int)255).withVisibility((o) -> {
      return !(Boolean)this.rainbow.getValue();
   }).build());
   private Setting satuation = this.register(Settings.floatBuilder("Saturation").withRange(0.0F, 1.0F).withValue((Number)0.6F).withVisibility((o) -> {
      return (Boolean)this.rainbow.getValue();
   }).build());
   private Setting brightness = this.register(Settings.floatBuilder("Brightness").withRange(0.0F, 1.0F).withValue((Number)0.6F).withVisibility((o) -> {
      return (Boolean)this.rainbow.getValue();
   }).build());
   private Setting speed = this.register(Settings.integerBuilder("Speed").withRange(0, 10).withValue((int)2).withVisibility((o) -> {
      return (Boolean)this.rainbow.getValue();
   }).build());
   private Setting alpha = this.register(Settings.integerBuilder("Transparency").withRange(0, 255).withValue((int)70).build());
   private Setting renderMode;
   private Setting tabbottMode;
   private Setting travisMode;
   private Setting tabbottDamage;
   private BlockPos renderBlock;
   private boolean switchCooldown;
   private boolean isAttacking;
   private boolean flag;
   private boolean shouldBreak;
   private static boolean togglePitch = false;
   private static boolean isSpoofingAngles;
   private static double yaw;
   private static double pitch;
   private int oldSlot;
   private int newSlot;
   private int hitDelayCounter;
   private float hue;
   private Color rgbc;
   public Set fuckedPlayers;
   @EventHandler
   private Listener packetListener;

   public CrystalAura() {
      this.renderMode = this.register(Settings.e("Render Mode", CrystalAura.RenderMode.SOLID));
      this.tabbottMode = this.register(Settings.b("Tabbott Mode", false));
      this.travisMode = this.register(Settings.b("Travis Mode", false));
      this.tabbottDamage = this.register(Settings.doubleBuilder("Enemy Health Min").withMinimum(0.0D).withValue((Number)8.0D).withMaximum(20.0D).withVisibility((o) -> {
         return (Boolean)this.tabbottMode.getValue();
      }).build());
      this.switchCooldown = false;
      this.isAttacking = false;
      this.flag = false;
      this.shouldBreak = false;
      this.oldSlot = -1;
      this.packetListener = new Listener((event) -> {
         if ((Boolean)this.spoofRotations.getValue()) {
            Packet packet = event.getPacket();
            if (packet instanceof CPacketPlayer && isSpoofingAngles) {
               ((CPacketPlayer)packet).field_149476_e = (float)yaw;
               ((CPacketPlayer)packet).field_149473_f = (float)pitch;
            }

         }
      }, new Predicate[0]);
   }

   public static BlockPos getPlayerPos() {
      return new BlockPos(Math.floor(mc.field_71439_g.field_70165_t), Math.floor(mc.field_71439_g.field_70163_u), Math.floor(mc.field_71439_g.field_70161_v));
   }

   static float calculateDamage(double posX, double posY, double posZ, Entity entity) {
      float doubleExplosionSize = 12.0F;
      double distancedsize = entity.func_70011_f(posX, posY, posZ) / (double)doubleExplosionSize;
      Vec3d vec3d = new Vec3d(posX, posY, posZ);
      double blockDensity = (double)entity.field_70170_p.func_72842_a(vec3d, entity.func_174813_aQ());
      double v = (1.0D - distancedsize) * blockDensity;
      float damage = (float)((int)((v * v + v) / 2.0D * 7.0D * (double)doubleExplosionSize + 1.0D));
      double finald = 1.0D;
      if (entity instanceof EntityLivingBase) {
         finald = (double)getBlastReduction((EntityLivingBase)entity, getDamageMultiplied(damage), new Explosion(mc.field_71441_e, (Entity)null, posX, posY, posZ, 6.0F, false, true));
      }

      return (float)finald;
   }

   private static float getBlastReduction(EntityLivingBase entity, float damage, Explosion explosion) {
      if (entity instanceof EntityPlayer) {
         EntityPlayer ep = (EntityPlayer)entity;
         DamageSource ds = DamageSource.func_94539_a(explosion);
         damage = CombatRules.func_189427_a(damage, (float)ep.func_70658_aO(), (float)ep.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e());
         int k = EnchantmentHelper.func_77508_a(ep.func_184193_aE(), ds);
         float f = MathHelper.func_76131_a((float)k, 0.0F, 20.0F);
         damage *= 1.0F - f / 25.0F;
         if (entity.func_70644_a(MobEffects.field_76429_m)) {
            damage -= damage / 4.0F;
         }

         return damage;
      } else {
         damage = CombatRules.func_189427_a(damage, (float)entity.func_70658_aO(), (float)entity.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e());
         return damage;
      }
   }

   private static float getDamageMultiplied(float damage) {
      int diff = mc.field_71441_e.func_175659_aa().func_151525_a();
      return damage * (diff == 0 ? 0.0F : (diff == 2 ? 1.0F : (diff == 1 ? 0.5F : 1.5F)));
   }

   private static void setYawAndPitch(float yaw1, float pitch1) {
      yaw = (double)yaw1;
      pitch = (double)pitch1;
      isSpoofingAngles = true;
   }

   private static void resetRotation() {
      if (isSpoofingAngles) {
         yaw = (double)mc.field_71439_g.field_70177_z;
         pitch = (double)mc.field_71439_g.field_70125_A;
         isSpoofingAngles = false;
      }

   }

   public void onWorldRender(RenderEvent event) {
      if (mc.func_175598_ae().field_78733_k != null) {
         if (this.renderBlock != null) {
            if ((Boolean)this.rainbow.getValue()) {
               this.rgbc = Color.getHSBColor(this.hue, (Float)this.satuation.getValue(), (Float)this.brightness.getValue());
               this.drawBlock(this.renderBlock, this.rgbc.getRed(), this.rgbc.getGreen(), this.rgbc.getBlue());
               if (this.hue + (float)(Integer)this.speed.getValue() / 200.0F > 1.0F) {
                  this.hue = 0.0F;
               } else {
                  this.hue += (float)(Integer)this.speed.getValue() / 200.0F;
               }
            } else {
               this.drawBlock(this.renderBlock, (Integer)this.red.getValue(), (Integer)this.green.getValue(), (Integer)this.blue.getValue());
            }
         }

      }
   }

   private void drawBlock(BlockPos blockPos, int r, int g, int b) {
      Color color = new Color(r, g, b, (Integer)this.alpha.getValue());
      wurstplusTessellator.prepare(7);
      if (((CrystalAura.RenderMode)this.renderMode.getValue()).equals(CrystalAura.RenderMode.UP)) {
         wurstplusTessellator.drawBox(blockPos, color.getRGB(), 2);
      } else if (((CrystalAura.RenderMode)this.renderMode.getValue()).equals(CrystalAura.RenderMode.SOLID)) {
         wurstplusTessellator.drawBox(blockPos, color.getRGB(), 63);
      } else {
         IBlockState iBlockState2;
         Vec3d interp2;
         if (((CrystalAura.RenderMode)this.renderMode.getValue()).equals(CrystalAura.RenderMode.OUTLINE)) {
            iBlockState2 = mc.field_71441_e.func_180495_p(blockPos);
            interp2 = interpolateEntity(mc.field_71439_g, mc.func_184121_ak());
            wurstplusTessellator.drawBoundingBox(iBlockState2.func_185918_c(mc.field_71441_e, blockPos).func_72317_d(-interp2.field_72450_a, -interp2.field_72448_b, -interp2.field_72449_c), 1.5F, r, g, b, (Integer)this.alpha.getValue());
         } else {
            iBlockState2 = mc.field_71441_e.func_180495_p(blockPos);
            interp2 = interpolateEntity(mc.field_71439_g, mc.func_184121_ak());
            wurstplusTessellator.drawFullBox(iBlockState2.func_185918_c(mc.field_71441_e, blockPos).func_72317_d(-interp2.field_72450_a, -interp2.field_72448_b, -interp2.field_72449_c), blockPos, 1.5F, r, g, b, (Integer)this.alpha.getValue());
         }
      }

      wurstplusTessellator.release();
   }

   public Boolean checkHole(EntityPlayer ent) {
      BlockPos pos = new BlockPos(ent.field_70165_t, ent.field_70163_u - 1.0D, ent.field_70161_v);
      if (mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150350_a) {
         return false;
      } else if (!this.canPlaceCrystal(pos.func_177968_d()) && (!this.canPlaceCrystal(pos.func_177968_d().func_177968_d()) || mc.field_71441_e.func_180495_p(pos.func_177982_a(0, 1, 1)).func_177230_c() != Blocks.field_150350_a)) {
         if (this.canPlaceCrystal(pos.func_177974_f()) || this.canPlaceCrystal(pos.func_177974_f().func_177974_f()) && mc.field_71441_e.func_180495_p(pos.func_177982_a(1, 1, 0)).func_177230_c() == Blocks.field_150350_a) {
            return true;
         } else if (!this.canPlaceCrystal(pos.func_177976_e()) && (!this.canPlaceCrystal(pos.func_177976_e().func_177976_e()) || mc.field_71441_e.func_180495_p(pos.func_177982_a(-1, 1, 0)).func_177230_c() != Blocks.field_150350_a)) {
            return !this.canPlaceCrystal(pos.func_177978_c()) && (!this.canPlaceCrystal(pos.func_177978_c().func_177978_c()) || mc.field_71441_e.func_180495_p(pos.func_177982_a(0, 1, -1)).func_177230_c() != Blocks.field_150350_a) ? false : true;
         } else {
            return true;
         }
      } else {
         return true;
      }
   }

   public void placeCrystals() {
      int crys = 1;
      if (this.oldSlot != -1) {
         mc.field_71439_g.field_71071_by.field_70461_c = this.oldSlot;
         this.oldSlot = -1;
      }

      this.isAttacking = false;
      int crystalSlot = mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP ? mc.field_71439_g.field_71071_by.field_70461_c : -1;
      if (crystalSlot == -1) {
         for(int l = 0; l < 9; ++l) {
            if (mc.field_71439_g.field_71071_by.func_70301_a(l).func_77973_b() == Items.field_185158_cP) {
               crystalSlot = l;
               break;
            }
         }
      }

      boolean offhand = false;
      if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) {
         offhand = true;
      } else if (crystalSlot == -1) {
         return;
      }

      label166:
      for(int i = 0; i < crys; ++i) {
         List blocks = this.findCrystalBlocks();
         List entities = new ArrayList();
         entities.addAll((Collection)mc.field_71441_e.field_73010_i.stream().filter((entityPlayer) -> {
            return !Friends.isFriend(entityPlayer.func_70005_c_());
         }).collect(Collectors.toList()));
         BlockPos targetBlock = null;
         double targetBlockDamage = 0.0D;
         EntityPlayer target = null;
         double minDam = (Double)this.minDamage.getValue();
         Iterator var14 = entities.iterator();

         label152:
         while(true) {
            EntityPlayer testTarget;
            do {
               do {
                  do {
                     Entity entity2;
                     do {
                        do {
                           if (!var14.hasNext()) {
                              if (target == null) {
                                 this.renderBlock = null;
                                 resetRotation();
                                 return;
                              }

                              this.renderBlock = targetBlock;
                              if (ModuleManager.getModuleByName("AutoEZ").isEnabled()) {
                                 AutoEZ autoGG = (AutoEZ)ModuleManager.getModuleByName("AutoEZ");
                                 autoGG.addTargetedPlayer(target.func_70005_c_());
                              }

                              if ((Boolean)this.place.getValue()) {
                                 if (!offhand && mc.field_71439_g.field_71071_by.field_70461_c != crystalSlot) {
                                    if ((Boolean)this.autoSwitch.getValue()) {
                                       mc.field_71439_g.field_71071_by.field_70461_c = crystalSlot;
                                       resetRotation();
                                       this.switchCooldown = true;
                                    }

                                    return;
                                 }

                                 this.lookAtPacket((double)targetBlock.field_177962_a + 0.5D, (double)targetBlock.field_177960_b - 0.5D, (double)targetBlock.field_177961_c + 0.5D, mc.field_71439_g);
                                 RayTraceResult result = mc.field_71441_e.func_72933_a(new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + (double)mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v), new Vec3d((double)targetBlock.field_177962_a + 0.5D, (double)targetBlock.field_177960_b - 0.5D, (double)targetBlock.field_177961_c + 0.5D));
                                 EnumFacing f = result != null && result.field_178784_b != null ? result.field_178784_b : EnumFacing.UP;
                                 if (this.switchCooldown) {
                                    this.switchCooldown = false;
                                    return;
                                 }

                                 if ((Boolean)this.debug.getValue()) {
                                    Command.sendChatMessage("placing crystal");
                                 }

                                 mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItemOnBlock(targetBlock, f, offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0F, 0.0F, 0.0F));
                              }

                              if ((Boolean)this.spoofRotations.getValue() && isSpoofingAngles) {
                                 if (togglePitch) {
                                    mc.field_71439_g.field_70125_A = (float)((double)mc.field_71439_g.field_70125_A + 4.0E-4D);
                                    togglePitch = false;
                                 } else {
                                    mc.field_71439_g.field_70125_A = (float)((double)mc.field_71439_g.field_70125_A - 4.0E-4D);
                                    togglePitch = true;
                                 }
                              }
                              continue label166;
                           }

                           entity2 = (Entity)var14.next();
                        } while(entity2 == mc.field_71439_g);
                     } while(!(entity2 instanceof EntityPlayer));

                     testTarget = (EntityPlayer)entity2;
                  } while(testTarget.field_70128_L);
               } while(testTarget.func_110143_aJ() <= 0.0F);
            } while(testTarget.func_174818_b(mc.field_71439_g.func_180425_c()) >= 169.0D);

            Iterator var17 = blocks.iterator();

            while(true) {
               BlockPos blockPos;
               double targetDamage;
               double selfDamage;
               float healthTarget;
               float healthSelf;
               do {
                  do {
                     do {
                        do {
                           if (!var17.hasNext()) {
                              continue label152;
                           }

                           blockPos = (BlockPos)var17.next();
                        } while(testTarget.func_174818_b(blockPos) >= 169.0D);

                        targetDamage = (double)calculateDamage((double)blockPos.field_177962_a + 0.5D, (double)(blockPos.field_177960_b + 1), (double)blockPos.field_177961_c + 0.5D, testTarget);
                        selfDamage = (double)calculateDamage((double)blockPos.field_177962_a + 0.5D, (double)(blockPos.field_177960_b + 1), (double)blockPos.field_177961_c + 0.5D, mc.field_71439_g);
                        healthTarget = testTarget.func_110143_aJ() + testTarget.func_110139_bj();
                        healthSelf = mc.field_71439_g.func_110143_aJ() + mc.field_71439_g.func_110139_bj();
                        if ((double)testTarget.func_110143_aJ() < (Double)this.tabbottDamage.getValue() && (Boolean)this.tabbottMode.getValue()) {
                           minDam = 0.1D;
                        }
                     } while(targetDamage < minDam);
                  } while(selfDamage >= (double)healthSelf - 0.5D);
               } while(selfDamage > targetDamage && targetDamage < (double)healthTarget);

               if (targetDamage > targetBlockDamage && selfDamage <= (Double)this.maxSelf.getValue() && (double)mc.field_71439_g.func_110143_aJ() - selfDamage >= 2.0D) {
                  targetBlock = blockPos;
                  targetBlockDamage = targetDamage;
                  target = testTarget;
               }
            }
         }
      }

   }

   public void breakCrystals(EntityEnderCrystal crystal) {
      if (crystal != null) {
         if (this.shouldBreak) {
            this.hitDelayCounter = 0;
            if ((Boolean)this.antiWeakness.getValue() && mc.field_71439_g.func_70644_a(MobEffects.field_76437_t)) {
               if (!this.isAttacking) {
                  this.oldSlot = mc.field_71439_g.field_71071_by.field_70461_c;
                  this.isAttacking = true;
               }

               this.newSlot = -1;

               for(int i = 0; i < 9; ++i) {
                  ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
                  if (stack != ItemStack.field_190927_a) {
                     if (stack.func_77973_b() instanceof ItemSword) {
                        this.newSlot = i;
                        break;
                     }

                     if (stack.func_77973_b() instanceof ItemTool) {
                        this.newSlot = i;
                        break;
                     }
                  }
               }

               if (this.newSlot != -1) {
                  mc.field_71439_g.field_71071_by.field_70461_c = this.newSlot;
                  this.switchCooldown = true;
               }
            }

            if (!(Boolean)this.travisMode.getValue()) {
               if ((Boolean)this.debug.getValue()) {
                  Command.sendChatMessage("hitting crystal");
               }

               this.lookAtPacket(crystal.field_70165_t, crystal.field_70163_u, crystal.field_70161_v, mc.field_71439_g);
               mc.field_71442_b.func_78764_a(mc.field_71439_g, crystal);
               mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
               return;
            }

            double selfDamage = (double)calculateDamage(crystal.field_70165_t + 0.5D, crystal.field_70163_u + 1.0D, crystal.field_70161_v + 0.5D, mc.field_71439_g);
            if (selfDamage < (Double)this.maxSelf.getValue() && (double)mc.field_71439_g.func_110143_aJ() - selfDamage > 0.0D) {
               if ((Boolean)this.debug.getValue()) {
                  Command.sendChatMessage("hitting crystal");
               }

               this.lookAtPacket(crystal.field_70165_t, crystal.field_70163_u, crystal.field_70161_v, mc.field_71439_g);
               mc.field_71442_b.func_78764_a(mc.field_71439_g, crystal);
               mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
               return;
            }
         }

      }
   }

   public void onUpdate() {
      if (mc.field_71439_g.func_184614_ca().func_77973_b() != Items.field_151046_w || (Boolean)this.cancelMining.getValue() || !mc.field_71439_g.func_184587_cr()) {
         EntityEnderCrystal crystal = (EntityEnderCrystal)mc.field_71441_e.field_72996_f.stream().filter((entity) -> {
            return entity instanceof EntityEnderCrystal;
         }).map((entity) -> {
            return (EntityEnderCrystal)entity;
         }).min(Comparator.comparing((c) -> {
            return mc.field_71439_g.func_70032_d(c);
         })).orElse((Object)null);
         if (crystal != null && (double)mc.field_71439_g.func_70032_d(crystal) <= (Double)this.hitRange.getValue()) {
            this.shouldBreak = true;
            if (this.hitDelayCounter < (Integer)this.hitTickDelay.getValue()) {
               ++this.hitDelayCounter;
               this.shouldBreak = false;
               if (!(Boolean)this.fastMode.getValue()) {
                  return;
               }
            }
         }

         if ((Boolean)this.experamental.getValue()) {
            if ((Boolean)this.explode.getValue()) {
               this.placeCrystals();
            }

            if ((Boolean)this.place.getValue()) {
               this.breakCrystals(crystal);
            }
         } else {
            if ((Boolean)this.explode.getValue()) {
               this.breakCrystals(crystal);
            }

            if ((Boolean)this.place.getValue()) {
               this.placeCrystals();
            }
         }

         resetRotation();
      }
   }

   private void lookAtPacket(double px, double py, double pz, EntityPlayer me) {
      double[] v = EntityUtil.calculateLookAt(px, py, pz, me);
      setYawAndPitch((float)v[0], (float)v[1]);
   }

   private boolean canPlaceCrystal(BlockPos blockPos) {
      BlockPos boost = blockPos.func_177982_a(0, 1, 0);
      BlockPos boost2 = blockPos.func_177982_a(0, 2, 0);
      return (mc.field_71441_e.func_180495_p(blockPos).func_177230_c() == Blocks.field_150357_h || mc.field_71441_e.func_180495_p(blockPos).func_177230_c() == Blocks.field_150343_Z) && mc.field_71441_e.func_180495_p(boost).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(boost2).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost)).isEmpty() && mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost2)).isEmpty();
   }

   private List findCrystalBlocks() {
      NonNullList positions = NonNullList.func_191196_a();
      positions.addAll((Collection)BlockInteractionHelper.getSphere(getPlayerPos(), ((Double)this.placeRange.getValue()).floatValue(), ((Double)this.placeRange.getValue()).intValue(), false, true, 0).stream().filter(this::canPlaceCrystal).collect(Collectors.toList()));
      return positions;
   }

   public static Vec3d interpolateEntity(Entity entity, float time) {
      return new Vec3d(entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)time, entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)time, entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)time);
   }

   public void onEnable() {
      this.fuckedPlayers = new HashSet();
      if (mc.field_71439_g == null) {
         this.disable();
      } else {
         if ((Boolean)this.fuckedMode.getValue() && ModuleManager.getModuleByName("Fucked Detector").isDisabled()) {
            this.flag = true;
            ModuleManager.getModuleByName("Fucked Detector").enable();
         }

         Command.sendChatMessage("we §l§2gaming§r");
         this.hitDelayCounter = (Integer)this.hitTickDelay.getValue();
         this.hue = 0.0F;
      }
   }

   public void onDisable() {
      if (this.flag) {
         ModuleManager.getModuleByName("Fucked Detector").disable();
         this.flag = false;
      }

      this.renderBlock = null;
      resetRotation();
      Command.sendChatMessage("we aint §l§4gaming§r no more");
   }

   private static enum RenderMode {
      SOLID,
      OUTLINE,
      UP,
      FULL;
   }
}
