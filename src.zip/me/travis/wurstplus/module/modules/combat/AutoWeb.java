package me.travis.wurstplus.module.modules.combat;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.travis.wurstplus.util.Friends;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

@Module.Info(
   name = "AutoWeb",
   category = Module.Category.COMBAT
)
public class AutoWeb extends Module {
   BlockPos head;
   BlockPos feet;
   private Setting delay = this.register(Settings.integerBuilder("Delay").withRange(0, 10).withValue((int)3).build());
   int d;
   public static EntityPlayer target;
   public static List targets;
   public static float yaw;
   public static float pitch;

   public boolean isInBlockRange(Entity target) {
      return target.func_70032_d(mc.field_71439_g) <= 4.0F;
   }

   public static boolean canBeClicked(BlockPos pos) {
      return mc.field_71441_e.func_180495_p(pos).func_177230_c().func_176209_a(mc.field_71441_e.func_180495_p(pos), false);
   }

   public boolean isValid(EntityPlayer entity) {
      return entity instanceof EntityPlayer && this.isInBlockRange(entity) && entity.func_110143_aJ() > 0.0F && !entity.field_70128_L && !entity.func_70005_c_().startsWith("Body #") && !Friends.isFriend(entity.func_70005_c_());
   }

   public void loadTargets() {
      Iterator var1 = mc.field_71441_e.field_73010_i.iterator();

      while(var1.hasNext()) {
         EntityPlayer player = (EntityPlayer)var1.next();
         if (!(player instanceof EntityPlayerSP)) {
            if (this.isValid(player)) {
               targets.add(player);
            } else if (targets.contains(player)) {
               targets.remove(player);
            }
         }
      }

   }

   private boolean isStackObby(ItemStack stack) {
      return stack != null && stack.func_77973_b() == Item.func_150899_d(30);
   }

   private boolean doesHotbarHaveWeb() {
      for(int i = 36; i < 45; ++i) {
         ItemStack stack = mc.field_71439_g.field_71069_bz.func_75139_a(i).func_75211_c();
         if (stack != null && this.isStackObby(stack)) {
            return true;
         }
      }

      return false;
   }

   public static Block getBlock(BlockPos pos) {
      return getState(pos).func_177230_c();
   }

   public static IBlockState getState(BlockPos pos) {
      return mc.field_71441_e.func_180495_p(pos);
   }

   public static boolean placeBlockLegit(BlockPos pos) {
      Vec3d eyesPos = new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + (double)mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v);
      Vec3d posVec = (new Vec3d(pos)).func_72441_c(0.5D, 0.5D, 0.5D);
      EnumFacing[] var3 = EnumFacing.values();
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         EnumFacing side = var3[var5];
         BlockPos neighbor = pos.func_177972_a(side);
         if (canBeClicked(neighbor)) {
            Vec3d hitVec = posVec.func_178787_e((new Vec3d(side.func_176730_m())).func_186678_a(0.5D));
            if (eyesPos.func_72436_e(hitVec) <= 36.0D) {
               mc.field_71442_b.func_187099_a(mc.field_71439_g, mc.field_71441_e, neighbor, side.func_176734_d(), hitVec, EnumHand.MAIN_HAND);
               mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);

               try {
                  TimeUnit.MILLISECONDS.sleep(10L);
               } catch (InterruptedException var10) {
                  var10.printStackTrace();
               }

               return true;
            }
         }
      }

      return false;
   }

   public void onUpdate() {
      if (!mc.field_71439_g.func_184587_cr()) {
         if (!this.isValid(target) || target == null) {
            this.updateTarget();
         }

         Iterator var1 = mc.field_71441_e.field_73010_i.iterator();

         while(var1.hasNext()) {
            EntityPlayer player = (EntityPlayer)var1.next();
            if (!(player instanceof EntityPlayerSP) && this.isValid(player) && player.func_70032_d(mc.field_71439_g) < target.func_70032_d(mc.field_71439_g)) {
               target = player;
               return;
            }
         }

         if (this.isValid(target) && mc.field_71439_g.func_70032_d(target) < 4.0F) {
            this.trap(target);
         } else {
            this.d = 0;
         }

      }
   }

   public void onEnable() {
      if (mc.field_71439_g == null) {
         this.disable();
      }
   }

   private void trap(EntityPlayer player) {
      if ((double)player.field_191988_bg == 0.0D && (double)player.field_70702_br == 0.0D && (double)player.field_191988_bg == 0.0D) {
         ++this.d;
      }

      if ((double)player.field_191988_bg != 0.0D || (double)player.field_70702_br != 0.0D || (double)player.field_191988_bg != 0.0D) {
         this.d = 0;
      }

      if (!this.doesHotbarHaveWeb()) {
         this.d = 0;
      }

      if (this.d == (Integer)this.delay.getValue() && this.doesHotbarHaveWeb()) {
         this.head = new BlockPos(player.field_70165_t, player.field_70163_u + 1.0D, player.field_70161_v);
         this.feet = new BlockPos(player.field_70165_t, player.field_70163_u, player.field_70161_v);

         for(int i = 36; i < 45; ++i) {
            ItemStack stack = mc.field_71439_g.field_71069_bz.func_75139_a(i).func_75211_c();
            if (stack != null && this.isStackObby(stack)) {
               int oldSlot = mc.field_71439_g.field_71071_by.field_70461_c;
               if (mc.field_71441_e.func_180495_p(this.head).func_185904_a().func_76222_j() || mc.field_71441_e.func_180495_p(this.feet).func_185904_a().func_76222_j()) {
                  mc.field_71439_g.field_71071_by.field_70461_c = i - 36;
                  if ((double)player.field_191988_bg != 0.0D && (double)player.field_70702_br != 0.0D) {
                     if (mc.field_71441_e.func_180495_p(this.head).func_185904_a().func_76222_j()) {
                        placeBlockLegit(this.head);
                     }

                     if (mc.field_71441_e.func_180495_p(this.feet).func_185904_a().func_76222_j()) {
                        placeBlockLegit(this.feet);
                     }
                  } else if (mc.field_71441_e.func_180495_p(this.head).func_185904_a().func_76222_j()) {
                     placeBlockLegit(this.head);
                  }

                  mc.field_71439_g.field_71071_by.field_70461_c = oldSlot;
                  this.d = 0;
                  break;
               }

               this.d = 0;
            }

            this.d = 0;
         }
      }

   }

   public void onDisable() {
      this.d = 0;
      yaw = mc.field_71439_g.field_70177_z;
      pitch = mc.field_71439_g.field_70125_A;
      target = null;
   }

   public void updateTarget() {
      Iterator var1 = mc.field_71441_e.field_73010_i.iterator();

      while(var1.hasNext()) {
         EntityPlayer player = (EntityPlayer)var1.next();
         if (!(player instanceof EntityPlayerSP) && !(player instanceof EntityPlayerSP) && this.isValid(player)) {
            target = player;
         }
      }

   }

   public EnumFacing getEnumFacing(float posX, float posY, float posZ) {
      return EnumFacing.func_176737_a(posX, posY, posZ);
   }

   public BlockPos getBlockPos(double x, double y, double z) {
      return new BlockPos(x, y, z);
   }
}
