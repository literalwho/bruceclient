package me.travis.wurstplus.module.modules.combat;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.module.ModuleManager;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.travis.wurstplus.util.WorldUtils;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemExpBottle;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

@Module.Info(
   name = "Auto Armor Repair",
   category = Module.Category.COMBAT
)
public class AutoArmorRepair extends Module {
   private Setting delay = this.register(Settings.integerBuilder("Delay").withMinimum(12).withValue((int)16).withMaximum(24).build());
   private Setting damage = this.register(Settings.integerBuilder("Heal Damage %").withMinimum(10).withValue((int)60).withMaximum(90).build());
   private int mostDamagedSlot;
   private int mostDamage;
   private int lastSlot;
   private int counter;
   private int armorCount;
   private int wait;
   private int[] slots;
   private boolean shouldThrow;
   private boolean shouldArmor;
   private boolean falg;

   protected void onEnable() {
      this.falg = false;
      this.mostDamage = -1;
      this.mostDamagedSlot = -1;
      this.shouldArmor = false;
      this.armorCount = 0;
      this.slots = new int[3];
      this.wait = 0;
      this.takeOffArmor();
      if (ModuleManager.getModuleByName("Tickplace").isEnabled()) {
         this.falg = true;
         ModuleManager.getModuleByName("Tickplace").disable();
      }

   }

   protected void onDisable() {
      if (this.falg) {
         ModuleManager.getModuleByName("Tickplace").enable();
      }

   }

   public void onUpdate() {
      if (mc.field_71439_g != null && !this.isDisabled() && !(mc.field_71462_r instanceof GuiContainer)) {
         if (this.shouldThrow) {
            WorldUtils.lookAtBlock(new BlockPos(mc.field_71439_g.func_180425_c().func_177982_a(0, -1, 0)));
            mc.field_71439_g.field_71071_by.field_70461_c = this.findXP();
            mc.field_71442_b.func_187101_a(mc.field_71439_g, mc.field_71441_e, EnumHand.MAIN_HAND);
            if (this.isRepaired() || this.counter > 40) {
               this.shouldThrow = false;
               this.shouldArmor = true;
               mc.field_71439_g.field_71071_by.field_70461_c = this.lastSlot;
               Command.sendChatMessage("done");
            }

            ++this.counter;
         }

         if (this.shouldArmor) {
            if (this.wait >= (Integer)this.delay.getValue()) {
               this.wait = 0;
               mc.field_71442_b.func_187098_a(0, this.slots[this.armorCount], 0, ClickType.QUICK_MOVE, mc.field_71439_g);
               mc.field_71442_b.func_78765_e();
               ++this.armorCount;
               if (this.armorCount > 2) {
                  this.armorCount = 0;
                  this.shouldArmor = false;
                  this.disable();
                  return;
               }
            }

            ++this.wait;
         }

      }
   }

   public int getMostDamagedSlot() {
      Iterator var1 = getArmor().entrySet().iterator();

      while(var1.hasNext()) {
         Entry armorSlot = (Entry)var1.next();
         ItemStack stack = (ItemStack)armorSlot.getValue();
         if (stack.func_77952_i() > this.mostDamage) {
            this.mostDamage = stack.func_77952_i();
            this.mostDamagedSlot = (Integer)armorSlot.getKey();
         }
      }

      return this.mostDamagedSlot;
   }

   public boolean isRepaired() {
      Iterator var1 = getArmor().entrySet().iterator();

      Entry armorSlot;
      ItemStack stack;
      do {
         if (!var1.hasNext()) {
            return false;
         }

         armorSlot = (Entry)var1.next();
         stack = (ItemStack)armorSlot.getValue();
      } while((Integer)armorSlot.getKey() != this.mostDamagedSlot);

      float percent = (float)(Integer)this.damage.getValue() / 100.0F;
      int dam = Math.round((float)stack.func_77958_k() * percent);
      int goods = stack.func_77958_k() - stack.func_77952_i();
      if (dam <= goods) {
         return true;
      } else {
         return false;
      }
   }

   public int findXP() {
      this.lastSlot = mc.field_71439_g.field_71071_by.field_70461_c;
      int slot = -1;

      for(int i = 0; i < 9; ++i) {
         ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
         if (stack != ItemStack.field_190927_a && stack.func_77973_b() instanceof ItemExpBottle) {
            slot = i;
            break;
         }
      }

      if (slot == -1) {
         Command.sendChatMessage("no xp");
         this.disable();
         return 1;
      } else {
         return slot;
      }
   }

   public boolean isSpace() {
      int spareSlots = 0;
      Iterator var2 = getInventory().entrySet().iterator();

      while(var2.hasNext()) {
         Entry invSlot = (Entry)var2.next();
         ItemStack stack = (ItemStack)invSlot.getValue();
         if (stack.func_77973_b() == Items.field_190931_a) {
            this.slots[spareSlots] = (Integer)invSlot.getKey();
            ++spareSlots;
            if (spareSlots > 2) {
               return true;
            }
         }
      }

      return false;
   }

   public void takeOffArmor() {
      if (this.isSpace()) {
         this.getMostDamagedSlot();
         if (this.mostDamagedSlot != -1) {
            Iterator var1 = getArmor().entrySet().iterator();

            while(var1.hasNext()) {
               Entry armorSlot = (Entry)var1.next();
               if ((Integer)armorSlot.getKey() != this.mostDamagedSlot) {
                  mc.field_71442_b.func_187098_a(0, (Integer)armorSlot.getKey(), 0, ClickType.QUICK_MOVE, mc.field_71439_g);
               }
            }

            this.counter = 0;
            this.shouldThrow = true;
            return;
         }
      }

      Command.sendChatMessage("Please ensure there is atleast 3 inv slots open!");
      this.disable();
   }

   private static Map getInventory() {
      return getInventorySlots(9, 44);
   }

   private static Map getArmor() {
      return getInventorySlots(5, 8);
   }

   private static Map getInventorySlots(int current, int last) {
      HashMap fullInventorySlots;
      for(fullInventorySlots = new HashMap(); current <= last; ++current) {
         fullInventorySlots.put(current, (ItemStack)mc.field_71439_g.field_71069_bz.func_75138_a().get(current));
      }

      return fullInventorySlots;
   }
}
