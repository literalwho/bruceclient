package me.travis.wurstplus.module.modules.combat;

import java.util.Iterator;
import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.module.ModuleManager;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.travis.wurstplus.util.BlockInteractionHelper;
import me.travis.wurstplus.util.Wrapper;
import net.minecraft.block.BlockObsidian;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

@Module.Info(
   name = "Surround",
   category = Module.Category.COMBAT
)
public class Surround extends Module {
   private final Vec3d[] surroundTargets = new Vec3d[]{new Vec3d(1.0D, 0.0D, 0.0D), new Vec3d(0.0D, 0.0D, 1.0D), new Vec3d(-1.0D, 0.0D, 0.0D), new Vec3d(0.0D, 0.0D, -1.0D), new Vec3d(1.0D, -1.0D, 0.0D), new Vec3d(0.0D, -1.0D, 1.0D), new Vec3d(-1.0D, -1.0D, 0.0D), new Vec3d(0.0D, -1.0D, -1.0D), new Vec3d(0.0D, -1.0D, 0.0D)};
   private Setting triggerable = this.register(Settings.b("Triggerable", true));
   private Setting timeoutTicks = this.register(Settings.integerBuilder("TimeoutTicks").withMinimum(1).withValue((int)20).withMaximum(100).build());
   private Setting blocksPerTick = this.register(Settings.integerBuilder("Blocks per Tick").withMinimum(1).withValue((int)4).withMaximum(9).build());
   private Setting rotate = this.register(Settings.b("Rotate", true));
   private Setting hybrid = this.register(Settings.b("Hybrid", true));
   private Setting announceUsage = this.register(Settings.b("Announce Usage", true));
   private int playerHotbarSlot = -1;
   private int lastHotbarSlot = -1;
   private int offsetStep = 0;
   private int totalTickRuns = 0;
   private boolean isSneaking = false;
   private boolean flag = false;
   private int yHeight;

   protected void onEnable() {
      this.flag = false;
      if (mc.field_71439_g == null) {
         this.disable();
      } else {
         this.playerHotbarSlot = Wrapper.getPlayer().field_71071_by.field_70461_c;
         this.lastHotbarSlot = -1;
         this.yHeight = (int)Math.round(mc.field_71439_g.field_70163_u);
         if (ModuleManager.getModuleByName("Unco Aura").isEnabled()) {
            this.flag = true;
            ModuleManager.getModuleByName("Unco Aura").disable();
         }

         if ((Boolean)this.announceUsage.getValue()) {
            Command.sendChatMessage("we surrounding");
         }

      }
   }

   protected void onDisable() {
      if (mc.field_71439_g != null) {
         if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
            Wrapper.getPlayer().field_71071_by.field_70461_c = this.playerHotbarSlot;
         }

         if (this.isSneaking) {
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.STOP_SNEAKING));
            this.isSneaking = false;
         }

         if (this.flag) {
            ModuleManager.getModuleByName("Unco Aura").enable();
            this.flag = false;
         }

         this.playerHotbarSlot = -1;
         this.lastHotbarSlot = -1;
         if ((Boolean)this.announceUsage.getValue()) {
            Command.sendChatMessage("we aint surrounding no more");
         }

      }
   }

   public void onUpdate() {
      if (this.isDisabled() && this.flag) {
         ModuleManager.getModuleByName("Unco Aura").enable();
         this.flag = false;
      }

      if (mc.field_71439_g != null) {
         if ((Boolean)this.hybrid.getValue() && (int)Math.round(mc.field_71439_g.field_70163_u) != this.yHeight) {
            this.disable();
         }

         if ((Boolean)this.triggerable.getValue() && this.totalTickRuns >= (Integer)this.timeoutTicks.getValue()) {
            this.totalTickRuns = 0;
            this.disable();
         } else {
            int blocksPlaced;
            for(blocksPlaced = 0; blocksPlaced < (Integer)this.blocksPerTick.getValue(); ++this.offsetStep) {
               if (this.offsetStep >= this.surroundTargets.length) {
                  this.offsetStep = 0;
                  break;
               }

               BlockPos offsetPos = new BlockPos(this.surroundTargets[this.offsetStep]);
               BlockPos targetPos = (new BlockPos(mc.field_71439_g.func_174791_d())).func_177982_a(offsetPos.field_177962_a, offsetPos.field_177960_b, offsetPos.field_177961_c);
               boolean shouldTryToPlace = true;
               if (!Wrapper.getWorld().func_180495_p(targetPos).func_185904_a().func_76222_j()) {
                  shouldTryToPlace = false;
               }

               Iterator var5 = mc.field_71441_e.func_72839_b((Entity)null, new AxisAlignedBB(targetPos)).iterator();

               while(var5.hasNext()) {
                  Entity entity = (Entity)var5.next();
                  if (!(entity instanceof EntityItem) && !(entity instanceof EntityXPOrb)) {
                     shouldTryToPlace = false;
                     break;
                  }
               }

               if (shouldTryToPlace && this.placeBlock(targetPos)) {
                  ++blocksPlaced;
               }
            }

            if (blocksPlaced > 0 && this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
               Wrapper.getPlayer().field_71071_by.field_70461_c = this.playerHotbarSlot;
               this.lastHotbarSlot = this.playerHotbarSlot;
            }

            ++this.totalTickRuns;
         }
      }
   }

   private boolean placeBlock(BlockPos pos) {
      if (!mc.field_71441_e.func_180495_p(pos).func_185904_a().func_76222_j()) {
         return false;
      } else if (!BlockInteractionHelper.checkForNeighbours(pos)) {
         return false;
      } else {
         EnumFacing[] var2 = EnumFacing.values();
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            EnumFacing side = var2[var4];
            BlockPos neighbor = pos.func_177972_a(side);
            EnumFacing side2 = side.func_176734_d();
            if (BlockInteractionHelper.canBeClicked(neighbor)) {
               int obiSlot = this.findObiInHotbar();
               if (obiSlot == -1) {
                  this.disable();
                  return false;
               }

               if (this.lastHotbarSlot != obiSlot) {
                  Wrapper.getPlayer().field_71071_by.field_70461_c = obiSlot;
                  this.lastHotbarSlot = obiSlot;
               }

               if (BlockInteractionHelper.blackList.contains(mc.field_71441_e.func_180495_p(neighbor).func_177230_c())) {
                  mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.START_SNEAKING));
                  this.isSneaking = true;
               }

               Vec3d hitVec = (new Vec3d(neighbor)).func_72441_c(0.5D, 0.5D, 0.5D).func_178787_e((new Vec3d(side2.func_176730_m())).func_186678_a(0.5D));
               if ((Boolean)this.rotate.getValue()) {
                  BlockInteractionHelper.faceVectorPacketInstant(hitVec);
               }

               mc.field_71442_b.func_187099_a(mc.field_71439_g, mc.field_71441_e, neighbor, side2, hitVec, EnumHand.MAIN_HAND);
               mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
               return true;
            }
         }

         return false;
      }
   }

   private int findObiInHotbar() {
      int slot = -1;

      for(int i = 0; i < 9; ++i) {
         ItemStack stack = Wrapper.getPlayer().field_71071_by.func_70301_a(i);
         if (stack != ItemStack.field_190927_a && stack.func_77973_b() instanceof ItemBlock && ((ItemBlock)stack.func_77973_b()).func_179223_d() instanceof BlockObsidian) {
            slot = i;
            break;
         }
      }

      return slot;
   }
}
