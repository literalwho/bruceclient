package me.travis.wurstplus.module.modules.combat;

import java.util.Iterator;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.travis.wurstplus.util.Friends;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.EnumHand;

@Module.Info(
   name = "Travis Aura",
   category = Module.Category.COMBAT
)
public class KillAura extends Module {
   private Setting attackPlayers = this.register(Settings.b("Players", true));
   private Setting hitRange = this.register(Settings.d("Hit Range", 5.5D));
   private Setting delay = this.register(Settings.integerBuilder("Delay").withMinimum(0).withValue((int)6).withMaximum(10).build());
   private Setting switchTo32k = this.register(Settings.b("32k Switch", true));
   private Setting onlyUse32k = this.register(Settings.b("32k Only", false));
   private int hasWaited = 0;

   public void onUpdate() {
      if (this.isEnabled() && !mc.field_71439_g.field_70128_L && mc.field_71441_e != null) {
         if (this.hasWaited < (Integer)this.delay.getValue()) {
            ++this.hasWaited;
         } else {
            this.hasWaited = 0;
            Iterator var1 = mc.field_71441_e.field_72996_f.iterator();

            while(true) {
               Entity entity;
               do {
                  do {
                     do {
                        do {
                           do {
                              do {
                                 do {
                                    if (!var1.hasNext()) {
                                       return;
                                    }

                                    entity = (Entity)var1.next();
                                 } while(!(entity instanceof EntityLivingBase));
                              } while(entity == mc.field_71439_g);
                           } while((double)mc.field_71439_g.func_70032_d(entity) > (Double)this.hitRange.getValue());
                        } while(((EntityLivingBase)entity).func_110143_aJ() <= 0.0F);
                     } while(!(entity instanceof EntityPlayer) && (Boolean)this.attackPlayers.getValue());
                  } while(entity instanceof EntityPlayer && Friends.isFriend(entity.func_70005_c_()));
               } while(!this.checkSharpness(mc.field_71439_g.func_184614_ca()) && (Boolean)this.onlyUse32k.getValue());

               this.attack(entity);
            }
         }
      }
   }

   private boolean checkSharpness(ItemStack item) {
      if (item.func_77978_p() == null) {
         return false;
      } else {
         NBTTagList enchants = (NBTTagList)item.func_77978_p().func_74781_a("ench");
         if (enchants == null) {
            return false;
         } else {
            for(int i = 0; i < enchants.func_74745_c(); ++i) {
               NBTTagCompound enchant = enchants.func_150305_b(i);
               if (enchant.func_74762_e("id") == 16) {
                  int lvl = enchant.func_74762_e("lvl");
                  if (lvl >= 42) {
                     return true;
                  }
                  break;
               }
            }

            return false;
         }
      }
   }

   public void attack(Entity e) {
      boolean holding32k = false;
      if (this.checkSharpness(mc.field_71439_g.func_184614_ca())) {
         holding32k = true;
      }

      if ((Boolean)this.switchTo32k.getValue() && !holding32k) {
         int newSlot = -1;

         for(int i = 0; i < 9; ++i) {
            ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (stack != ItemStack.field_190927_a && this.checkSharpness(stack)) {
               newSlot = i;
               break;
            }
         }

         if (newSlot != -1) {
            mc.field_71439_g.field_71071_by.field_70461_c = newSlot;
            holding32k = true;
         }
      }

      if (!(Boolean)this.onlyUse32k.getValue() || holding32k) {
         mc.field_71442_b.func_78764_a(mc.field_71439_g, e);
         mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
      }
   }
}
