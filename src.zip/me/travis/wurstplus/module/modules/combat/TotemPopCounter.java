package me.travis.wurstplus.module.modules.combat;

import java.util.HashMap;
import java.util.Iterator;
import java.util.function.Predicate;
import me.travis.wurstplus.wurstplusMod;
import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.event.events.TotemPopEvent;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.SPacketEntityStatus;

@Module.Info(
   name = "TotemPopCounter",
   description = "Counts the times your enemy pops",
   category = Module.Category.COMBAT
)
public class TotemPopCounter extends Module {
   private HashMap popList = new HashMap();
   private Setting mode;
   @EventHandler
   public Listener totemPopEvent;
   @EventHandler
   public Listener totemPopListener;

   public TotemPopCounter() {
      this.mode = this.register(Settings.e("Colour", TotemPopCounter.colour.DARK_PURPLE));
      this.totemPopEvent = new Listener((event) -> {
         if (this.popList == null) {
            this.popList = new HashMap();
         }

         if (this.popList.get(event.getEntity().func_70005_c_()) == null) {
            this.popList.put(event.getEntity().func_70005_c_(), 1);
            Command.sendChatMessage(this.colourchoice() + event.getEntity().func_70005_c_() + " popped " + 1 + " totem");
         } else if (this.popList.get(event.getEntity().func_70005_c_()) != null) {
            int popCounter = (Integer)this.popList.get(event.getEntity().func_70005_c_());
            ++popCounter;
            this.popList.put(event.getEntity().func_70005_c_(), popCounter);
            Command.sendChatMessage(this.colourchoice() + event.getEntity().func_70005_c_() + " popped " + popCounter + " totems kek");
         }

      }, new Predicate[0]);
      this.totemPopListener = new Listener((event) -> {
         if (mc.field_71441_e != null && mc.field_71439_g != null) {
            if (event.getPacket() instanceof SPacketEntityStatus) {
               SPacketEntityStatus packet = (SPacketEntityStatus)event.getPacket();
               if (packet.func_149160_c() == 35) {
                  Entity entity = packet.func_149161_a(mc.field_71441_e);
                  wurstplusMod.EVENT_BUS.post(new TotemPopEvent(entity));
               }
            }

         }
      }, new Predicate[0]);
   }

   public void onUpdate() {
      Iterator var1 = mc.field_71441_e.field_73010_i.iterator();

      while(var1.hasNext()) {
         EntityPlayer player = (EntityPlayer)var1.next();
         if (player.func_110143_aJ() <= 0.0F && this.popList.containsKey(player.func_70005_c_())) {
            Command.sendChatMessage(this.colourchoice() + player.func_70005_c_() + " died after popping " + this.popList.get(player.func_70005_c_()) + " totems Ezzzzz");
            this.popList.remove(player.func_70005_c_(), this.popList.get(player.func_70005_c_()));
         }
      }

   }

   private String colourchoice() {
      switch((TotemPopCounter.colour)this.mode.getValue()) {
      case BLACK:
         return "&0";
      case RED:
         return "&c";
      case AQUA:
         return "&b";
      case BLUE:
         return "&9";
      case GOLD:
         return "&6";
      case GRAY:
         return "&7";
      case WHITE:
         return "&f";
      case GREEN:
         return "&a";
      case YELLOW:
         return "&e";
      case DARK_RED:
         return "&4";
      case DARK_AQUA:
         return "&3";
      case DARK_BLUE:
         return "&1";
      case DARK_GRAY:
         return "&8";
      case DARK_GREEN:
         return "&2";
      case DARK_PURPLE:
         return "&5";
      case LIGHT_PURPLE:
         return "&d";
      default:
         return "";
      }
   }

   private static enum colour {
      BLACK,
      DARK_BLUE,
      DARK_GREEN,
      DARK_AQUA,
      DARK_RED,
      DARK_PURPLE,
      GOLD,
      GRAY,
      DARK_GRAY,
      BLUE,
      GREEN,
      AQUA,
      RED,
      LIGHT_PURPLE,
      YELLOW,
      WHITE;
   }
}
