package me.travis.wurstplus.module.modules.combat;

import java.util.OptionalInt;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

@Module.Info(
   name = "AutoTotem",
   category = Module.Category.COMBAT
)
public class AutoTotem extends Module {
   private Setting soft = this.register(Settings.b("Soft", true));
   private Setting healthSwitch = this.register(Settings.integerBuilder("Health Switch").withRange(1, 20).withValue((int)4).withVisibility((o) -> {
      return (Boolean)this.soft.getValue();
   }).build());

   public void onUpdate() {
      if (mc.field_71439_g != null) {
         if (!(mc.field_71462_r instanceof GuiContainer)) {
            if ((Boolean)this.soft.getValue()) {
               if (mc.field_71439_g.func_110143_aJ() + mc.field_71439_g.func_110139_bj() <= (float)(Integer)this.healthSwitch.getValue() && this.getOffhand().func_77973_b() == Items.field_190929_cY) {
                  return;
               }

               if (!this.getOffhand().func_190926_b() && mc.field_71439_g.func_110143_aJ() + mc.field_71439_g.func_110139_bj() >= (float)(Integer)this.healthSwitch.getValue()) {
                  return;
               }

               this.findItem(Items.field_190929_cY).ifPresent((slot) -> {
                  this.invPickup(slot);
                  this.invPickup(45);
                  this.invPickup(slot);
               });
            } else {
               if (this.getOffhand().func_77973_b() == Items.field_190929_cY) {
                  return;
               }

               this.findItem(Items.field_190929_cY).ifPresent((slot) -> {
                  this.invPickup(slot);
                  this.invPickup(45);
                  this.invPickup(slot);
               });
            }

         }
      }
   }

   private void invPickup(int slot) {
      mc.field_71442_b.func_187098_a(0, slot, 0, ClickType.PICKUP, mc.field_71439_g);
   }

   private OptionalInt findItem(Item ofType) {
      for(int i = 44; i >= 9; --i) {
         if (mc.field_71439_g.field_71069_bz.func_75139_a(i).func_75211_c().func_77973_b() == ofType) {
            return OptionalInt.of(i);
         }
      }

      return OptionalInt.empty();
   }

   private ItemStack getOffhand() {
      return mc.field_71439_g.func_184582_a(EntityEquipmentSlot.OFFHAND);
   }
}
