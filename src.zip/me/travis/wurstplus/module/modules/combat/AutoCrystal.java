package me.travis.wurstplus.module.modules.combat;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.event.events.RenderEvent;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.module.ModuleManager;
import me.travis.wurstplus.module.modules.chat.AutoEZ;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.travis.wurstplus.util.EntityUtil;
import me.travis.wurstplus.util.Friends;
import me.travis.wurstplus.util.wurstplusTessellator;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.potion.Potion;
import net.minecraft.util.CombatRules;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Explosion;

@Module.Info(
   name = "AutoCrystal",
   category = Module.Category.CrystalPVP
)
public class AutoCrystal extends Module {
   private Setting debug = this.register(Settings.b("Debug", false));
   private Setting place = this.register(Settings.b("Place", true));
   private Setting explode = this.register(Settings.b("Explode", true));
   private Setting onlyOwn = this.register(Settings.b("Only Explode Own", true));
   private Setting antiWeakness = this.register(Settings.b("Anti Weakness", true));
   private Setting offhand = this.register(Settings.b("Smart Offhand", false));
   private Setting offhandHealth = this.register(Settings.integerBuilder("Offhand Min Health").withMinimum(0).withValue((int)3).withMaximum(20).withVisibility((o) -> {
      return (Boolean)this.offhand.getValue();
   }).build());
   private Setting hitTickDelay = this.register(Settings.integerBuilder("Hit Delay").withMinimum(0).withValue((int)3).withMaximum(20).build());
   private Setting placeTickDelay = this.register(Settings.integerBuilder("Place Delay").withMinimum(0).withValue((int)3).withMaximum(20).build());
   private Setting hitRange = this.register(Settings.doubleBuilder("Hit Range").withMinimum(0.0D).withValue((Number)5.5D).build());
   private Setting placeRange = this.register(Settings.doubleBuilder("Place Range").withMinimum(0.0D).withValue((Number)3.5D).build());
   private Setting minDamage = this.register(Settings.doubleBuilder("Min Damage").withMinimum(0.0D).withValue((Number)2.0D).withMaximum(20.0D).build());
   private Setting maxSelfDamage = this.register(Settings.doubleBuilder("Max Self Damage").withMinimum(0.0D).withValue((Number)8.0D).withMaximum(20.0D).build());
   private Setting rotate = this.register(Settings.b("Spoof Rotations", false));
   private Setting tabbottMode = this.register(Settings.b("Tabbott Mode", false));
   private Setting placeMode;
   private Setting renderMode;
   private Setting alpha;
   private Setting rainbow;
   private Setting satuation;
   private Setting brightness;
   private Setting speed;
   private Setting red;
   private Setting green;
   private Setting blue;
   private BlockPos renderBlock;
   private boolean switchCooldown;
   private boolean isAttacking;
   private static boolean togglePitch = false;
   private static boolean isSpoofingAngles;
   private static double yaw;
   private static double pitch;
   private int oldSlot;
   private int newSlot;
   private int hitDelayCounter;
   private int placeDelayCounter;
   EntityEnderCrystal crystal;
   private float hue;
   private Color rgbc;
   @EventHandler
   private Listener packetListener;

   public AutoCrystal() {
      this.placeMode = this.register(Settings.e("Place Mode", AutoCrystal.PlaceMode.PLACEFIRST));
      this.renderMode = this.register(Settings.e("Render Mode", AutoCrystal.RenderMode.UP));
      this.alpha = this.register(Settings.integerBuilder("Transparency").withRange(0, 255).withValue((int)70).build());
      this.rainbow = this.register(Settings.b("RainbowMode", false));
      this.satuation = this.register(Settings.floatBuilder("Saturation").withRange(0.0F, 1.0F).withValue((Number)0.6F).withVisibility((o) -> {
         return (Boolean)this.rainbow.getValue();
      }).build());
      this.brightness = this.register(Settings.floatBuilder("Brightness").withRange(0.0F, 1.0F).withValue((Number)0.6F).withVisibility((o) -> {
         return (Boolean)this.rainbow.getValue();
      }).build());
      this.speed = this.register(Settings.integerBuilder("Speed").withRange(0, 10).withValue((int)2).withVisibility((o) -> {
         return (Boolean)this.rainbow.getValue();
      }).build());
      this.red = this.register(Settings.integerBuilder("Red").withRange(0, 255).withValue((int)255).withVisibility((o) -> {
         return !(Boolean)this.rainbow.getValue();
      }).build());
      this.green = this.register(Settings.integerBuilder("Green").withRange(0, 255).withValue((int)255).withVisibility((o) -> {
         return !(Boolean)this.rainbow.getValue();
      }).build());
      this.blue = this.register(Settings.integerBuilder("Blue").withRange(0, 255).withValue((int)255).withVisibility((o) -> {
         return !(Boolean)this.rainbow.getValue();
      }).build());
      this.switchCooldown = false;
      this.isAttacking = false;
      this.oldSlot = -1;
      this.packetListener = new Listener((event) -> {
         if ((Boolean)this.rotate.getValue()) {
            Packet packet = event.getPacket();
            if (packet instanceof CPacketPlayer && isSpoofingAngles) {
               ((CPacketPlayer)packet).field_149476_e = (float)yaw;
               ((CPacketPlayer)packet).field_149473_f = (float)pitch;
            }

         }
      }, new Predicate[0]);
   }

   public void onUpdate() {
      if (mc.field_71439_g.func_110143_aJ() >= (float)(Integer)this.offhandHealth.getValue() && (Boolean)this.offhand.getValue()) {
         this.placeCrystalOffhand();
      }

      if (((AutoCrystal.PlaceMode)this.placeMode.getValue()).equals(AutoCrystal.PlaceMode.PLACEFIRST)) {
         if (this.placeDelayCounter >= (Integer)this.placeTickDelay.getValue()) {
            this.placeCrystal();
         }

         if (this.hitDelayCounter >= (Integer)this.hitTickDelay.getValue()) {
            this.breakCrystal();
         }
      } else {
         if (this.hitDelayCounter >= (Integer)this.hitTickDelay.getValue()) {
            this.breakCrystal();
         }

         if (this.placeDelayCounter >= (Integer)this.placeTickDelay.getValue()) {
            this.placeCrystal();
         }
      }

      ++this.placeDelayCounter;
      ++this.hitDelayCounter;
      resetRotation();
   }

   public EntityEnderCrystal getBestCrystal(double range) {
      int totems = this.getTotems();
      double bestDam = 0.0D;
      double minDam = (Double)this.minDamage.getValue();
      EntityEnderCrystal bestCrystal = null;
      Entity target = null;
      List players = (List)mc.field_71441_e.field_73010_i.stream().filter((entityPlayer) -> {
         return !Friends.isFriend(entityPlayer.func_70005_c_());
      }).collect(Collectors.toList());
      List crystals = (List)mc.field_71441_e.field_72996_f.stream().filter((entity) -> {
         return entity instanceof EntityEnderCrystal;
      }).collect(Collectors.toList());
      Iterator var12 = crystals.iterator();

      label99:
      while(true) {
         Entity crystal;
         do {
            do {
               if (!var12.hasNext()) {
                  if (ModuleManager.getModuleByName("AutoEZ").isEnabled() && target != null) {
                     AutoEZ autoGG = (AutoEZ)ModuleManager.getModuleByName("AutoEZ");
                     autoGG.addTargetedPlayer(target.func_70005_c_());
                  }

                  players.clear();
                  crystals.clear();
                  return bestCrystal;
               }

               crystal = (Entity)var12.next();
            } while((double)mc.field_71439_g.func_70032_d(crystal) > range);
         } while(crystal == null);

         Iterator var14 = players.iterator();

         while(true) {
            Entity player;
            EntityPlayer testTarget;
            do {
               while(true) {
                  do {
                     do {
                        if (!var14.hasNext()) {
                           continue label99;
                        }

                        player = (Entity)var14.next();
                     } while(player == mc.field_71439_g);
                  } while(!(player instanceof EntityPlayer));

                  testTarget = (EntityPlayer)player;
                  if (!testTarget.field_70128_L && testTarget.func_110143_aJ() > 0.0F && testTarget.func_174818_b(mc.field_71439_g.func_180425_c()) < 169.0D) {
                     break;
                  }

                  if ((Boolean)this.debug.getValue()) {
                     Command.sendChatMessage("passing - target shit");
                  }
               }
            } while(testTarget.func_70068_e(crystal) >= 169.0D);

            if (testTarget.func_110143_aJ() < 8.0F && (Boolean)this.tabbottMode.getValue()) {
               minDam = 0.1D;
            }

            double targetDamage = (double)calculateDamage(crystal.field_70165_t, crystal.field_70163_u, crystal.field_70161_v, testTarget);
            double selfDamage = (double)calculateDamage(crystal.field_70165_t, crystal.field_70163_u, crystal.field_70161_v, mc.field_71439_g);
            float healthTarget = testTarget.func_110143_aJ() + testTarget.func_110139_bj();
            float healthSelf = mc.field_71439_g.func_110143_aJ() + mc.field_71439_g.func_110139_bj();
            if ((targetDamage < minDam || selfDamage > targetDamage && targetDamage < (double)healthTarget || selfDamage > (Double)this.maxSelfDamage.getValue() || (double)healthSelf < 0.5D && totems == 0) && (Boolean)this.debug.getValue()) {
               Command.sendChatMessage("passing - too much self damage / too little damage");
            }

            if (targetDamage > bestDam) {
               if ((Boolean)this.debug.getValue()) {
                  Command.sendChatMessage("lookin good");
               }

               target = player;
               bestDam = targetDamage;
               bestCrystal = (EntityEnderCrystal)crystal;
            }
         }
      }
   }

   public BlockPos getBestBlock() {
      List blocks = this.findCrystalBlocks((Double)this.placeRange.getValue());
      List players = (List)mc.field_71441_e.field_73010_i.stream().filter((entityPlayer) -> {
         return !Friends.isFriend(entityPlayer.func_70005_c_());
      }).collect(Collectors.toList());
      BlockPos targetBlock = null;
      EntityPlayer target = null;
      int totems = this.getTotems();
      double bestDam = 0.0D;
      double minDam = (Double)this.minDamage.getValue();
      Iterator var10 = players.iterator();

      label91:
      while(true) {
         EntityPlayer testTarget;
         do {
            do {
               do {
                  Entity player;
                  do {
                     do {
                        if (!var10.hasNext()) {
                           if (target == null) {
                              this.renderBlock = null;
                              resetRotation();
                           }

                           return targetBlock;
                        }

                        player = (Entity)var10.next();
                     } while(player == mc.field_71439_g);
                  } while(!(player instanceof EntityPlayer));

                  testTarget = (EntityPlayer)player;
               } while(testTarget.field_70128_L);
            } while(testTarget.func_110143_aJ() <= 0.0F);
         } while(testTarget.func_174818_b(mc.field_71439_g.func_180425_c()) >= 169.0D);

         Iterator var13 = blocks.iterator();

         while(true) {
            BlockPos blockPos;
            double targetDamage;
            double selfDamage;
            float healthSelf;
            do {
               float healthTarget;
               do {
                  do {
                     do {
                        do {
                           if (!var13.hasNext()) {
                              continue label91;
                           }

                           blockPos = (BlockPos)var13.next();
                        } while(testTarget.func_174818_b(blockPos) >= 169.0D);

                        targetDamage = (double)calculateDamage((double)blockPos.field_177962_a + 0.5D, (double)(blockPos.field_177960_b + 1), (double)blockPos.field_177961_c + 0.5D, testTarget);
                        selfDamage = (double)calculateDamage((double)blockPos.field_177962_a + 0.5D, (double)(blockPos.field_177960_b + 1), (double)blockPos.field_177961_c + 0.5D, mc.field_71439_g);
                        healthTarget = testTarget.func_110143_aJ() + testTarget.func_110139_bj();
                        healthSelf = mc.field_71439_g.func_110143_aJ() + mc.field_71439_g.func_110139_bj();
                        if (testTarget.func_110143_aJ() < 8.0F && (Boolean)this.tabbottMode.getValue()) {
                           minDam = 0.1D;
                        }
                     } while(targetDamage < minDam);
                  } while(selfDamage > targetDamage && targetDamage < (double)healthTarget);
               } while(selfDamage > (Double)this.maxSelfDamage.getValue());
            } while((double)healthSelf < 0.5D && totems == 0);

            if (targetDamage > bestDam) {
               bestDam = targetDamage;
               targetBlock = blockPos;
               target = testTarget;
            }
         }
      }
   }

   public void breakCrystal() {
      this.crystal = this.getBestCrystal((Double)this.hitRange.getValue());
      if (this.crystal != null) {
         if ((Boolean)this.explode.getValue()) {
            if ((Boolean)this.antiWeakness.getValue() && mc.field_71439_g.func_70644_a(MobEffects.field_76437_t)) {
               if (!this.isAttacking) {
                  this.oldSlot = mc.field_71439_g.field_71071_by.field_70461_c;
                  this.isAttacking = true;
               }

               this.newSlot = -1;

               for(int i = 0; i < 9; ++i) {
                  ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
                  if (stack != ItemStack.field_190927_a) {
                     if (stack.func_77973_b() instanceof ItemSword) {
                        this.newSlot = i;
                        break;
                     }

                     if (stack.func_77973_b() instanceof ItemTool) {
                        this.newSlot = i;
                        break;
                     }
                  }
               }

               if (this.newSlot != -1) {
                  mc.field_71439_g.field_71071_by.field_70461_c = this.newSlot;
                  this.switchCooldown = true;
               }
            }

            if ((Boolean)this.debug.getValue()) {
               Command.sendChatMessage("hitting crystal");
            }

            this.lookAtPacket(this.crystal.field_70165_t, this.crystal.field_70163_u, this.crystal.field_70161_v, mc.field_71439_g);
            mc.field_71442_b.func_78764_a(mc.field_71439_g, this.crystal);
            mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
         }

         this.hitDelayCounter = 0;
      }
   }

   public void placeCrystal() {
      if (this.oldSlot != -1) {
         mc.field_71439_g.field_71071_by.field_70461_c = this.oldSlot;
         this.oldSlot = -1;
      }

      this.isAttacking = false;
      int crystalSlot = mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP ? mc.field_71439_g.field_71071_by.field_70461_c : -1;
      if (crystalSlot == -1) {
         for(int i = 0; i < 9; ++i) {
            if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() == Items.field_185158_cP) {
               crystalSlot = i;
               break;
            }
         }
      }

      boolean offhand = false;
      if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) {
         offhand = true;
      } else if (crystalSlot == -1) {
         return;
      }

      BlockPos targetBlock = this.getBestBlock();
      if (targetBlock != null) {
         this.renderBlock = targetBlock;
         if ((Boolean)this.place.getValue()) {
            if (!offhand && mc.field_71439_g.field_71071_by.field_70461_c != crystalSlot) {
               mc.field_71439_g.field_71071_by.field_70461_c = crystalSlot;
               resetRotation();
               this.switchCooldown = true;
            }

            this.lookAtPacket((double)targetBlock.field_177962_a + 0.5D, (double)targetBlock.field_177960_b - 0.5D, (double)targetBlock.field_177961_c + 0.5D, mc.field_71439_g);
            RayTraceResult result = mc.field_71441_e.func_72933_a(new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + (double)mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v), new Vec3d((double)targetBlock.field_177962_a + 0.5D, (double)targetBlock.field_177960_b - 0.5D, (double)targetBlock.field_177961_c + 0.5D));
            EnumFacing f = result != null && result.field_178784_b != null ? result.field_178784_b : EnumFacing.UP;
            if (this.switchCooldown) {
               this.switchCooldown = false;
               return;
            }

            if ((Boolean)this.debug.getValue()) {
               Command.sendChatMessage("placing crystal");
            }

            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItemOnBlock(targetBlock, f, offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0F, 0.0F, 0.0F));
         }

         if ((Boolean)this.rotate.getValue() && isSpoofingAngles) {
            if (togglePitch) {
               mc.field_71439_g.field_70125_A = (float)((double)mc.field_71439_g.field_70125_A + 4.0E-4D);
               togglePitch = false;
            } else {
               mc.field_71439_g.field_70125_A = (float)((double)mc.field_71439_g.field_70125_A - 4.0E-4D);
               togglePitch = true;
            }
         }

         this.placeDelayCounter = 0;
      }
   }

   private void placeCrystalOffhand() {
      int slot = this.findCrystalsInHotbar();
      if (this.getOffhand().func_77973_b() != Items.field_185158_cP && slot != -1) {
         if ((Boolean)this.debug.getValue()) {
            Command.sendChatMessage("swapping " + mc.field_71439_g.field_71071_by.func_70301_a(45).func_77973_b());
            Command.sendChatMessage("with " + mc.field_71439_g.field_71071_by.func_70301_a(slot).func_77973_b());
         }

         this.invPickup(slot);
         this.invPickup(45);
         this.invPickup(slot);
      }
   }

   private void invPickup(int slot) {
      mc.field_71442_b.func_187098_a(0, slot, 0, ClickType.PICKUP, mc.field_71439_g);
   }

   private ItemStack getOffhand() {
      return mc.field_71439_g.func_184582_a(EntityEquipmentSlot.OFFHAND);
   }

   public int getTotems() {
      return this.offhand() + mc.field_71439_g.field_71071_by.field_70462_a.stream().filter((itemStack) -> {
         return itemStack.func_77973_b() == Items.field_190929_cY;
      }).mapToInt(ItemStack::func_190916_E).sum();
   }

   public int offhand() {
      return mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY ? 1 : 0;
   }

   public void onWorldRender(RenderEvent event) {
      if (mc.func_175598_ae().field_78733_k != null) {
         if (this.renderBlock != null) {
            if ((Boolean)this.rainbow.getValue()) {
               this.rgbc = Color.getHSBColor(this.hue, (Float)this.satuation.getValue(), (Float)this.brightness.getValue());
               this.drawBlock(this.renderBlock, this.rgbc.getRed(), this.rgbc.getGreen(), this.rgbc.getBlue());
               if (this.hue + (float)(Integer)this.speed.getValue() / 200.0F > 1.0F) {
                  this.hue = 0.0F;
               } else {
                  this.hue += (float)(Integer)this.speed.getValue() / 200.0F;
               }
            } else {
               this.drawBlock(this.renderBlock, (Integer)this.red.getValue(), (Integer)this.green.getValue(), (Integer)this.blue.getValue());
            }
         }

      }
   }

   private int findCrystalsInHotbar() {
      int slot = -1;

      for(int i = 44; i >= 9; --i) {
         if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() == Items.field_185158_cP) {
            slot = i;
            break;
         }
      }

      return slot;
   }

   private void drawBlock(BlockPos blockPos, int r, int g, int b) {
      Color color = new Color(r, g, b, (Integer)this.alpha.getValue());
      wurstplusTessellator.prepare(7);
      if (((AutoCrystal.RenderMode)this.renderMode.getValue()).equals(AutoCrystal.RenderMode.UP)) {
         wurstplusTessellator.drawBox(blockPos, color.getRGB(), 2);
      } else if (((AutoCrystal.RenderMode)this.renderMode.getValue()).equals(AutoCrystal.RenderMode.SOLID)) {
         wurstplusTessellator.drawBox(blockPos, color.getRGB(), 63);
      } else {
         IBlockState iBlockState2;
         Vec3d interp2;
         if (((AutoCrystal.RenderMode)this.renderMode.getValue()).equals(AutoCrystal.RenderMode.OUTLINE)) {
            iBlockState2 = mc.field_71441_e.func_180495_p(blockPos);
            interp2 = interpolateEntity(mc.field_71439_g, mc.func_184121_ak());
            wurstplusTessellator.drawBoundingBox(iBlockState2.func_185918_c(mc.field_71441_e, blockPos).func_72317_d(-interp2.field_72450_a, -interp2.field_72448_b, -interp2.field_72449_c), 1.5F, r, g, b, (Integer)this.alpha.getValue());
         } else {
            iBlockState2 = mc.field_71441_e.func_180495_p(blockPos);
            interp2 = interpolateEntity(mc.field_71439_g, mc.func_184121_ak());
            wurstplusTessellator.drawFullBox(iBlockState2.func_185918_c(mc.field_71441_e, blockPos).func_72317_d(-interp2.field_72450_a, -interp2.field_72448_b, -interp2.field_72449_c), blockPos, 1.5F, r, g, b, (Integer)this.alpha.getValue());
         }
      }

      wurstplusTessellator.release();
   }

   public static Vec3d interpolateEntity(Entity entity, float time) {
      return new Vec3d(entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)time, entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)time, entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)time);
   }

   private void lookAtPacket(double px, double py, double pz, EntityPlayer me) {
      double[] v = EntityUtil.calculateLookAt(px, py, pz, me);
      setYawAndPitch((float)v[0], (float)v[1]);
   }

   private boolean canPlaceCrystal(BlockPos blockPos) {
      BlockPos boost = blockPos.func_177982_a(0, 1, 0);
      BlockPos boost2 = blockPos.func_177982_a(0, 2, 0);
      return (mc.field_71441_e.func_180495_p(blockPos).func_177230_c() == Blocks.field_150357_h || mc.field_71441_e.func_180495_p(blockPos).func_177230_c() == Blocks.field_150343_Z) && mc.field_71441_e.func_180495_p(boost).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(boost2).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost)).isEmpty() && mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost2)).isEmpty();
   }

   public static BlockPos getPlayerPos() {
      return new BlockPos(Math.floor(mc.field_71439_g.field_70165_t), Math.floor(mc.field_71439_g.field_70163_u), Math.floor(mc.field_71439_g.field_70161_v));
   }

   private List findCrystalBlocks(double range) {
      NonNullList positions = NonNullList.func_191196_a();
      positions.addAll((Collection)this.getSphere(getPlayerPos(), (float)range, (int)range, false, true, 0).stream().filter(this::canPlaceCrystal).collect(Collectors.toList()));
      return positions;
   }

   public List getSphere(BlockPos loc, float r, int h, boolean hollow, boolean sphere, int plus_y) {
      List circleblocks = new ArrayList();
      int cx = loc.func_177958_n();
      int cy = loc.func_177956_o();
      int cz = loc.func_177952_p();

      for(int x = cx - (int)r; (float)x <= (float)cx + r; ++x) {
         for(int z = cz - (int)r; (float)z <= (float)cz + r; ++z) {
            for(int y = sphere ? cy - (int)r : cy; (float)y < (sphere ? (float)cy + r : (float)(cy + h)); ++y) {
               double dist = (double)((cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? (cy - y) * (cy - y) : 0));
               if (dist < (double)(r * r) && (!hollow || dist >= (double)((r - 1.0F) * (r - 1.0F)))) {
                  BlockPos l = new BlockPos(x, y + plus_y, z);
                  circleblocks.add(l);
               }
            }
         }
      }

      return circleblocks;
   }

   public static float calculateDamage(double posX, double posY, double posZ, Entity entity) {
      float doubleExplosionSize = 12.0F;
      double distancedsize = entity.func_70011_f(posX, posY, posZ) / (double)doubleExplosionSize;
      Vec3d vec3d = new Vec3d(posX, posY, posZ);
      double blockDensity = (double)entity.field_70170_p.func_72842_a(vec3d, entity.func_174813_aQ());
      double v = (1.0D - distancedsize) * blockDensity;
      float damage = (float)((int)((v * v + v) / 2.0D * 9.0D * (double)doubleExplosionSize + 1.0D));
      double finald = 1.0D;
      if (entity instanceof EntityLivingBase) {
         finald = (double)getBlastReduction((EntityLivingBase)entity, getDamageMultiplied(damage), new Explosion(mc.field_71441_e, (Entity)null, posX, posY, posZ, 6.0F, false, true));
      }

      return (float)finald;
   }

   public static float getBlastReduction(EntityLivingBase entity, float damage, Explosion explosion) {
      if (entity instanceof EntityPlayer) {
         EntityPlayer ep = (EntityPlayer)entity;
         DamageSource ds = DamageSource.func_94539_a(explosion);
         damage = CombatRules.func_189427_a(damage, (float)ep.func_70658_aO(), (float)ep.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e());
         int k = EnchantmentHelper.func_77508_a(ep.func_184193_aE(), ds);
         float f = MathHelper.func_76131_a((float)k, 0.0F, 20.0F);
         damage *= 1.0F - f / 25.0F;
         if (entity.func_70644_a(Potion.func_188412_a(11))) {
            damage -= damage / 4.0F;
         }

         return Math.max(damage - ep.func_110139_bj(), 0.0F);
      } else {
         return CombatRules.func_189427_a(damage, (float)entity.func_70658_aO(), (float)entity.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e());
      }
   }

   private static float getDamageMultiplied(float damage) {
      int diff = mc.field_71441_e.func_175659_aa().func_151525_a();
      return damage * (diff == 0 ? 0.0F : (diff == 2 ? 1.0F : (diff == 1 ? 0.5F : 1.5F)));
   }

   public static float calculateDamage(EntityEnderCrystal crystal, Entity entity) {
      return calculateDamage(crystal.field_70165_t, crystal.field_70163_u, crystal.field_70161_v, entity);
   }

   private static void setYawAndPitch(float yaw1, float pitch1) {
      yaw = (double)yaw1;
      pitch = (double)pitch1;
      isSpoofingAngles = true;
   }

   private static void resetRotation() {
      if (isSpoofingAngles) {
         yaw = (double)mc.field_71439_g.field_70177_z;
         pitch = (double)mc.field_71439_g.field_70125_A;
         isSpoofingAngles = false;
      }

   }

   protected void onEnable() {
      Command.sendChatMessage("we §l§2gaming§r");
      if (mc.field_71439_g == null) {
         this.disable();
      }
   }

   public void onDisable() {
      this.renderBlock = null;
      Command.sendChatMessage("we aint §l§4gaming§r no more");
      resetRotation();
   }

   private static enum PlaceMode {
      PLACEFIRST,
      BREAKFIRST;
   }

   private static enum RenderMode {
      SOLID,
      OUTLINE,
      UP,
      FULL;
   }
}
