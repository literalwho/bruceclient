package me.travis.wurstplus.module.modules.misc;

import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import net.minecraft.util.math.MathHelper;

@Module.Info(
   name = "PosLock",
   category = Module.Category.MISC
)
public class Poslock extends Module {
   private Setting direction;

   public Poslock() {
      this.direction = this.register(Settings.e("Direction", Poslock.Direction.North));
   }

   public void onUpdate() {
      if (!this.isDisabled()) {
         if (this.direction.getValue() == Poslock.Direction.North) {
            mc.field_71439_g.field_70177_z = (float)MathHelper.func_76125_a(180, -180, 180);
         } else if (this.direction.getValue() == Poslock.Direction.South) {
            mc.field_71439_g.field_70177_z = (float)MathHelper.func_76125_a(0, -180, 180);
         } else if (this.direction.getValue() == Poslock.Direction.West) {
            mc.field_71439_g.field_70177_z = (float)MathHelper.func_76125_a(90, -180, 180);
         } else if (this.direction.getValue() == Poslock.Direction.East) {
            mc.field_71439_g.field_70177_z = -90.0F;
         } else {
            Command.sendChatMessage("what");
         }

      }
   }

   public static enum Direction {
      North,
      South,
      West,
      East;
   }
}
