package me.travis.wurstplus.module.modules.misc;

import java.util.ArrayList;
import java.util.function.Predicate;
import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.command.commands.FriendCommand;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.util.Friends;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.player.EntityPlayer;

@Module.Info(
   name = "MiddleClick Friend",
   category = Module.Category.RENDER
)
public class MiddleClickFriend extends Module {
   @EventHandler
   private Listener listener = new Listener((event) -> {
      if (mc.field_71476_x != null && mc.field_71476_x.field_72308_g instanceof EntityPlayer) {
         String name = mc.field_71476_x.field_72308_g.func_70005_c_();
         if (Friends.isFriend(name)) {
            if (!Friends.isFriend(name)) {
               Command.sendChatMessage("That player isn't your friend.");
               return;
            }

            Friends var10000 = Friends.INSTANCE;
            Friends.Friend friend = (Friends.Friend)((ArrayList)Friends.friends.getValue()).stream().filter((friend1) -> {
               return friend1.getUsername().equalsIgnoreCase(name);
            }).findFirst().get();
            var10000 = Friends.INSTANCE;
            ((ArrayList)Friends.friends.getValue()).remove(friend);
            Command.sendChatMessage("&b" + friend.getUsername() + "&r has been unfriended.");
            return;
         }

         (new Thread(() -> {
            Friends.Friend f = FriendCommand.getFriendByName(name);
            if (f == null) {
               Command.sendChatMessage("Failed to find UUID of " + name);
            } else {
               Friends var10000 = Friends.INSTANCE;
               ((ArrayList)Friends.friends.getValue()).add(f);
               Command.sendChatMessage("Added &b" + name + "&r to friends list");
            }
         })).start();
      }

   }, new Predicate[0]);

   protected void onEnable() {
   }
}
