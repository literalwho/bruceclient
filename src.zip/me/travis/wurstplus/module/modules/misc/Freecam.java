package me.travis.wurstplus.module.modules.misc;

import java.util.function.Predicate;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketInput;
import net.minecraft.network.play.client.CPacketPlayer;

@Module.Info(
   name = "Freecam",
   category = Module.Category.MOVEMENT
)
public class Freecam extends Module {
   private Setting speed = this.register(Settings.i("Speed", 5));
   private double posX;
   private double posY;
   private double posZ;
   private float pitch;
   private float yaw;
   private EntityOtherPlayerMP clonedPlayer;
   private boolean isRidingEntity;
   private Entity ridingEntity;
   @EventHandler
   private Listener moveListener = new Listener((event) -> {
      mc.field_71439_g.field_70145_X = true;
   }, (Predicate[])(new Predicate[0]));
   @EventHandler
   private Listener pushListener = new Listener((event) -> {
      event.setCanceled(true);
   }, (Predicate[])(new Predicate[0]));
   @EventHandler
   private Listener sendListener = new Listener((event) -> {
      if (event.getPacket() instanceof CPacketPlayer || event.getPacket() instanceof CPacketInput) {
         event.cancel();
      }

   }, (Predicate[])(new Predicate[0]));

   protected void onEnable() {
      if (mc.field_71439_g != null) {
         this.isRidingEntity = mc.field_71439_g.func_184187_bx() != null;
         if (mc.field_71439_g.func_184187_bx() == null) {
            this.posX = mc.field_71439_g.field_70165_t;
            this.posY = mc.field_71439_g.field_70163_u;
            this.posZ = mc.field_71439_g.field_70161_v;
         } else {
            this.ridingEntity = mc.field_71439_g.func_184187_bx();
            mc.field_71439_g.func_184210_p();
         }

         this.pitch = mc.field_71439_g.field_70125_A;
         this.yaw = mc.field_71439_g.field_70177_z;
         (this.clonedPlayer = new EntityOtherPlayerMP(mc.field_71441_e, mc.func_110432_I().func_148256_e())).func_82149_j(mc.field_71439_g);
         this.clonedPlayer.field_70759_as = mc.field_71439_g.field_70759_as;
         mc.field_71441_e.func_73027_a(-100, this.clonedPlayer);
         mc.field_71439_g.field_71075_bZ.field_75100_b = true;
         mc.field_71439_g.field_71075_bZ.func_75092_a((float)(Integer)this.speed.getValue() / 100.0F);
         mc.field_71439_g.field_70145_X = true;
      }

   }

   protected void onDisable() {
      EntityPlayer localPlayer = mc.field_71439_g;
      if (localPlayer != null) {
         mc.field_71439_g.func_70080_a(this.posX, this.posY, this.posZ, this.yaw, this.pitch);
         mc.field_71441_e.func_73028_b(-100);
         this.clonedPlayer = null;
         double posX = 0.0D;
         this.posZ = 0.0D;
         this.posY = 0.0D;
         this.posX = 0.0D;
         float n = 0.0F;
         this.yaw = 0.0F;
         this.pitch = 0.0F;
         mc.field_71439_g.field_71075_bZ.field_75100_b = false;
         mc.field_71439_g.field_71075_bZ.func_75092_a(0.05F);
         mc.field_71439_g.field_70145_X = false;
         EntityPlayerSP player = mc.field_71439_g;
         EntityPlayerSP player2 = mc.field_71439_g;
         EntityPlayerSP player3 = mc.field_71439_g;
         double motionX = 0.0D;
         player3.field_70179_y = 0.0D;
         player2.field_70181_x = 0.0D;
         player.field_70159_w = 0.0D;
         if (this.isRidingEntity) {
            mc.field_71439_g.func_184205_a(this.ridingEntity, true);
         }
      }

   }

   public void onUpdate() {
      mc.field_71439_g.field_71075_bZ.field_75100_b = true;
      mc.field_71439_g.field_71075_bZ.func_75092_a((float)(Integer)this.speed.getValue() / 100.0F);
      mc.field_71439_g.field_70145_X = true;
      mc.field_71439_g.field_70122_E = false;
      mc.field_71439_g.field_70143_R = 0.0F;
   }
}
