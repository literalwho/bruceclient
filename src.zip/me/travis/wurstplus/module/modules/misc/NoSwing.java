package me.travis.wurstplus.module.modules.misc;

import java.util.function.Predicate;
import me.travis.wurstplus.module.Module;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.play.client.CPacketAnimation;

@Module.Info(
   name = "NoSwing",
   category = Module.Category.EXPLOITS
)
public class NoSwing extends Module {
   @EventHandler
   public Listener listener = new Listener((event) -> {
      if (event.getPacket() instanceof CPacketAnimation) {
         event.cancel();
      }

   }, new Predicate[0]);
}
