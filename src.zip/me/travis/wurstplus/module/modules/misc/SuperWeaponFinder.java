package me.travis.wurstplus.module.modules.misc;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import me.travis.wurstplus.event.events.RenderEvent;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.travis.wurstplus.util.Friends;
import me.travis.wurstplus.util.wurstplusTessellator;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.math.BlockPos;

@Module.Info(
   name = "32k Warner",
   category = Module.Category.MISC
)
public class SuperWeaponFinder extends Module {
   private Setting renderOwn = this.register(Settings.b("Show Own", false));
   private Setting rainbow = this.register(Settings.b("RainbowMode", false));
   private Setting red = this.register(Settings.integerBuilder("Red").withRange(0, 255).withValue((int)255).withVisibility((o) -> {
      return !(Boolean)this.rainbow.getValue();
   }).build());
   private Setting green = this.register(Settings.integerBuilder("Green").withRange(0, 255).withValue((int)255).withVisibility((o) -> {
      return !(Boolean)this.rainbow.getValue();
   }).build());
   private Setting blue = this.register(Settings.integerBuilder("Blue").withRange(0, 255).withValue((int)255).withVisibility((o) -> {
      return !(Boolean)this.rainbow.getValue();
   }).build());
   private Setting satuation = this.register(Settings.floatBuilder("Saturation").withRange(0.0F, 1.0F).withValue((Number)0.6F).withVisibility((o) -> {
      return (Boolean)this.rainbow.getValue();
   }).build());
   private Setting brightness = this.register(Settings.floatBuilder("Brightness").withRange(0.0F, 1.0F).withValue((Number)0.6F).withVisibility((o) -> {
      return (Boolean)this.rainbow.getValue();
   }).build());
   private Setting speed = this.register(Settings.integerBuilder("Speed").withRange(0, 10).withValue((int)2).withVisibility((o) -> {
      return (Boolean)this.rainbow.getValue();
   }).build());
   private Setting alpha = this.register(Settings.integerBuilder("Transparency").withRange(0, 255).withValue((int)70).build());
   private BlockPos renderBlock;
   private Color rgbc;
   private float hue;

   public void onUpdate() {
      if (!mc.field_71439_g.field_70128_L && mc.field_71439_g != null && !this.isDisabled()) {
         EntityPlayer target = null;
         List entities = new ArrayList();
         entities.addAll((Collection)mc.field_71441_e.field_73010_i.stream().filter((entityPlayer) -> {
            return !Friends.isFriend(entityPlayer.func_70005_c_());
         }).collect(Collectors.toList()));
         Iterator var3 = entities.iterator();

         while(true) {
            EntityPlayer e;
            do {
               do {
                  do {
                     if (!var3.hasNext()) {
                        if (target == null) {
                           this.renderBlock = null;
                        }

                        return;
                     }

                     e = (EntityPlayer)var3.next();
                  } while(e.field_70128_L);
               } while(e.func_110143_aJ() <= 0.0F);
            } while(e.func_70005_c_() == mc.field_71439_g.func_70005_c_() && !(Boolean)this.renderOwn.getValue());

            if (this.checkSharpness(e.func_184614_ca())) {
               this.renderBlock = e.func_180425_c();
               target = e;
            }
         }
      }
   }

   public void onWorldRender(RenderEvent event) {
      if (this.renderBlock != null) {
         if ((Boolean)this.rainbow.getValue()) {
            this.rgbc = Color.getHSBColor(this.hue, (Float)this.satuation.getValue(), (Float)this.brightness.getValue());
            wurstplusTessellator.drawRange(this.renderBlock, (float)this.rgbc.getRed(), (float)this.rgbc.getGreen(), (float)this.rgbc.getBlue(), (float)(Integer)this.alpha.getValue());
            if (this.hue + (float)(Integer)this.speed.getValue() / 200.0F > 1.0F) {
               this.hue = 0.0F;
            } else {
               this.hue += (float)(Integer)this.speed.getValue() / 200.0F;
            }
         } else {
            wurstplusTessellator.drawRange(this.renderBlock, (float)(Integer)this.red.getValue(), (float)(Integer)this.green.getValue(), (float)(Integer)this.blue.getValue(), (float)(Integer)this.alpha.getValue());
         }
      }

   }

   private boolean checkSharpness(ItemStack stack) {
      if (stack.func_77978_p() == null) {
         return false;
      } else {
         NBTTagList enchants = (NBTTagList)stack.func_77978_p().func_74781_a("ench");
         if (enchants == null) {
            return false;
         } else {
            for(int i = 0; i < enchants.func_74745_c(); ++i) {
               NBTTagCompound enchant = enchants.func_150305_b(i);
               if (enchant.func_74762_e("id") == 16) {
                  int lvl = enchant.func_74762_e("lvl");
                  if (lvl >= 42) {
                     return true;
                  }
                  break;
               }
            }

            return false;
         }
      }
   }

   protected void onEnable() {
      this.hue = 0.0F;
   }

   protected void onDisable() {
      this.renderBlock = null;
   }
}
