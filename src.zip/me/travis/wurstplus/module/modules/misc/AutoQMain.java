package me.travis.wurstplus.module.modules.misc;

import java.text.SimpleDateFormat;
import java.util.Date;
import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.CPacketChatMessage;

@Module.Info(
   name = "AutoQMain",
   description = "Automatically does /queue main on 2b2t.org",
   category = Module.Category.CHAT
)
public class AutoQMain extends Module {
   private Setting debug = this.register(Settings.b("Debug", true));
   private Setting debugWarn = this.register(Settings.b("Connection Warning", true));
   private Setting endDi = this.register(Settings.b("Dimension Warning", true));
   private Setting delay = this.register(Settings.doubleBuilder("Wait time").withMinimum(0.2D).withValue((Number)7.1D).withMaximum(10.0D).build());
   private double delayTime;
   private double oldDelay = 0.0D;

   public void onUpdate() {
      if (mc.field_71439_g != null) {
         if (this.oldDelay == 0.0D) {
            this.oldDelay = (Double)this.delay.getValue();
         } else if (this.oldDelay != (Double)this.delay.getValue()) {
            this.delayTime = (Double)this.delay.getValue();
            this.oldDelay = (Double)this.delay.getValue();
         }

         if (this.delayTime <= 0.0D) {
            this.delayTime = (double)((int)((Double)this.delay.getValue() * 2400.0D));
         } else if (this.delayTime > 0.0D) {
            --this.delayTime;
            return;
         }

         if (Minecraft.func_71410_x().func_147104_D() == null) {
            Command.sendWarningMessage(this.getChatName() + "&l&6Warning: &r&6You are on singleplayer");
         } else {
            if (!Minecraft.func_71410_x().func_147104_D().field_78845_b.equalsIgnoreCase("2b2t.org") && (Boolean)this.debugWarn.getValue()) {
               Command.sendWarningMessage(this.getChatName() + "&l&6Warning: &r&6You are not connected to 2b2t.org");
            }

            if (mc.field_71439_g.field_71093_bK != 1 && (Boolean)this.endDi.getValue()) {
               Command.sendWarningMessage(this.getChatName() + "&l&6Warning: &r&6You are not in the end. Not running &b/queue main&7.");
            } else {
               if ((Boolean)this.debug.getValue()) {
                  SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
                  Date date = new Date(System.currentTimeMillis());
                  System.out.println(formatter.format(date));
                  Command.sendChatMessage("&7Run &b/queue main&7 at " + formatter.format(date));
               }

               Minecraft.func_71410_x().field_71442_b.field_78774_b.func_147297_a(new CPacketChatMessage("/queue main"));
            }
         }
      }
   }

   public void onDisable() {
      this.delayTime = 0.0D;
   }
}
