package me.travis.wurstplus.module.modules.misc;

import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import net.minecraft.item.ItemEndCrystal;
import net.minecraft.item.ItemExpBottle;

@Module.Info(
   name = "Tickplace",
   category = Module.Category.MISC
)
public class Fastplace extends Module {
   private Setting xp = this.register(Settings.b("EXP & Crystal only", false));

   public void onUpdate() {
      if (!this.isDisabled() && mc.field_71439_g != null) {
         if ((Boolean)this.xp.getValue()) {
            if (mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() instanceof ItemExpBottle || mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() instanceof ItemEndCrystal) {
               mc.field_71467_ac = 0;
            }
         } else {
            mc.field_71467_ac = 0;
         }

      }
   }
}
