package me.travis.wurstplus.module.modules.DispenserPVP;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.module.ModuleManager;
import me.travis.wurstplus.module.modules.combat.CrystalAura;
import me.travis.wurstplus.module.modules.combat.CrystalAura2;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.travis.wurstplus.util.BlockInteractionHelper;
import me.travis.wurstplus.util.Friends;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockLiquid;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

@Module.Info(
   name = "OldHopper32k",
   category = Module.Category.DispenserPVP
)
public class Linux32k extends Module {
   private static final List blackList;
   private static final List shulkerList;
   private static final DecimalFormat df;
   private Setting moveToHotbar = this.register(Settings.b("Move 32k to Hotbar", true));
   private Setting autoEnableHitAura = this.register(Settings.b("Auto enable Hit Aura", true));
   private Setting placeRange = this.register(Settings.doubleBuilder("Place range").withMinimum(1.0D).withValue((Number)4.0D).withMaximum(10.0D).build());
   private Setting yOffset = this.register(Settings.i("Y Offset (Hopper)", 2));
   private Setting placeCloseToEnemy = this.register(Settings.b("Place close to enemy", false));
   private Setting placeObiOnTop = this.register(Settings.b("Place Obi on Top", true));
   private Setting debugMessages = this.register(Settings.b("Debug Messages", true));
   private int swordSlot;
   private static boolean isSneaking;

   protected void onEnable() {
      if (!this.isDisabled() && mc.field_71439_g != null && !ModuleManager.isModuleEnabled("Freecam")) {
         df.setRoundingMode(RoundingMode.CEILING);
         int hopperSlot = -1;
         int shulkerSlot = -1;
         int obiSlot = -1;
         this.swordSlot = -1;

         int i;
         for(i = 0; i < 9 && (hopperSlot == -1 || shulkerSlot == -1 || obiSlot == -1); ++i) {
            ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (stack != ItemStack.field_190927_a && stack.func_77973_b() instanceof ItemBlock) {
               Block block = ((ItemBlock)stack.func_77973_b()).func_179223_d();
               if (block == Blocks.field_150438_bZ) {
                  hopperSlot = i;
               } else if (shulkerList.contains(block)) {
                  shulkerSlot = i;
               } else if (block == Blocks.field_150343_Z) {
                  obiSlot = i;
               }
            }
         }

         if (hopperSlot == -1) {
            if ((Boolean)this.debugMessages.getValue()) {
               Command.sendChatMessage(this.getChatName() + "Hopper missing, disabling.");
            }

            this.disable();
         } else if (shulkerSlot == -1) {
            if ((Boolean)this.debugMessages.getValue()) {
               Command.sendChatMessage(this.getChatName() + "Shulker missing, disabling.");
            }

            this.disable();
         } else {
            i = (int)Math.ceil((Double)this.placeRange.getValue());
            CrystalAura2 crystalAura = (CrystalAura2)ModuleManager.getModuleByName("CrystalAura2");
            List placeTargetList = crystalAura.getSphere(CrystalAura.getPlayerPos(), (float)i, i, false, true, 0);
            Map placeTargetMap = new HashMap();
            BlockPos placeTarget = null;
            boolean useRangeSorting = false;
            Iterator var10 = placeTargetList.iterator();

            BlockPos pos;
            label153:
            while(var10.hasNext()) {
               pos = (BlockPos)var10.next();
               Iterator var12 = mc.field_71441_e.field_72996_f.iterator();

               while(true) {
                  Entity entity;
                  do {
                     do {
                        do {
                           do {
                              if (!var12.hasNext()) {
                                 continue label153;
                              }

                              entity = (Entity)var12.next();
                           } while(!(entity instanceof EntityPlayer));
                        } while(entity == mc.field_71439_g);
                     } while(Friends.isFriend(entity.func_70005_c_()));
                  } while((Integer)this.yOffset.getValue() != 0 && Math.abs(mc.field_71439_g.func_180425_c().field_177960_b - pos.field_177960_b) > Math.abs((Integer)this.yOffset.getValue()));

                  if (this.isAreaPlaceable(pos)) {
                     useRangeSorting = true;
                     double distanceToEntity = entity.func_70011_f((double)pos.field_177962_a, (double)pos.field_177960_b, (double)pos.field_177961_c);
                     placeTargetMap.put(pos, placeTargetMap.containsKey(pos) ? (Double)placeTargetMap.get(pos) + distanceToEntity : distanceToEntity);
                     useRangeSorting = true;
                  }
               }
            }

            if (placeTargetMap.size() > 0) {
               placeTargetMap.forEach((k, v) -> {
                  if (!this.isAreaPlaceable(k)) {
                     placeTargetMap.remove(k);
                  }

               });
               if (placeTargetMap.size() == 0) {
                  useRangeSorting = false;
               }
            }

            if (useRangeSorting) {
               if ((Boolean)this.placeCloseToEnemy.getValue()) {
                  if ((Boolean)this.debugMessages.getValue()) {
                     Command.sendChatMessage(this.getChatName() + "Placing close to Enemy");
                  }

                  placeTarget = (BlockPos)((Entry)Collections.min(placeTargetMap.entrySet(), Entry.comparingByValue())).getKey();
               } else {
                  if ((Boolean)this.debugMessages.getValue()) {
                     Command.sendChatMessage(this.getChatName() + "Placing far from Enemy");
                  }

                  placeTarget = (BlockPos)((Entry)Collections.max(placeTargetMap.entrySet(), Entry.comparingByValue())).getKey();
               }
            } else {
               if ((Boolean)this.debugMessages.getValue()) {
                  Command.sendChatMessage(this.getChatName() + "No enemy nearby, placing at first valid position.");
               }

               var10 = placeTargetList.iterator();

               while(var10.hasNext()) {
                  pos = (BlockPos)var10.next();
                  if (this.isAreaPlaceable(pos)) {
                     placeTarget = pos;
                     break;
                  }
               }
            }

            if (placeTarget == null) {
               if ((Boolean)this.debugMessages.getValue()) {
                  Command.sendChatMessage(this.getChatName() + "No valid position in range to place!");
               }

               this.disable();
            } else {
               if ((Boolean)this.debugMessages.getValue()) {
                  Command.sendChatMessage(this.getChatName() + "Place Target: " + placeTarget.field_177962_a + " " + placeTarget.field_177960_b + " " + placeTarget.field_177961_c + " Distance: " + df.format(mc.field_71439_g.func_174791_d().func_72438_d(new Vec3d(placeTarget))));
               }

               mc.field_71439_g.field_71071_by.field_70461_c = hopperSlot;
               placeBlock(new BlockPos(placeTarget));
               mc.field_71439_g.field_71071_by.field_70461_c = shulkerSlot;
               placeBlock(new BlockPos(placeTarget.func_177982_a(0, 1, 0)));
               if ((Boolean)this.placeObiOnTop.getValue() && obiSlot != -1) {
                  mc.field_71439_g.field_71071_by.field_70461_c = obiSlot;
                  placeBlock(new BlockPos(placeTarget.func_177982_a(0, 2, 0)));
               }

               if (isSneaking) {
                  mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.STOP_SNEAKING));
                  isSneaking = false;
               }

               mc.field_71439_g.field_71071_by.field_70461_c = shulkerSlot;
               BlockPos hopperPos = new BlockPos(placeTarget);
               mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItemOnBlock(hopperPos, EnumFacing.DOWN, EnumHand.MAIN_HAND, 0.0F, 0.0F, 0.0F));
               this.swordSlot = shulkerSlot + 32;
            }
         }
      } else {
         this.disable();
      }
   }

   public void onUpdate() {
      if (!this.isDisabled() && mc.field_71439_g != null && !ModuleManager.isModuleEnabled("Freecam")) {
         if (mc.field_71462_r instanceof GuiContainer) {
            if (!(Boolean)this.moveToHotbar.getValue()) {
               this.disable();
            } else if (this.swordSlot != -1) {
               boolean swapReady = true;
               if (((GuiContainer)mc.field_71462_r).field_147002_h.func_75139_a(0).func_75211_c().field_190928_g) {
                  swapReady = false;
               }

               if (!((GuiContainer)mc.field_71462_r).field_147002_h.func_75139_a(this.swordSlot).func_75211_c().field_190928_g) {
                  swapReady = false;
               }

               if (swapReady) {
                  mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, 0, this.swordSlot - 32, ClickType.SWAP, mc.field_71439_g);
                  if ((Boolean)this.autoEnableHitAura.getValue()) {
                     ModuleManager.getModuleByName("Aura").enable();
                  }

                  this.disable();
               }

            }
         }
      }
   }

   private boolean isAreaPlaceable(BlockPos blockPos) {
      Iterator var2 = mc.field_71441_e.func_72839_b((Entity)null, new AxisAlignedBB(blockPos)).iterator();

      Entity entity;
      do {
         if (!var2.hasNext()) {
            if (!mc.field_71441_e.func_180495_p(blockPos).func_185904_a().func_76222_j()) {
               return false;
            }

            if (!mc.field_71441_e.func_180495_p(blockPos.func_177982_a(0, 1, 0)).func_185904_a().func_76222_j()) {
               return false;
            }

            if (mc.field_71441_e.func_180495_p(blockPos.func_177982_a(0, -1, 0)).func_177230_c() instanceof BlockAir) {
               return false;
            }

            if (mc.field_71441_e.func_180495_p(blockPos.func_177982_a(0, -1, 0)).func_177230_c() instanceof BlockLiquid) {
               return false;
            }

            if (mc.field_71439_g.func_174791_d().func_72438_d(new Vec3d(blockPos)) > (Double)this.placeRange.getValue()) {
               return false;
            }

            Block block = mc.field_71441_e.func_180495_p(blockPos.func_177982_a(0, -1, 0)).func_177230_c();
            if (!blackList.contains(block) && !shulkerList.contains(block)) {
               return mc.field_71439_g.func_174791_d().func_72438_d((new Vec3d(blockPos)).func_72441_c(0.0D, 1.0D, 0.0D)) <= (Double)this.placeRange.getValue();
            }

            return false;
         }

         entity = (Entity)var2.next();
      } while(!(entity instanceof EntityLivingBase));

      return false;
   }

   private static void placeBlock(BlockPos pos) {
      if (mc.field_71441_e.func_180495_p(pos).func_185904_a().func_76222_j()) {
         if (checkForNeighbours(pos)) {
            EnumFacing[] var1 = EnumFacing.values();
            int var2 = var1.length;

            for(int var3 = 0; var3 < var2; ++var3) {
               EnumFacing side = var1[var3];
               BlockPos neighbor = pos.func_177972_a(side);
               EnumFacing side2 = side.func_176734_d();
               if (mc.field_71441_e.func_180495_p(neighbor).func_177230_c().func_176209_a(mc.field_71441_e.func_180495_p(neighbor), false)) {
                  Vec3d hitVec = (new Vec3d(neighbor)).func_72441_c(0.5D, 0.5D, 0.5D).func_178787_e((new Vec3d(side2.func_176730_m())).func_186678_a(0.5D));
                  Block neighborPos = mc.field_71441_e.func_180495_p(neighbor).func_177230_c();
                  if (blackList.contains(neighborPos) || shulkerList.contains(neighborPos)) {
                     mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.START_SNEAKING));
                     isSneaking = true;
                  }

                  BlockInteractionHelper.faceVectorPacketInstant(hitVec);
                  mc.field_71442_b.func_187099_a(mc.field_71439_g, mc.field_71441_e, neighbor, side2, hitVec, EnumHand.MAIN_HAND);
                  mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                  mc.field_71467_ac = 4;
                  return;
               }
            }

         }
      }
   }

   private static boolean checkForNeighbours(BlockPos blockPos) {
      if (!hasNeighbour(blockPos)) {
         EnumFacing[] var1 = EnumFacing.values();
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            EnumFacing side = var1[var3];
            BlockPos neighbour = blockPos.func_177972_a(side);
            if (hasNeighbour(neighbour)) {
               return true;
            }
         }

         return false;
      } else {
         return true;
      }
   }

   private static boolean hasNeighbour(BlockPos blockPos) {
      EnumFacing[] var1 = EnumFacing.values();
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         EnumFacing side = var1[var3];
         BlockPos neighbour = blockPos.func_177972_a(side);
         if (!mc.field_71441_e.func_180495_p(neighbour).func_185904_a().func_76222_j()) {
            return true;
         }
      }

      return false;
   }

   static {
      blackList = Arrays.asList(Blocks.field_150477_bB, Blocks.field_150486_ae, Blocks.field_150447_bR, Blocks.field_150462_ai, Blocks.field_150467_bQ, Blocks.field_150382_bo, Blocks.field_150438_bZ, Blocks.field_150409_cd, Blocks.field_150367_z, Blocks.field_150415_aT);
      shulkerList = Arrays.asList(Blocks.field_190977_dl, Blocks.field_190978_dm, Blocks.field_190979_dn, Blocks.field_190980_do, Blocks.field_190981_dp, Blocks.field_190982_dq, Blocks.field_190983_dr, Blocks.field_190984_ds, Blocks.field_190985_dt, Blocks.field_190986_du, Blocks.field_190987_dv, Blocks.field_190988_dw, Blocks.field_190989_dx, Blocks.field_190990_dy, Blocks.field_190991_dz, Blocks.field_190975_dA);
      df = new DecimalFormat("#.#");
   }
}
