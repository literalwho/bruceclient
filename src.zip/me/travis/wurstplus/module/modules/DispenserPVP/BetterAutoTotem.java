package me.travis.wurstplus.module.modules.DispenserPVP;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;

@Module.Info(
   name = "Better Auto Totem",
   category = Module.Category.DispenserPVP
)
public class BetterAutoTotem extends Module {
   private int numOfTotems;
   private int preferredTotemSlot;
   private Setting soft = this.register(Settings.b("Soft", false));
   private Setting pauseInContainers = this.register(Settings.b("PauseInContainers", true));
   private Setting pauseInInventory = this.register(Settings.b("PauseInInventory", true));

   public void onUpdate() {
      if (mc.field_71439_g != null) {
         if (this.findTotems()) {
            if (!(Boolean)this.pauseInContainers.getValue() || !(mc.field_71462_r instanceof GuiContainer) || mc.field_71462_r instanceof GuiInventory) {
               if (!(Boolean)this.pauseInInventory.getValue() || !(mc.field_71462_r instanceof GuiInventory) || !(mc.field_71462_r instanceof GuiInventory)) {
                  if ((Boolean)this.soft.getValue()) {
                     if (mc.field_71439_g.func_184592_cb().func_77973_b().equals(Items.field_190931_a)) {
                        mc.field_71442_b.func_187098_a(0, this.preferredTotemSlot, 0, ClickType.PICKUP, mc.field_71439_g);
                        mc.field_71442_b.func_187098_a(0, 45, 0, ClickType.PICKUP, mc.field_71439_g);
                        mc.field_71442_b.func_78765_e();
                     }
                  } else if (!mc.field_71439_g.func_184592_cb().func_77973_b().equals(Items.field_190929_cY)) {
                     boolean offhandEmptyPreSwitch = false;
                     if (mc.field_71439_g.func_184592_cb().func_77973_b().equals(Items.field_190931_a)) {
                        offhandEmptyPreSwitch = true;
                     }

                     mc.field_71442_b.func_187098_a(0, this.preferredTotemSlot, 0, ClickType.PICKUP, mc.field_71439_g);
                     mc.field_71442_b.func_187098_a(0, 45, 0, ClickType.PICKUP, mc.field_71439_g);
                     if (!offhandEmptyPreSwitch) {
                        mc.field_71442_b.func_187098_a(0, this.preferredTotemSlot, 0, ClickType.PICKUP, mc.field_71439_g);
                     }

                     mc.field_71442_b.func_78765_e();
                  }
               }
            }
         }
      }
   }

   private boolean findTotems() {
      this.numOfTotems = 0;
      AtomicInteger preferredTotemSlotStackSize = new AtomicInteger();
      preferredTotemSlotStackSize.set(Integer.MIN_VALUE);
      getInventoryAndHotbarSlots().forEach((slotKey, slotValue) -> {
         int numOfTotemsInStack = 0;
         if (slotValue.func_77973_b().equals(Items.field_190929_cY)) {
            numOfTotemsInStack = slotValue.func_190916_E();
            if (preferredTotemSlotStackSize.get() < numOfTotemsInStack) {
               preferredTotemSlotStackSize.set(numOfTotemsInStack);
               this.preferredTotemSlot = slotKey;
            }
         }

         this.numOfTotems += numOfTotemsInStack;
      });
      if (mc.field_71439_g.func_184592_cb().func_77973_b().equals(Items.field_190929_cY)) {
         this.numOfTotems += mc.field_71439_g.func_184592_cb().func_190916_E();
      }

      return this.numOfTotems != 0;
   }

   private static Map getInventoryAndHotbarSlots() {
      return getInventorySlots(9, 44);
   }

   private static Map getInventorySlots(int current, int last) {
      HashMap fullInventorySlots;
      for(fullInventorySlots = new HashMap(); current <= last; ++current) {
         fullInventorySlots.put(current, (ItemStack)mc.field_71439_g.field_71069_bz.func_75138_a().get(current));
      }

      return fullInventorySlots;
   }

   public void disableSoft() {
      this.soft.setValue(false);
   }
}
