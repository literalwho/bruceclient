package me.travis.wurstplus.module.modules.DispenserPVP;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.module.ModuleManager;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.travis.wurstplus.util.BlockInteractionHelper;
import net.minecraft.item.ItemBed;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

@Module.Info(
   name = "AutoBedBomb",
   category = Module.Category.DispenserPVP
)
public class AutoBedBomb extends Module {
   private static final DecimalFormat df = new DecimalFormat("#.#");
   private Setting rotate = this.register(Settings.b("Rotate", false));
   private Setting debugMessages = this.register(Settings.b("Debug Messages", false));
   private int stage;
   private BlockPos placeTarget;
   private int bedSlot;
   private boolean isSneaking;

   protected void onEnable() {
      if (BetterAuto32k.mc.field_71439_g != null && !ModuleManager.isModuleEnabled("Freecam")) {
         df.setRoundingMode(RoundingMode.CEILING);
         this.stage = 0;
         this.placeTarget = null;
         this.bedSlot = -1;
         this.isSneaking = false;

         for(int i = 0; i < 9 && this.bedSlot == -1; ++i) {
            ItemStack stack = BetterAuto32k.mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (stack.func_77973_b() instanceof ItemBed) {
               this.bedSlot = 1;
               break;
            }
         }

         if (this.bedSlot == -1) {
            if ((Boolean)this.debugMessages.getValue()) {
               Command.sendChatMessage("[AutoBedBomb] Bed(s) missing, disabling.");
            }

            this.disable();
         } else if (BetterAuto32k.mc.field_71476_x != null && BetterAuto32k.mc.field_71476_x.func_178782_a() != null && BetterAuto32k.mc.field_71476_x.func_178782_a().func_177984_a() != null) {
            this.placeTarget = BetterAuto32k.mc.field_71476_x.func_178782_a().func_177984_a();
            if ((Boolean)this.debugMessages.getValue()) {
               ;
            }
         } else {
            if ((Boolean)this.debugMessages.getValue()) {
               Command.sendChatMessage("[AutoBedBomb] Not a valid place target, disabling.");
            }

            this.disable();
         }
      } else {
         this.disable();
      }
   }

   public void onUpdate() {
      if (BetterAuto32k.mc.field_71439_g != null) {
         if (!ModuleManager.isModuleEnabled("Freecam")) {
            if (this.stage == 0) {
               BetterAuto32k.mc.field_71439_g.field_71071_by.field_70461_c = this.bedSlot;
               this.placeBlock(new BlockPos(this.placeTarget), EnumFacing.DOWN);
               BetterAuto32k.mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(BetterAuto32k.mc.field_71439_g, Action.STOP_SNEAKING));
               this.isSneaking = false;
               BetterAuto32k.mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItemOnBlock(this.placeTarget.func_177982_a(0, 0, 0), EnumFacing.DOWN, EnumHand.MAIN_HAND, 0.0F, 0.0F, 0.0F));
               this.stage = 1;
            } else {
               this.disable();
            }
         }
      }
   }

   private void placeBlock(BlockPos pos, EnumFacing side) {
      BlockPos neighbour = pos.func_177972_a(side);
      EnumFacing opposite = side.func_176734_d();
      if (!this.isSneaking) {
         BetterAuto32k.mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(BetterAuto32k.mc.field_71439_g, Action.START_SNEAKING));
         this.isSneaking = true;
      }

      Vec3d hitVec = (new Vec3d(neighbour)).func_72441_c(0.5D, 0.5D, 0.5D).func_178787_e((new Vec3d(opposite.func_176730_m())).func_186678_a(0.5D));
      if ((Boolean)this.rotate.getValue()) {
         BlockInteractionHelper.faceVectorPacketInstant(hitVec);
      }

      BetterAuto32k.mc.field_71442_b.func_187099_a(BetterAuto32k.mc.field_71439_g, BetterAuto32k.mc.field_71441_e, neighbour, opposite, hitVec, EnumHand.MAIN_HAND);
      BetterAuto32k.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
   }
}
