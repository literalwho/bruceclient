package me.travis.wurstplus.module.modules.DispenserPVP;

import java.util.Iterator;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.travis.wurstplus.util.EntityUtil;
import me.travis.wurstplus.util.Friends;
import me.travis.wurstplus.util.LagCompensator;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;

@Module.Info(
   name = "Bruce Aura",
   category = Module.Category.DispenserPVP,
   description = "Hits entities around you"
)
public class BruceAura extends Module {
   private Setting attackPlayers = this.register(Settings.b("Players", true));
   private Setting attackMobs = this.register(Settings.b("Mobs", false));
   private Setting attackAnimals = this.register(Settings.b("Animals", false));
   private Setting hitRange = this.register(Settings.d("Hit Range", 5.5D));
   private Setting ignoreWalls = this.register(Settings.b("Ignore Walls", true));
   private Setting waitMode;
   private Setting waitTick;
   private Setting autoWait;
   private Setting switchMode;
   private Setting hitMode;
   private int waitCounter;

   public BruceAura() {
      this.waitMode = this.register(Settings.e("Mode", BruceAura.WaitMode.TICK));
      this.waitTick = this.register(Settings.doubleBuilder("Tick Delay").withMinimum(0.1D).withValue((Number)2.0D).withMaximum(20.0D).build());
      this.autoWait = this.register(Settings.b("Auto Tick Delay", true));
      this.switchMode = this.register(Settings.e("Autoswitch", BruceAura.SwitchMode.Only32k));
      this.hitMode = this.register(Settings.e("Tool", BruceAura.HitMode.SWORD));
   }

   public void onEnable() {
      if (mc.field_71439_g != null) {
         ;
      }
   }

   public void onUpdate() {
      double autoWaitTick = 0.0D;
      if (!mc.field_71439_g.field_70128_L && mc.field_71439_g != null) {
         if ((Boolean)this.autoWait.getValue()) {
            autoWaitTick = 20.0D - (double)Math.round(LagCompensator.INSTANCE.getTickRate() * 10.0F) / 10.0D;
         }

         boolean shield = mc.field_71439_g.func_184592_cb().func_77973_b().equals(Items.field_185159_cQ) && mc.field_71439_g.func_184600_cs() == EnumHand.OFF_HAND;
         if (!mc.field_71439_g.func_184587_cr() || shield) {
            if (((BruceAura.WaitMode)this.waitMode.getValue()).equals(BruceAura.WaitMode.CPS)) {
               if (mc.field_71439_g.func_184825_o(this.getLagComp()) < 1.0F) {
                  return;
               }

               if (mc.field_71439_g.field_70173_aa % 2 != 0) {
                  return;
               }
            }

            if ((Boolean)this.autoWait.getValue()) {
               if (((BruceAura.WaitMode)this.waitMode.getValue()).equals(BruceAura.WaitMode.TICK) && autoWaitTick > 0.0D) {
                  if ((double)this.waitCounter < autoWaitTick) {
                     ++this.waitCounter;
                     return;
                  }

                  this.waitCounter = 0;
               }
            } else if (((BruceAura.WaitMode)this.waitMode.getValue()).equals(BruceAura.WaitMode.TICK) && (Double)this.waitTick.getValue() > 0.0D) {
               if ((double)this.waitCounter < (Double)this.waitTick.getValue()) {
                  ++this.waitCounter;
                  return;
               }

               this.waitCounter = 0;
            }

            Iterator entityIterator = Minecraft.func_71410_x().field_71441_e.field_72996_f.iterator();

            Entity target;
            while(true) {
               do {
                  do {
                     do {
                        do {
                           do {
                              do {
                                 if (!entityIterator.hasNext()) {
                                    return;
                                 }

                                 target = (Entity)entityIterator.next();
                              } while(!EntityUtil.isLiving(target));
                           } while(target == mc.field_71439_g);
                        } while((double)mc.field_71439_g.func_70032_d(target) > (Double)this.hitRange.getValue());
                     } while(((EntityLivingBase)target).func_110143_aJ() <= 0.0F);
                  } while(((BruceAura.WaitMode)this.waitMode.getValue()).equals(BruceAura.WaitMode.CPS) && ((EntityLivingBase)target).field_70737_aN != 0);
               } while(!(Boolean)this.ignoreWalls.getValue() && !mc.field_71439_g.func_70685_l(target) && !this.canEntityFeetBeSeen(target));

               if ((Boolean)this.attackPlayers.getValue() && target instanceof EntityPlayer && !Friends.isFriend(target.func_70005_c_())) {
                  this.attack(target);
                  return;
               }

               if (EntityUtil.isPassive(target)) {
                  if ((Boolean)this.attackAnimals.getValue()) {
                     break;
                  }
               } else if (EntityUtil.isMobAggressive(target) && (Boolean)this.attackMobs.getValue()) {
                  break;
               }
            }

            this.attack(target);
         }
      }
   }

   private boolean checkSharpness(ItemStack stack) {
      if (stack.func_77978_p() == null) {
         return false;
      } else if (stack.func_77973_b().equals(Items.field_151056_x) && ((BruceAura.HitMode)this.hitMode.getValue()).equals(BruceAura.HitMode.SWORD)) {
         return false;
      } else if (stack.func_77973_b().equals(Items.field_151048_u) && ((BruceAura.HitMode)this.hitMode.getValue()).equals(BruceAura.HitMode.AXE)) {
         return false;
      } else {
         NBTTagList enchants = (NBTTagList)stack.func_77978_p().func_74781_a("ench");
         if (enchants == null) {
            return false;
         } else {
            for(int i = 0; i < enchants.func_74745_c(); ++i) {
               NBTTagCompound enchant = enchants.func_150305_b(i);
               if (enchant.func_74762_e("id") == 16) {
                  int lvl = enchant.func_74762_e("lvl");
                  if (((BruceAura.SwitchMode)this.switchMode.getValue()).equals(BruceAura.SwitchMode.Only32k)) {
                     if (lvl >= 42) {
                        return true;
                     }
                  } else if (((BruceAura.SwitchMode)this.switchMode.getValue()).equals(BruceAura.SwitchMode.ALL)) {
                     if (lvl >= 4) {
                        return true;
                     }
                  } else if (((BruceAura.SwitchMode)this.switchMode.getValue()).equals(BruceAura.SwitchMode.NONE)) {
                     return true;
                  }
                  break;
               }
            }

            return false;
         }
      }
   }

   private void attack(Entity e) {
      boolean holding32k = false;
      if (this.checkSharpness(mc.field_71439_g.func_184614_ca())) {
         holding32k = true;
      }

      if ((((BruceAura.SwitchMode)this.switchMode.getValue()).equals(BruceAura.SwitchMode.Only32k) || ((BruceAura.SwitchMode)this.switchMode.getValue()).equals(BruceAura.SwitchMode.ALL)) && !holding32k) {
         int newSlot = -1;

         for(int i = 0; i < 9; ++i) {
            ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (stack != ItemStack.field_190927_a && this.checkSharpness(stack)) {
               newSlot = i;
               break;
            }
         }

         if (newSlot != -1) {
            mc.field_71439_g.field_71071_by.field_70461_c = newSlot;
            holding32k = true;
         }
      }

      if (!((BruceAura.SwitchMode)this.switchMode.getValue()).equals(BruceAura.SwitchMode.Only32k) || holding32k) {
         mc.field_71442_b.func_78764_a(mc.field_71439_g, e);
         mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
      }
   }

   private float getLagComp() {
      return ((BruceAura.WaitMode)this.waitMode.getValue()).equals(BruceAura.WaitMode.CPS) ? -(20.0F - LagCompensator.INSTANCE.getTickRate()) : 0.0F;
   }

   private boolean canEntityFeetBeSeen(Entity entityIn) {
      return mc.field_71441_e.func_147447_a(new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + (double)mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v), new Vec3d(entityIn.field_70165_t, entityIn.field_70163_u, entityIn.field_70161_v), false, true, false) == null;
   }

   private static enum WaitMode {
      CPS,
      TICK;
   }

   private static enum HitMode {
      SWORD,
      AXE;
   }

   private static enum SwitchMode {
      NONE,
      ALL,
      Only32k;
   }
}
