package me.travis.wurstplus.module.modules.DispenserPVP;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.module.modules.combat.CrystalAura;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.travis.wurstplus.util.BlockInteractionHelper;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockLiquid;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.network.play.client.CPacketPlayer.Rotation;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;

@Module.Info(
   name = "Auto32kVersionOne",
   category = Module.Category.DispenserPVP
)
public class Auto32kVersionOne extends Module {
   private static final DecimalFormat df = new DecimalFormat("#.#");
   private static final List shulkerList;
   private Setting moveToHotbar = this.register(Settings.b("Move 32k to Hotbar", true));
   private Setting placeRange = this.register(Settings.d("Place Range", 5.0D));
   private Setting spoofRotation = this.register(Settings.b("Spoof Rotation", true));
   private Setting raytraceCheck = this.register(Settings.b("Raytrace Check", true));
   private Setting debugMessages = this.register(Settings.b("Debug Messages", false));
   private Setting wait = this.register(Settings.integerBuilder("Hopper Wait").withMinimum(1).withValue((int)10).withMaximum(20).build());
   private boolean dispenserPlace;
   private boolean flag;
   private boolean lastBlock;
   private int hopperSlot;
   private int delay;
   private int swordSlot;
   private int shulkerSlot;
   private int obiSlot;
   private int redSlot;
   private int disSlot;
   private Float yaw;
   public int xPlus;
   public int zPlus;
   public double xDis;
   public double zDis;
   public EnumFacing face;
   private BlockPos placeTarget;

   protected void onEnable() {
      if (mc.field_71439_g == null) {
         this.disable();
      } else {
         this.delay = 0;
         this.lastBlock = false;
         this.dispenserPlace = false;
         this.flag = true;
         df.setRoundingMode(RoundingMode.CEILING);
         this.hopperSlot = -1;
         this.obiSlot = -1;
         this.redSlot = -1;
         this.disSlot = -1;
         this.swordSlot = -1;
         this.shulkerSlot = -1;
         boolean isNegative = false;
         this.yaw = mc.field_71439_g.field_70177_z;
         if (this.yaw < 0.0F) {
            isNegative = true;
         }

         int dir = Math.round(Math.abs(this.yaw)) % 360;
         if (135 < dir && dir < 225) {
            this.xPlus = 0;
            this.zPlus = 1;
            this.xDis = 0.0D;
            this.zDis = -0.1D;
            this.face = EnumFacing.SOUTH;
         } else if (225 < dir && dir < 315) {
            if (isNegative) {
               this.xPlus = 1;
               this.zPlus = 0;
               this.xDis = 0.1D;
               this.zDis = 0.0D;
               this.face = EnumFacing.EAST;
            } else {
               this.xPlus = -1;
               this.zPlus = 0;
               this.xDis = -0.1D;
               this.zDis = 0.0D;
               this.face = EnumFacing.WEST;
            }
         } else if (45 < dir && dir < 135) {
            if (isNegative) {
               this.xPlus = -1;
               this.zPlus = 0;
               this.xDis = -0.1D;
               this.zDis = 0.0D;
               this.face = EnumFacing.WEST;
            } else {
               this.xPlus = 1;
               this.zPlus = 0;
               this.xDis = 0.1D;
               this.zDis = 0.0D;
               this.face = EnumFacing.EAST;
            }
         } else {
            this.xPlus = 0;
            this.zPlus = -1;
            this.xDis = 0.0D;
            this.zDis = 0.1D;
            this.face = EnumFacing.NORTH;
         }

         for(int i = 0; i < 9 && (this.hopperSlot == -1 || this.shulkerSlot == -1 || this.obiSlot == -1 || this.redSlot == -1 || this.disSlot == -1); ++i) {
            ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (stack != ItemStack.field_190927_a && stack.func_77973_b() instanceof ItemBlock) {
               Block block = ((ItemBlock)stack.func_77973_b()).func_179223_d();
               if (block == Blocks.field_150438_bZ) {
                  this.hopperSlot = i;
               } else if (shulkerList.contains(block)) {
                  this.shulkerSlot = i;
               } else if (block == Blocks.field_150343_Z) {
                  this.obiSlot = i;
               } else if (block == Blocks.field_150451_bX) {
                  this.redSlot = i;
               } else if (block == Blocks.field_150367_z) {
                  this.disSlot = i;
               }
            }
         }

         if (this.shulkerSlot != -1 && this.hopperSlot != -1 && this.obiSlot != -1 && this.redSlot != -1 && this.disSlot != -1) {
            try {
               this.placeTarget = new BlockPos((double)mc.field_71476_x.func_178782_a().func_177958_n(), (double)mc.field_71476_x.func_178782_a().func_177956_o() + 1.0D, (double)mc.field_71476_x.func_178782_a().func_177952_p());
            } catch (Exception var6) {
               Command.sendChatMessage("right mate, ur fucking retarded if you think that's a block");
               this.disable();
               return;
            }

            if (this.isAreaPlaceable(this.placeTarget)) {
               Command.sendChatMessage("server is lagging");
               mc.field_71439_g.field_71071_by.field_70461_c = this.obiSlot;
               this.placeBlock(new BlockPos(this.placeTarget), (Boolean)this.spoofRotation.getValue());
               mc.field_71439_g.field_71071_by.field_70461_c = this.disSlot;
               this.placeBlock(new BlockPos(this.placeTarget.func_177982_a(0, 1, 0)), (Boolean)this.spoofRotation.getValue());
               mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItemOnBlock(new BlockPos(this.placeTarget.func_177982_a(0, 1, 0)), EnumFacing.DOWN, EnumHand.MAIN_HAND, 0.0F, 0.0F, 0.0F));
            } else {
               Command.sendChatMessage("there's no place my g");
               this.disable();
            }
         } else {
            if ((Boolean)this.debugMessages.getValue()) {
               Command.sendChatMessage("Ensure all blocks needed are in your hotbar x");
            }

            this.disable();
         }
      }
   }

   public void onUpdate() {
      if (!this.isDisabled() && mc.field_71439_g != null) {
         if (this.lastBlock && this.delay >= (Integer)this.wait.getValue()) {
            mc.field_71439_g.field_71071_by.field_70461_c = this.hopperSlot;
            BlockPos hopperPos = new BlockPos(this.placeTarget.func_177982_a(this.xPlus, 0, this.zPlus));
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.START_SNEAKING));
            this.placeBlock(hopperPos, (Boolean)this.spoofRotation.getValue());
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.STOP_SNEAKING));
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItemOnBlock(new BlockPos(this.placeTarget.func_177982_a(this.xPlus, 0, this.zPlus)), this.face, EnumHand.MAIN_HAND, 0.0F, 0.0F, 0.0F));
            mc.field_71439_g.field_71071_by.field_70461_c = this.shulkerSlot;
            this.swordSlot = this.shulkerSlot + 32;
            this.lastBlock = false;
            this.delay = 0;
         }

         if (!this.dispenserPlace) {
            this.placeItemsInDispenser();
         } else {
            if (this.flag) {
               this.placeRestOfBlocks();
            }

            if (!(mc.field_71462_r instanceof GuiContainer)) {
               ++this.delay;
            } else if (!(Boolean)this.moveToHotbar.getValue()) {
               this.disable();
            } else if (this.swordSlot == -1) {
               ++this.delay;
            } else {
               boolean swapReady = true;
               if (((GuiContainer)mc.field_71462_r).field_147002_h.func_75139_a(0).func_75211_c().field_190928_g) {
                  ++this.delay;
                  swapReady = false;
               }

               if (!((GuiContainer)mc.field_71462_r).field_147002_h.func_75139_a(this.swordSlot).func_75211_c().field_190928_g) {
                  ++this.delay;
                  swapReady = false;
               }

               if (swapReady) {
                  mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, 0, this.swordSlot - 32, ClickType.SWAP, mc.field_71439_g);
                  this.disable();
               }

            }
         }
      }
   }

   private boolean isAreaPlaceable(BlockPos blockPos) {
      Iterator var2 = mc.field_71441_e.func_72839_b((Entity)null, new AxisAlignedBB(blockPos)).iterator();

      while(var2.hasNext()) {
         Entity entity = (Entity)var2.next();
         if (entity instanceof EntityLivingBase) {
            return false;
         }
      }

      if (!mc.field_71441_e.func_180495_p(blockPos).func_185904_a().func_76222_j()) {
         return false;
      } else if (!mc.field_71441_e.func_180495_p(blockPos.func_177982_a(0, 1, 0)).func_185904_a().func_76222_j()) {
         return false;
      } else if (!mc.field_71441_e.func_180495_p(blockPos.func_177982_a(this.xPlus, 0, this.zPlus)).func_185904_a().func_76222_j()) {
         return false;
      } else if (!mc.field_71441_e.func_180495_p(blockPos.func_177982_a(this.xPlus, 1, this.zPlus)).func_185904_a().func_76222_j()) {
         return false;
      } else if (!mc.field_71441_e.func_180495_p(blockPos.func_177982_a(0, 2, 0)).func_185904_a().func_76222_j()) {
         return false;
      } else if (mc.field_71441_e.func_180495_p(blockPos.func_177982_a(0, -1, 0)).func_177230_c() instanceof BlockAir) {
         return false;
      } else if (mc.field_71441_e.func_180495_p(blockPos.func_177982_a(0, -1, 0)).func_177230_c() instanceof BlockLiquid) {
         return false;
      } else if (mc.field_71439_g.func_174791_d().func_72438_d(new Vec3d(blockPos)) > (Double)this.placeRange.getValue()) {
         return false;
      } else if (!(Boolean)this.raytraceCheck.getValue()) {
         return true;
      } else {
         RayTraceResult result = mc.field_71441_e.func_147447_a(new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + (double)mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v), new Vec3d(blockPos), false, true, false);
         return result == null || result.func_178782_a().equals(blockPos);
      }
   }

   private void placeBlock(BlockPos pos, boolean spoofRotation) {
      if (!mc.field_71441_e.func_180495_p(pos).func_185904_a().func_76222_j()) {
         Command.sendChatMessage("BLOCK WAS UNABLE TO BE PLACED :(");
      } else {
         EnumFacing[] var3 = EnumFacing.values();
         int var4 = var3.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            EnumFacing side = var3[var5];
            BlockPos neighbor = pos.func_177972_a(side);
            EnumFacing side2 = side.func_176734_d();
            if (mc.field_71441_e.func_180495_p(neighbor).func_177230_c().func_176209_a(mc.field_71441_e.func_180495_p(neighbor), false)) {
               Vec3d hitVec = (new Vec3d(neighbor)).func_72441_c(0.5D + this.xDis, 0.5D, 0.5D + this.zDis).func_178787_e((new Vec3d(side2.func_176730_m())).func_186678_a(0.5D));
               if (spoofRotation) {
                  Vec3d eyesPos = new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + (double)mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v);
                  double diffX = hitVec.field_72450_a - eyesPos.field_72450_a;
                  double diffY = hitVec.field_72448_b - eyesPos.field_72448_b;
                  double diffZ = hitVec.field_72449_c - eyesPos.field_72449_c;
                  double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
                  float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
                  float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)));
                  mc.field_71439_g.field_71174_a.func_147297_a(new Rotation(mc.field_71439_g.field_70177_z + MathHelper.func_76142_g(yaw - mc.field_71439_g.field_70177_z), mc.field_71439_g.field_70125_A + MathHelper.func_76142_g(pitch - mc.field_71439_g.field_70125_A), mc.field_71439_g.field_70122_E));
               }

               mc.field_71442_b.func_187099_a(mc.field_71439_g, mc.field_71441_e, neighbor, side2, hitVec, EnumHand.MAIN_HAND);
               mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
               mc.field_71467_ac = 4;
               return;
            }
         }

      }
   }

   public static BlockPos getPlayerPos() {
      return new BlockPos(Math.floor(CrystalAura.mc.field_71439_g.field_70165_t), Math.floor(CrystalAura.mc.field_71439_g.field_70163_u), Math.floor(CrystalAura.mc.field_71439_g.field_70161_v));
   }

   public List getSphere(BlockPos loc, float r, int h, boolean hollow, boolean sphere, int plus_y) {
      List circleblocks = new ArrayList();
      int cx = loc.func_177958_n();
      int cy = loc.func_177956_o();
      int cz = loc.func_177952_p();

      for(int x = cx - (int)r; (float)x <= (float)cx + r; ++x) {
         for(int z = cz - (int)r; (float)z <= (float)cz + r; ++z) {
            for(int y = sphere ? cy - (int)r : cy; (float)y < (sphere ? (float)cy + r : (float)(cy + h)); ++y) {
               double dist = (double)((cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? (cy - y) * (cy - y) : 0));
               if (dist < (double)(r * r) && (!hollow || dist >= (double)((r - 1.0F) * (r - 1.0F)))) {
                  BlockPos l = new BlockPos(x, y + plus_y, z);
                  circleblocks.add(l);
               }
            }
         }
      }

      return circleblocks;
   }

   public void placeRestOfBlocks() {
      mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.START_SNEAKING));
      mc.field_71439_g.field_71071_by.field_70461_c = this.redSlot;
      this.placeBlock(new BlockPos(this.placeTarget.func_177982_a(0, 2, 0)), (Boolean)this.spoofRotation.getValue());
      mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.STOP_SNEAKING));
      this.flag = false;
      this.lastBlock = true;
   }

   public void placeItemsInDispenser() {
      try {
         mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, 0, this.shulkerSlot, ClickType.SWAP, mc.field_71439_g);
         this.dispenserPlace = true;
      } catch (Exception var2) {
      }
   }

   public void faceBlock(BlockPos pos, EnumFacing face) {
      Vec3d hitVec = (new Vec3d(pos.func_177972_a(face))).func_72441_c(0.5D, 0.5D, 0.5D).func_178787_e((new Vec3d(face.func_176730_m())).func_186678_a(0.5D));
      BlockInteractionHelper.faceVectorPacketInstant(hitVec);
   }

   static {
      shulkerList = Arrays.asList(Blocks.field_190977_dl, Blocks.field_190978_dm, Blocks.field_190979_dn, Blocks.field_190980_do, Blocks.field_190981_dp, Blocks.field_190982_dq, Blocks.field_190983_dr, Blocks.field_190984_ds, Blocks.field_190985_dt, Blocks.field_190986_du, Blocks.field_190987_dv, Blocks.field_190988_dw, Blocks.field_190989_dx, Blocks.field_190990_dy, Blocks.field_190991_dz, Blocks.field_190975_dA);
   }
}
