package me.travis.wurstplus.setting.builder.primitive;

import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.builder.SettingBuilder;
import me.travis.wurstplus.setting.impl.EnumSetting;

public class EnumSettingBuilder extends SettingBuilder {
   Class clazz;

   public EnumSettingBuilder(Class clazz) {
      this.clazz = clazz;
   }

   public Setting build() {
      return new EnumSetting((Enum)this.initialValue, this.predicate(), this.consumer(), this.name, this.visibilityPredicate(), this.clazz);
   }
}
