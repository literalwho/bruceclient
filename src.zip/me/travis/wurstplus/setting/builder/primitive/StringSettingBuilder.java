package me.travis.wurstplus.setting.builder.primitive;

import me.travis.wurstplus.setting.builder.SettingBuilder;
import me.travis.wurstplus.setting.impl.StringSetting;

public class StringSettingBuilder extends SettingBuilder {
   public StringSetting build() {
      return new StringSetting((String)this.initialValue, this.predicate(), this.consumer(), this.name, this.visibilityPredicate());
   }
}
