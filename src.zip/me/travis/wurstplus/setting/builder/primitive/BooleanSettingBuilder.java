package me.travis.wurstplus.setting.builder.primitive;

import me.travis.wurstplus.setting.builder.SettingBuilder;
import me.travis.wurstplus.setting.impl.BooleanSetting;

public class BooleanSettingBuilder extends SettingBuilder {
   public BooleanSetting build() {
      return new BooleanSetting((Boolean)this.initialValue, this.predicate(), this.consumer(), this.name, this.visibilityPredicate());
   }

   public BooleanSettingBuilder withName(String name) {
      return (BooleanSettingBuilder)super.withName(name);
   }
}
