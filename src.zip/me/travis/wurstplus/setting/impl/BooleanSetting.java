package me.travis.wurstplus.setting.impl;

import java.util.function.BiConsumer;
import java.util.function.Predicate;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.converter.BooleanConverter;

public class BooleanSetting extends Setting {
   private static final BooleanConverter converter = new BooleanConverter();

   public BooleanSetting(Boolean value, Predicate restriction, BiConsumer consumer, String name, Predicate visibilityPredicate) {
      super(value, restriction, consumer, name, visibilityPredicate);
   }

   public BooleanConverter converter() {
      return converter;
   }
}
