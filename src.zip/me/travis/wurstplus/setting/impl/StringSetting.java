package me.travis.wurstplus.setting.impl;

import java.util.function.BiConsumer;
import java.util.function.Predicate;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.converter.StringConverter;

public class StringSetting extends Setting {
   private static final StringConverter converter = new StringConverter();

   public StringSetting(String value, Predicate restriction, BiConsumer consumer, String name, Predicate visibilityPredicate) {
      super(value, restriction, consumer, name, visibilityPredicate);
   }

   public StringConverter converter() {
      return converter;
   }
}
