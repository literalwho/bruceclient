package me.travis.wurstplus.setting.converter;

import com.google.common.base.Converter;

public interface Convertable {
   Converter converter();
}
