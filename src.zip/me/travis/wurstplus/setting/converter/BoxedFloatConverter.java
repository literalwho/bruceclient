package me.travis.wurstplus.setting.converter;

import com.google.gson.JsonElement;

public class BoxedFloatConverter extends AbstractBoxedNumberConverter {
   protected Float doBackward(JsonElement s) {
      return s.getAsFloat();
   }
}
