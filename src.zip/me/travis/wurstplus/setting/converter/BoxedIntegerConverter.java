package me.travis.wurstplus.setting.converter;

import com.google.gson.JsonElement;

public class BoxedIntegerConverter extends AbstractBoxedNumberConverter {
   protected Integer doBackward(JsonElement s) {
      return s.getAsInt();
   }
}
