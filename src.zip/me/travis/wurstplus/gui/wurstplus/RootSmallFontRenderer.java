package me.travis.wurstplus.gui.wurstplus;

public class RootSmallFontRenderer extends RootFontRenderer {
   public RootSmallFontRenderer() {
      super(0.75F);
   }
}
