package me.travis.wurstplus.gui.wurstplus;

public class RootLargeFontRenderer extends RootFontRenderer {
   public RootLargeFontRenderer() {
      super(1.2F);
   }
}
