package me.travis.wurstplus.gui.wurstplus.theme.staticui;

import java.util.Iterator;
import me.travis.wurstplus.gui.rgui.render.AbstractComponentUI;
import me.travis.wurstplus.gui.rgui.render.font.FontRenderer;
import me.travis.wurstplus.gui.wurstplus.RenderHelper;
import me.travis.wurstplus.gui.wurstplus.component.Radar;
import me.travis.wurstplus.util.EntityUtil;
import me.travis.wurstplus.util.Wrapper;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import org.lwjgl.opengl.GL11;

public class RadarUI extends AbstractComponentUI {
   float scale = 2.0F;
   public static final int radius = 45;

   public void handleSizeComponent(Radar component) {
      component.setWidth(90);
      component.setHeight(90);
   }

   public void renderComponent(Radar component, FontRenderer fontRenderer) {
      this.scale = 2.0F;
      GL11.glTranslated((double)(component.getWidth() / 2), (double)(component.getHeight() / 2), 0.0D);
      GlStateManager.func_179090_x();
      GlStateManager.func_179140_f();
      GlStateManager.func_179147_l();
      GlStateManager.func_179129_p();
      GlStateManager.func_179094_E();
      GL11.glColor4f(0.11F, 0.11F, 0.11F, 0.6F);
      RenderHelper.drawCircle(0.0F, 0.0F, 45.0F);
      GL11.glRotatef(Wrapper.getPlayer().field_70177_z + 180.0F, 0.0F, 0.0F, -1.0F);
      Iterator var3 = Wrapper.getWorld().field_72996_f.iterator();

      while(var3.hasNext()) {
         Entity e = (Entity)var3.next();
         if (e instanceof EntityLiving) {
            float red = 1.0F;
            float green = 1.0F;
            if (EntityUtil.isPassive(e)) {
               red = 0.0F;
            } else {
               green = 0.0F;
            }

            double dX = e.field_70165_t - Wrapper.getPlayer().field_70165_t;
            double dZ = e.field_70161_v - Wrapper.getPlayer().field_70161_v;
            double distance = Math.sqrt(Math.pow(dX, 2.0D) + Math.pow(dZ, 2.0D));
            if (distance <= (double)(45.0F * this.scale) && Math.abs(Wrapper.getPlayer().field_70163_u - e.field_70163_u) <= 30.0D) {
               GL11.glColor4f(red, green, 0.0F, 0.5F);
               RenderHelper.drawCircle((float)((int)dX) / this.scale, (float)((int)dZ) / this.scale, 2.5F / this.scale);
            }
         }
      }

      GL11.glColor3f(1.0F, 1.0F, 1.0F);
      RenderHelper.drawCircle(0.0F, 0.0F, 3.0F / this.scale);
      GL11.glLineWidth(1.8F);
      GL11.glColor3f(0.59F, 0.05F, 0.11F);
      GL11.glEnable(2848);
      RenderHelper.drawCircleOutline(0.0F, 0.0F, 45.0F);
      GL11.glDisable(2848);
      component.getTheme().getFontRenderer().drawString(-component.getTheme().getFontRenderer().getStringWidth("+z") / 2, 45 - component.getTheme().getFontRenderer().getFontHeight(), "§7z+");
      GL11.glRotatef(90.0F, 0.0F, 0.0F, 1.0F);
      component.getTheme().getFontRenderer().drawString(-component.getTheme().getFontRenderer().getStringWidth("+x") / 2, 45 - component.getTheme().getFontRenderer().getFontHeight(), "§7x-");
      GL11.glRotatef(90.0F, 0.0F, 0.0F, 1.0F);
      component.getTheme().getFontRenderer().drawString(-component.getTheme().getFontRenderer().getStringWidth("-z") / 2, 45 - component.getTheme().getFontRenderer().getFontHeight(), "§7z-");
      GL11.glRotatef(90.0F, 0.0F, 0.0F, 1.0F);
      component.getTheme().getFontRenderer().drawString(-component.getTheme().getFontRenderer().getStringWidth("+x") / 2, 45 - component.getTheme().getFontRenderer().getFontHeight(), "§7x+");
      GlStateManager.func_179121_F();
      GlStateManager.func_179098_w();
      GL11.glTranslated((double)(-component.getWidth() / 2), (double)(-component.getHeight() / 2), 0.0D);
   }
}
