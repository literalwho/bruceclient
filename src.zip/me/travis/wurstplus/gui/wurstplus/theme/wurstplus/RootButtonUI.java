package me.travis.wurstplus.gui.wurstplus.theme.wurstplus;

import java.awt.Color;
import me.travis.wurstplus.gui.rgui.component.container.Container;
import me.travis.wurstplus.gui.rgui.component.use.Button;
import me.travis.wurstplus.gui.rgui.render.AbstractComponentUI;
import me.travis.wurstplus.gui.rgui.render.font.FontRenderer;
import me.travis.wurstplus.gui.wurstplus.RenderHelper;
import me.travis.wurstplus.gui.wurstplus.wurstplusGUI;
import org.lwjgl.opengl.GL11;

public class RootButtonUI extends AbstractComponentUI {
   protected Color idleColour = new Color(25, 208, 194);
   protected Color downColour = new Color(25, 208, 194);

   public void renderComponent(Button component, FontRenderer ff) {
      GL11.glColor3f(0.0F, 0.0F, 102.0F);
      if (component.isHovered() || component.isPressed()) {
         GL11.glColor3f(0.0F, 0.0F, 255.0F);
      }

      RenderHelper.drawRoundedRectangle(0.0F, 0.0F, (float)component.getWidth(), (float)component.getHeight(), 3.0F);
      GL11.glColor3f(25.0F, 208.0F, 194.0F);
      GL11.glEnable(3553);
      wurstplusGUI.fontRenderer.drawString(component.getWidth() / 2 - wurstplusGUI.fontRenderer.getStringWidth(component.getName()) / 2, 0, component.isPressed() ? this.downColour : this.idleColour, component.getName());
      GL11.glDisable(3553);
      GL11.glDisable(3042);
   }

   public void handleAddComponent(Button component, Container container) {
      component.setWidth(wurstplusGUI.fontRenderer.getStringWidth(component.getName()) + 28);
      component.setHeight(wurstplusGUI.fontRenderer.getFontHeight() + 2);
   }
}
