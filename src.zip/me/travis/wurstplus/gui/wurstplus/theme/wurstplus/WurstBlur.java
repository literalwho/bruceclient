package me.travis.wurstplus.gui.wurstplus.theme.wurstplus;

import me.travis.wurstplus.gui.rgui.component.container.use.Frame;
import me.travis.wurstplus.gui.rgui.render.AbstractComponentUI;
import me.travis.wurstplus.gui.rgui.render.font.FontRenderer;
import me.travis.wurstplus.gui.wurstplus.RenderHelper;

public class WurstBlur extends AbstractComponentUI {
   public void renderComponent(Frame component, FontRenderer fontRenderer) {
      RenderHelper.blurScreen();
   }
}
