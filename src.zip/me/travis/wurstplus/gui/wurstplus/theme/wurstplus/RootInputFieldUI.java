package me.travis.wurstplus.gui.wurstplus.theme.wurstplus;

import me.travis.wurstplus.gui.rgui.component.container.Container;
import me.travis.wurstplus.gui.rgui.component.use.InputField;
import me.travis.wurstplus.gui.rgui.render.AbstractComponentUI;
import me.travis.wurstplus.gui.rgui.render.font.FontRenderer;
import me.travis.wurstplus.gui.wurstplus.RenderHelper;
import org.lwjgl.opengl.GL11;

public class RootInputFieldUI extends AbstractComponentUI {
   public void renderComponent(InputField component, FontRenderer fontRenderer) {
      GL11.glColor3f(0.0F, 0.0F, 102.0F);
      RenderHelper.drawFilledRectangle(0.0F, 0.0F, (float)component.getWidth(), (float)component.getHeight());
      GL11.glLineWidth(1.5F);
      GL11.glColor4f(0.0F, 0.0F, 100.0F, 10.0F);
      RenderHelper.drawRectangle(0.0F, 0.0F, (float)component.getWidth(), (float)component.getHeight());
   }

   public void handleAddComponent(InputField component, Container container) {
      component.setWidth(200);
      component.setHeight(component.getTheme().getFontRenderer().getFontHeight());
   }
}
