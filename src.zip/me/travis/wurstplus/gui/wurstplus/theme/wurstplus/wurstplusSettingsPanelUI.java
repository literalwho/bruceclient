package me.travis.wurstplus.gui.wurstplus.theme.wurstplus;

import me.travis.wurstplus.gui.rgui.render.AbstractComponentUI;
import me.travis.wurstplus.gui.rgui.render.font.FontRenderer;
import me.travis.wurstplus.gui.wurstplus.RenderHelper;
import me.travis.wurstplus.gui.wurstplus.component.SettingsPanel;
import org.lwjgl.opengl.GL11;

public class wurstplusSettingsPanelUI extends AbstractComponentUI {
   public void renderComponent(SettingsPanel component, FontRenderer fontRenderer) {
      super.renderComponent(component, fontRenderer);
      GL11.glLineWidth(2.0F);
      GL11.glColor4f(0.0F, 65.0F, 255.0F, 50.0F);
      RenderHelper.drawFilledRectangle(0.0F, 0.0F, (float)component.getWidth(), (float)component.getHeight());
      GL11.glColor3f(0.0F, 25.0F, 255.0F);
      GL11.glLineWidth(2.5F);
      RenderHelper.drawRectangle(0.0F, 0.0F, (float)component.getWidth(), (float)component.getHeight());
   }
}
