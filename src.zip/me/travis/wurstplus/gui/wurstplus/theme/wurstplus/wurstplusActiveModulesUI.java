package me.travis.wurstplus.gui.wurstplus.theme.wurstplus;

import java.awt.Color;
import java.awt.Font;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;
import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.gui.font.CFontRenderer;
import me.travis.wurstplus.gui.rgui.component.AlignedComponent;
import me.travis.wurstplus.gui.rgui.render.AbstractComponentUI;
import me.travis.wurstplus.gui.rgui.render.font.FontRenderer;
import me.travis.wurstplus.gui.wurstplus.component.ActiveModules;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.module.ModuleManager;
import me.travis.wurstplus.util.ColourUtils;
import me.travis.wurstplus.util.Wrapper;
import org.lwjgl.opengl.GL11;

public class wurstplusActiveModulesUI extends AbstractComponentUI {
   CFontRenderer cFontRenderer = new CFontRenderer(new Font("Calibri", 0, 20), true, false);

   public void renderComponent(ActiveModules component, FontRenderer f) {
      GL11.glDisable(2884);
      GL11.glEnable(3042);
      GL11.glEnable(3553);
      FontRenderer renderer = Wrapper.getFontRenderer();
      List mods = (List)ModuleManager.getModules().stream().filter(Module::isEnabled).sorted(Comparator.comparing((module) -> {
         return this.cFontRenderer.getStringWidth(module.getName() + (module.getHudInfo() == null ? "" : module.getHudInfo() + " ")) * (component.sort_up ? -1 : 1);
      })).collect(Collectors.toList());
      int[] y = new int[]{2};
      if (component.getParent().getY() < 26 && Wrapper.getPlayer().func_70651_bq().size() > 0 && component.getParent().getOpacity() == 0.0F) {
         y[0] = Math.max(component.getParent().getY(), 26 - component.getParent().getY());
      }

      float[] hue = new float[]{(float)(System.currentTimeMillis() % 11520L) / 11520.0F};
      boolean lAlign = component.getAlignment() == AlignedComponent.Alignment.LEFT;
      Function xFunc;
      switch(component.getAlignment()) {
      case RIGHT:
         xFunc = (i) -> {
            return component.getWidth() - i;
         };
         break;
      case CENTER:
         xFunc = (i) -> {
            return component.getWidth() / 2 - i / 2;
         };
         break;
      case LEFT:
      default:
         xFunc = (i) -> {
            return 0;
         };
      }

      mods.stream().forEach((module) -> {
         int rgb = Color.HSBtoRGB(hue[0], 1.0F, 1.0F);
         String s = module.getHudInfo();
         String text = module.getName() + (s == null ? "" : " " + Command.SECTIONSIGN() + "7" + s);
         int textwidth = this.cFontRenderer.getStringWidth(text);
         int textheight = renderer.getFontHeight() + 1;
         int red = rgb >> 16 & 255;
         int green = rgb >> 8 & 255;
         int blue = rgb & 255;
         int trgb = ColourUtils.toRGBA(red, green, blue, 255);
         this.cFontRenderer.drawStringWithShadow(text, (double)(Integer)xFunc.apply(textwidth), (double)y[0], trgb);
         hue[0] += 0.02F;
         y[0] += textheight;
      });
      component.setHeight(y[0]);
      GL11.glEnable(2884);
      GL11.glDisable(3042);
   }

   public void handleSizeComponent(ActiveModules component) {
      component.setWidth(100);
      component.setHeight(100);
   }
}
