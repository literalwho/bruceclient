package me.travis.wurstplus.gui.wurstplus.theme.wurstplus;

import me.travis.wurstplus.gui.font.CFontRenderer;
import me.travis.wurstplus.gui.rgui.render.AbstractComponentUI;
import me.travis.wurstplus.gui.rgui.render.font.FontRenderer;
import me.travis.wurstplus.gui.rgui.render.theme.AbstractTheme;
import me.travis.wurstplus.gui.wurstplus.wurstplusGUI;
import me.travis.wurstplus.gui.wurstplus.theme.staticui.RadarUI;
import me.travis.wurstplus.gui.wurstplus.theme.staticui.TabGuiUI;

public class wurstplusTheme extends AbstractTheme {
   FontRenderer fontRenderer;
   CFontRenderer CFontRenderer;

   public wurstplusTheme() {
      this.installUI(new WurstBlur());
      this.installUI(new RootButtonUI());
      this.installUI(new wurstplusTheme.GUIUI());
      this.installUI(new RootGroupboxUI());
      this.installUI(new wurstplusFrameUI());
      this.installUI(new RootScrollpaneUI());
      this.installUI(new RootInputFieldUI());
      this.installUI(new RootLabelUI());
      this.installUI(new RootChatUI());
      this.installUI(new RootCheckButtonUI());
      this.installUI(new wurstplusActiveModulesUI());
      this.installUI(new wurstplusSettingsPanelUI());
      this.installUI(new RootSliderUI());
      this.installUI(new wurstplusEnumbuttonUI());
      this.installUI(new RootColorizedCheckButtonUI());
      this.installUI(new wurstplusUnboundSliderUI());
      this.installUI(new RadarUI());
      this.installUI(new TabGuiUI());
      this.fontRenderer = wurstplusGUI.fontRenderer;
   }

   public FontRenderer getFontRenderer() {
      return this.fontRenderer;
   }

   public class GUIUI extends AbstractComponentUI {
   }
}
