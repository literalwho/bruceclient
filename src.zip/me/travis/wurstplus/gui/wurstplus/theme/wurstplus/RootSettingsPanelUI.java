package me.travis.wurstplus.gui.wurstplus.theme.wurstplus;

import me.travis.wurstplus.gui.rgui.render.AbstractComponentUI;
import me.travis.wurstplus.gui.rgui.render.font.FontRenderer;
import me.travis.wurstplus.gui.wurstplus.RenderHelper;
import me.travis.wurstplus.gui.wurstplus.component.SettingsPanel;
import org.lwjgl.opengl.GL11;

public class RootSettingsPanelUI extends AbstractComponentUI {
   public void renderComponent(SettingsPanel component, FontRenderer fontRenderer) {
      GL11.glColor4f(0.0F, 0.0F, 102.0F, 30.0F);
      RenderHelper.drawOutlinedRoundedRectangle(0, 0, component.getWidth(), component.getHeight(), 6.0F, 0.14F, 0.14F, 0.14F, component.getOpacity(), 1.0F);
   }
}
