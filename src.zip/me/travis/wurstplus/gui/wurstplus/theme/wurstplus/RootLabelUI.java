package me.travis.wurstplus.gui.wurstplus.theme.wurstplus;

import me.travis.wurstplus.gui.rgui.component.AlignedComponent;
import me.travis.wurstplus.gui.rgui.component.use.Label;
import me.travis.wurstplus.gui.rgui.render.AbstractComponentUI;
import me.travis.wurstplus.gui.rgui.render.font.FontRenderer;
import org.lwjgl.opengl.GL11;

public class RootLabelUI extends AbstractComponentUI {
   public void renderComponent(Label component, FontRenderer a) {
      a = component.getFontRenderer();
      String[] lines = component.getLines();
      int y = 0;
      boolean shadow = component.isShadow();
      String[] var6 = lines;
      int var7 = lines.length;

      for(int var8 = 0; var8 < var7; ++var8) {
         String s = var6[var8];
         int x = 0;
         if (component.getAlignment() == AlignedComponent.Alignment.CENTER) {
            x = component.getWidth() / 2 - a.getStringWidth(s) / 2;
         } else if (component.getAlignment() == AlignedComponent.Alignment.RIGHT) {
            x = component.getWidth() - a.getStringWidth(s);
         }

         if (shadow) {
            a.drawStringWithShadow(x, y, 0, 0, 102, s);
         } else {
            a.drawString(x, y, s);
         }

         y += a.getFontHeight() + 3;
      }

      GL11.glDisable(3553);
      GL11.glDisable(3042);
   }

   public void handleSizeComponent(Label component) {
      String[] lines = component.getLines();
      int y = 0;
      int w = 0;
      String[] var5 = lines;
      int var6 = lines.length;

      for(int var7 = 0; var7 < var6; ++var7) {
         String s = var5[var7];
         w = Math.max(w, component.getFontRenderer().getStringWidth(s));
         y += component.getFontRenderer().getFontHeight() + 3;
      }

      component.setWidth(w);
      component.setHeight(y);
   }
}
