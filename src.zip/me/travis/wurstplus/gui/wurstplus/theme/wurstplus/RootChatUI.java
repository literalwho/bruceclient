package me.travis.wurstplus.gui.wurstplus.theme.wurstplus;

import me.travis.wurstplus.gui.rgui.render.AbstractComponentUI;

public class RootChatUI extends AbstractComponentUI {
}
