package me.travis.wurstplus.gui.wurstplus;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Font;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Nonnull;
import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.gui.font.CFontRenderer;
import me.travis.wurstplus.gui.rgui.GUI;
import me.travis.wurstplus.gui.rgui.component.Component;
import me.travis.wurstplus.gui.rgui.component.container.use.Frame;
import me.travis.wurstplus.gui.rgui.component.container.use.Scrollpane;
import me.travis.wurstplus.gui.rgui.component.listen.MouseListener;
import me.travis.wurstplus.gui.rgui.component.listen.TickListener;
import me.travis.wurstplus.gui.rgui.component.use.CheckButton;
import me.travis.wurstplus.gui.rgui.component.use.Label;
import me.travis.wurstplus.gui.rgui.render.theme.Theme;
import me.travis.wurstplus.gui.rgui.util.ContainerHelper;
import me.travis.wurstplus.gui.rgui.util.Docking;
import me.travis.wurstplus.gui.wurstplus.component.ActiveModules;
import me.travis.wurstplus.gui.wurstplus.component.Radar;
import me.travis.wurstplus.gui.wurstplus.component.SettingsPanel;
import me.travis.wurstplus.gui.wurstplus.theme.wurstplus.wurstplusTheme;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.module.ModuleManager;
import me.travis.wurstplus.util.ColourHolder;
import me.travis.wurstplus.util.LagCompensator;
import me.travis.wurstplus.util.ModuleMan;
import me.travis.wurstplus.util.OnlineFriends;
import me.travis.wurstplus.util.Pair;
import me.travis.wurstplus.util.Wrapper;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityEgg;
import net.minecraft.entity.projectile.EntitySnowball;
import net.minecraft.entity.projectile.EntityWitherSkull;
import net.minecraft.util.text.TextFormatting;

public class wurstplusGUI extends GUI {
   public ModuleMan manager = new ModuleMan();
   public static final RootFontRenderer fontRenderer = new RootFontRenderer(1.0F);
   public Theme theme = this.getTheme();
   public static CFontRenderer cFontRenderer = new CFontRenderer(new Font("comic sans", 0, 18), true, false);
   public static ColourHolder primaryColour = new ColourHolder(29, 29, 29);
   private static final int DOCK_OFFSET = 0;

   public wurstplusGUI() {
      super(new wurstplusTheme());
   }

   public void drawGUI() {
      super.drawGUI();
   }

   public void initializeGUI() {
      HashMap categoryScrollpaneHashMap = new HashMap();
      Iterator var2 = ModuleManager.getModules().iterator();

      while(var2.hasNext()) {
         final Module module = (Module)var2.next();
         if (!module.getCategory().isHidden()) {
            Module.Category moduleCategory = module.getCategory();
            Scrollpane scrollpane;
            if (!categoryScrollpaneHashMap.containsKey(moduleCategory)) {
               Stretcherlayout stretcherlayout = new Stretcherlayout(1);
               stretcherlayout.setComponentOffsetWidth(0);
               scrollpane = new Scrollpane(this.getTheme(), stretcherlayout, 300, 260);
               scrollpane.setMaximumHeight(180);
               categoryScrollpaneHashMap.put(moduleCategory, new Pair(scrollpane, new SettingsPanel(this.getTheme(), (Module)null)));
            }

            final Pair pair = (Pair)categoryScrollpaneHashMap.get(moduleCategory);
            scrollpane = (Scrollpane)pair.getKey();
            final CheckButton checkButton = new CheckButton(module.getName());
            checkButton.setToggled(module.isEnabled());
            checkButton.addTickListener(() -> {
               checkButton.setToggled(module.isEnabled());
               checkButton.setName(module.getName());
            });
            checkButton.addMouseListener(new MouseListener() {
               public void onMouseDown(MouseListener.MouseButtonEvent event) {
                  if (event.getButton() == 1) {
                     ((SettingsPanel)pair.getValue()).setModule(module);
                     ((SettingsPanel)pair.getValue()).setX(event.getX() + checkButton.getX());
                     ((SettingsPanel)pair.getValue()).setY(event.getY() + checkButton.getY());
                  }

               }

               public void onMouseRelease(MouseListener.MouseButtonEvent event) {
               }

               public void onMouseDrag(MouseListener.MouseButtonEvent event) {
               }

               public void onMouseMove(MouseListener.MouseMoveEvent event) {
               }

               public void onScroll(MouseListener.MouseScrollEvent event) {
               }
            });
            checkButton.addPoof(new CheckButton.CheckButtonPoof() {
               public void execute(CheckButton component, CheckButton.CheckButtonPoof.CheckButtonPoofInfo info) {
                  if (info.getAction().equals(CheckButton.CheckButtonPoof.CheckButtonPoofInfo.CheckButtonPoofInfoAction.TOGGLE)) {
                     module.setEnabled(checkButton.isToggled());
                  }

               }
            });
            scrollpane.addChild(checkButton);
         }
      }

      int x = 10;
      int y = 10;
      int nexty = y;
      Iterator var23 = categoryScrollpaneHashMap.entrySet().iterator();

      while(var23.hasNext()) {
         Entry entry = (Entry)var23.next();
         Stretcherlayout stretcherlayout = new Stretcherlayout(1);
         stretcherlayout.COMPONENT_OFFSET_Y = 1;
         Frame frame = new Frame(this.getTheme(), stretcherlayout, ((Module.Category)entry.getKey()).getName());
         Scrollpane scrollpane = (Scrollpane)((Pair)entry.getValue()).getKey();
         frame.addChild(new Component[]{scrollpane});
         frame.addChild(new Component[]{(Component)((Pair)entry.getValue()).getValue()});
         scrollpane.setOriginOffsetY(0);
         scrollpane.setOriginOffsetX(0);
         frame.setCloseable(false);
         frame.setX(x);
         frame.setY(y);
         this.addChild(new Component[]{frame});
         nexty = Math.max(y + frame.getHeight() + 50, nexty);
         x += frame.getWidth() + 10;
         if ((float)x > (float)Wrapper.getMinecraft().field_71443_c / 1.2F) {
            y = nexty;
            nexty = nexty;
         }
      }

      this.addMouseListener(new MouseListener() {
         private boolean isBetween(int min, int val, int max) {
            return val <= max && val >= min;
         }

         public void onMouseDown(MouseListener.MouseButtonEvent event) {
            List panels = ContainerHelper.getAllChildren(SettingsPanel.class, wurstplusGUI.this);
            Iterator var3 = panels.iterator();

            while(true) {
               SettingsPanel settingsPanel;
               int pX;
               int pY;
               do {
                  do {
                     if (!var3.hasNext()) {
                        return;
                     }

                     settingsPanel = (SettingsPanel)var3.next();
                  } while(!settingsPanel.isVisible());

                  int[] real = GUI.calculateRealPosition(settingsPanel);
                  pX = event.getX() - real[0];
                  pY = event.getY() - real[1];
               } while(this.isBetween(0, pX, settingsPanel.getWidth()) && this.isBetween(0, pY, settingsPanel.getHeight()));

               settingsPanel.setVisible(false);
            }
         }

         public void onMouseRelease(MouseListener.MouseButtonEvent event) {
         }

         public void onMouseDrag(MouseListener.MouseButtonEvent event) {
         }

         public void onMouseMove(MouseListener.MouseMoveEvent event) {
         }

         public void onScroll(MouseListener.MouseScrollEvent event) {
         }
      });
      ArrayList frames = new ArrayList();
      Frame frame = new Frame(this.getTheme(), new Stretcherlayout(1), "Active Goods");
      frame.setCloseable(false);
      frame.addChild(new Component[]{new ActiveModules()});
      frame.setPinneable(true);
      frames.add(frame);
      frame = new Frame(this.getTheme(), new Stretcherlayout(1), "Welcomer");
      frame.setCloseable(false);
      frame.setPinneable(true);
      Label welcomer = new Label("");
      welcomer.setShadow(true);
      welcomer.addTickListener(() -> {
         welcomer.setText("");
         welcomer.addLine("§l§6" + Wrapper.getPlayer().getDisplayNameString() + "§r Bruce WIllis thinks you're looking sexy today!. §k /");
      });
      frame.addChild(new Component[]{welcomer});
      welcomer.setFontRenderer(fontRenderer);
      frames.add(frame);
      frame = new Frame(this.getTheme(), new Stretcherlayout(1), "Info");
      frame.setCloseable(false);
      frame.setPinneable(true);
      Label information = new Label("");
      information.setShadow(true);
      information.addTickListener(() -> {
         information.setText("");
         information.addLine("§6§l Bruce Client");
         information.addLine("§r§3" + Math.round(LagCompensator.INSTANCE.getTickRate()) + Command.SECTIONSIGN() + "3 tps");
         StringBuilder var10001 = (new StringBuilder()).append("§r§3");
         Wrapper.getMinecraft();
         information.addLine(var10001.append(Minecraft.field_71470_ab).append(Command.SECTIONSIGN()).append("3 fps").toString());
      });
      frame.addChild(new Component[]{information});
      information.setFontRenderer(fontRenderer);
      frames.add(frame);
      frame = new Frame(this.getTheme(), new Stretcherlayout(1), "ching client");
      frame.setCloseable(true);
      frame.setPinneable(true);
      Label ching = new Label("");
      information.setShadow(true);
      information.addTickListener(() -> {
         ching.setText("");
         ching.addLine("§8§l ching client b8.2020");
         ching.addLine("§f modules lingwenged");
         ching.addLine(" ");
         ching.addLine("§4 aura - 1000 cps");
         ching.addLine("§7 reach - 20");
         ching.addLine("§b highjump - 30");
         ching.addLine("§5 speed - 50");
         ching.addLine("§d timer - 10");
         ching.addLine("§2 packet fly - speed 100");
         ching.addLine("§1 ching client - suffix");
         ching.addLine("§3 totemcounter - 36");
         ching.addLine("§c auto32k - yakgod");
         ching.addLine("§2 autolog - 19 hp");
      });
      frame.addChild(new Component[]{ching});
      welcomer.setFontRenderer(fontRenderer);
      frames.add(frame);
      frame = new Frame(this.getTheme(), new Stretcherlayout(1), "Stats");
      frame.setCloseable(false);
      frame.setPinneable(true);
      Label goodsLabel = new Label("");
      goodsLabel.setShadow(true);
      goodsLabel.addTickListener(() -> {
         goodsLabel.setText("");
         goodsLabel.addLine("§6 Totems:" + this.manager.getTotems());
         goodsLabel.addLine("§6 Hole:" + this.manager.getHoleType());
      });
      frame.addChild(new Component[]{goodsLabel});
      goodsLabel.setFontRenderer(fontRenderer);
      frames.add(frame);
      frame = new Frame(this.getTheme(), new Stretcherlayout(1), "Friends");
      frame.setCloseable(false);
      frame.setPinneable(true);
      Label friendLabel = new Label("");
      friendLabel.setShadow(true);
      friendLabel.addTickListener(() -> {
         friendLabel.setText("");
         if (OnlineFriends.getFriends().isEmpty()) {
            friendLabel.addLine("");
         } else {
            friendLabel.addLine("§3§l The Boys");
            Iterator var1 = OnlineFriends.getFriends().iterator();

            while(var1.hasNext()) {
               Entity e = (Entity)var1.next();
               friendLabel.addLine("§6 " + e.func_70005_c_());
            }
         }

      });
      frame.addChild(new Component[]{friendLabel});
      friendLabel.setFontRenderer(fontRenderer);
      frames.add(frame);
      frame = new Frame(this.getTheme(), new Stretcherlayout(1), "Text Radar");
      Label list = new Label("");
      DecimalFormat dfHealth = new DecimalFormat("#.#");
      dfHealth.setRoundingMode(RoundingMode.HALF_UP);
      StringBuilder healthSB = new StringBuilder();
      list.addTickListener(() -> {
         if (list.isVisible()) {
            list.setText("");
            Minecraft mc = Wrapper.getMinecraft();
            if (mc.field_71439_g != null) {
               List entityList = mc.field_71441_e.field_73010_i;
               Map playersx = new HashMap();
               Iterator var6 = entityList.iterator();

               while(var6.hasNext()) {
                  Entity e = (Entity)var6.next();
                  if (!e.func_70005_c_().equals(mc.field_71439_g.func_70005_c_())) {
                     String posString = e.field_70163_u > mc.field_71439_g.field_70163_u ? ChatFormatting.DARK_GREEN + "+" : (e.field_70163_u == mc.field_71439_g.field_70163_u ? " " : ChatFormatting.DARK_RED + "-");
                     float hpRaw = ((EntityLivingBase)e).func_110143_aJ() + ((EntityLivingBase)e).func_110139_bj();
                     String hp = dfHealth.format((double)hpRaw);
                     healthSB.append(Command.SECTIONSIGN());
                     if (hpRaw >= 20.0F) {
                        healthSB.append("a");
                     } else if (hpRaw >= 10.0F) {
                        healthSB.append("e");
                     } else if (hpRaw >= 5.0F) {
                        healthSB.append("6");
                     } else {
                        healthSB.append("c");
                     }

                     healthSB.append(hp);
                     playersx.put(ChatFormatting.GRAY + posString + " " + healthSB.toString() + " " + ChatFormatting.GRAY + e.func_70005_c_(), (int)mc.field_71439_g.func_70032_d(e));
                     healthSB.setLength(0);
                  }
               }

               if (playersx.isEmpty()) {
                  list.setText("");
               } else {
                  Map players = sortByValue(playersx);
                  var6 = players.entrySet().iterator();

                  while(var6.hasNext()) {
                     Entry player = (Entry)var6.next();
                     list.addLine(Command.SECTIONSIGN() + "7" + (String)player.getKey() + " " + Command.SECTIONSIGN() + "8" + player.getValue());
                  }

               }
            }
         }
      });
      frame.setCloseable(false);
      frame.setPinneable(true);
      frame.setMinimumWidth(75);
      list.setShadow(true);
      frame.addChild(new Component[]{list});
      list.setFontRenderer(fontRenderer);
      frames.add(frame);
      frame = new Frame(this.getTheme(), new Stretcherlayout(1), "Entities");
      final Label entityLabel = new Label("");
      frame.setCloseable(false);
      entityLabel.addTickListener(new TickListener() {
         Minecraft mc = Wrapper.getMinecraft();

         public void onTick() {
            if (this.mc.field_71439_g != null && entityLabel.isVisible()) {
               List entityList = new ArrayList(this.mc.field_71441_e.field_72996_f);
               if (entityList.size() <= 1) {
                  entityLabel.setText("");
               } else {
                  Map entityCounts = (Map)entityList.stream().filter(Objects::nonNull).filter((e) -> {
                     return !(e instanceof EntityPlayer);
                  }).collect(Collectors.groupingBy((x$0) -> {
                     return wurstplusGUI.getEntityName(x$0);
                  }, Collectors.reducing(0, (ent) -> {
                     return ent instanceof EntityItem ? ((EntityItem)ent).func_92059_d().func_190916_E() : 1;
                  }, Integer::sum)));
                  entityLabel.setText("");
                  Stream var10000 = entityCounts.entrySet().stream().sorted(Entry.comparingByValue()).map((entry) -> {
                     return TextFormatting.GRAY + (String)entry.getKey() + " " + TextFormatting.DARK_GRAY + "x" + entry.getValue();
                  });
                  Label var10001 = entityLabel;
                  var10000.forEach(var10001::addLine);
               }
            }
         }
      });
      frame.addChild(new Component[]{entityLabel});
      frame.setPinneable(true);
      entityLabel.setShadow(true);
      entityLabel.setFontRenderer(fontRenderer);
      frame = new Frame(this.getTheme(), new Stretcherlayout(1), "Coordinates");
      frame.setCloseable(false);
      frame.setPinneable(true);
      final Label coordsLabel = new Label("");
      coordsLabel.addTickListener(new TickListener() {
         Minecraft mc = Minecraft.func_71410_x();

         public void onTick() {
            boolean inHell = this.mc.field_71441_e.func_180494_b(this.mc.field_71439_g.func_180425_c()).func_185359_l().equals("Hell");
            int posX = (int)this.mc.field_71439_g.field_70165_t;
            int posY = (int)this.mc.field_71439_g.field_70163_u;
            int posZ = (int)this.mc.field_71439_g.field_70161_v;
            float f = !inHell ? 0.125F : 8.0F;
            int hposX = (int)(this.mc.field_71439_g.field_70165_t * (double)f);
            int hposZ = (int)(this.mc.field_71439_g.field_70161_v * (double)f);
            coordsLabel.setText(String.format(" %sf%,d%s7, %sf%,d%s7, %sf%,d %s7(%sf%,d%s7, %sf%,d%s7, %sf%,d%s7)", Command.SECTIONSIGN(), posX, Command.SECTIONSIGN(), Command.SECTIONSIGN(), posY, Command.SECTIONSIGN(), Command.SECTIONSIGN(), posZ, Command.SECTIONSIGN(), Command.SECTIONSIGN(), hposX, Command.SECTIONSIGN(), Command.SECTIONSIGN(), posY, Command.SECTIONSIGN(), Command.SECTIONSIGN(), hposZ, Command.SECTIONSIGN()));
         }
      });
      frame.addChild(new Component[]{coordsLabel});
      coordsLabel.setFontRenderer(fontRenderer);
      coordsLabel.setShadow(true);
      frame.setHeight(20);
      frame = new Frame(this.getTheme(), new Stretcherlayout(1), "Radar");
      frame.setCloseable(false);
      frame.setMinimizeable(true);
      frame.setPinneable(true);
      frame.addChild(new Component[]{new Radar()});
      frame.setWidth(100);
      frame.setHeight(100);

      Frame frame1;
      for(Iterator var17 = frames.iterator(); var17.hasNext(); this.addChild(new Component[]{frame1})) {
         frame1 = (Frame)var17.next();
         frame1.setX(x);
         frame1.setY(y);
         nexty = Math.max(y + frame1.getHeight() + 10, nexty);
         x += frame1.getWidth() + 10;
         if ((float)(x * DisplayGuiScreen.getScale()) > (float)Wrapper.getMinecraft().field_71443_c / 1.2F) {
            y = nexty;
            nexty = nexty;
            x = 10;
         }
      }

   }

   private static String getEntityName(@Nonnull Entity entity) {
      if (entity instanceof EntityItem) {
         return TextFormatting.DARK_AQUA + ((EntityItem)entity).func_92059_d().func_77973_b().func_77653_i(((EntityItem)entity).func_92059_d());
      } else if (entity instanceof EntityWitherSkull) {
         return TextFormatting.DARK_GRAY + "Wither skull";
      } else if (entity instanceof EntityEnderCrystal) {
         return TextFormatting.LIGHT_PURPLE + "End crystal";
      } else if (entity instanceof EntityEnderPearl) {
         return "Thrown ender pearl";
      } else if (entity instanceof EntityMinecart) {
         return "Minecart";
      } else if (entity instanceof EntityItemFrame) {
         return "Item frame";
      } else if (entity instanceof EntityEgg) {
         return "Thrown egg";
      } else {
         return entity instanceof EntitySnowball ? "Thrown snowball" : entity.func_70005_c_();
      }
   }

   public static Map sortByValue(Map map) {
      List list = new LinkedList(map.entrySet());
      Collections.sort(list, Comparator.comparing((o) -> {
         return (Comparable)o.getValue();
      }));
      Map result = new LinkedHashMap();
      Iterator var3 = list.iterator();

      while(var3.hasNext()) {
         Entry entry = (Entry)var3.next();
         result.put(entry.getKey(), entry.getValue());
      }

      return result;
   }

   public void destroyGUI() {
      this.kill();
   }

   public static void dock(Frame component) {
      Docking docking = component.getDocking();
      if (docking.isTop()) {
         component.setY(0);
      }

      if (docking.isBottom()) {
         component.setY(Wrapper.getMinecraft().field_71440_d / DisplayGuiScreen.getScale() - component.getHeight() - 0);
      }

      if (docking.isLeft()) {
         component.setX(0);
      }

      if (docking.isRight()) {
         component.setX(Wrapper.getMinecraft().field_71443_c / DisplayGuiScreen.getScale() - component.getWidth() - 0);
      }

      if (docking.isCenterHorizontal()) {
         component.setX(Wrapper.getMinecraft().field_71443_c / (DisplayGuiScreen.getScale() * 2) - component.getWidth() / 2);
      }

      if (docking.isCenterVertical()) {
         component.setY(Wrapper.getMinecraft().field_71440_d / (DisplayGuiScreen.getScale() * 2) - component.getHeight() / 2);
      }

   }
}
