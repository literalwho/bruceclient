package me.travis.wurstplus.gui.wurstplus.component;

import me.travis.wurstplus.gui.rgui.component.AbstractComponent;

public class Radar extends AbstractComponent {
}
