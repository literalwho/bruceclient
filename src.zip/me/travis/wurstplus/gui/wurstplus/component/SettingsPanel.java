package me.travis.wurstplus.gui.wurstplus.component;

import java.util.Arrays;
import java.util.Iterator;
import me.travis.wurstplus.gui.rgui.component.Component;
import me.travis.wurstplus.gui.rgui.component.container.OrganisedContainer;
import me.travis.wurstplus.gui.rgui.component.use.CheckButton;
import me.travis.wurstplus.gui.rgui.component.use.Slider;
import me.travis.wurstplus.gui.rgui.render.theme.Theme;
import me.travis.wurstplus.gui.wurstplus.Stretcherlayout;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.impl.BooleanSetting;
import me.travis.wurstplus.setting.impl.EnumSetting;
import me.travis.wurstplus.setting.impl.numerical.DoubleSetting;
import me.travis.wurstplus.setting.impl.numerical.FloatSetting;
import me.travis.wurstplus.setting.impl.numerical.IntegerSetting;
import me.travis.wurstplus.setting.impl.numerical.NumberSetting;
import me.travis.wurstplus.util.Bind;

public class SettingsPanel extends OrganisedContainer {
   Module module;

   public SettingsPanel(Theme theme, Module module) {
      super(theme, new Stretcherlayout(1));
      this.setAffectLayout(false);
      this.module = module;
      this.prepare();
   }

   public void renderChildren() {
      super.renderChildren();
   }

   public Module getModule() {
      return this.module;
   }

   private void prepare() {
      this.getChildren().clear();
      if (this.module == null) {
         this.setVisible(false);
      } else {
         if (!this.module.settingList.isEmpty()) {
            Iterator var1 = this.module.settingList.iterator();

            while(var1.hasNext()) {
               final Setting setting = (Setting)var1.next();
               if (setting.isVisible()) {
                  String name = setting.getName();
                  boolean isNumber = setting instanceof NumberSetting;
                  boolean isBoolean = setting instanceof BooleanSetting;
                  boolean isEnum = setting instanceof EnumSetting;
                  if (setting.getValue() instanceof Bind) {
                     this.addChild(new Component[]{new BindButton("Bind", this.module)});
                  }

                  if (isNumber) {
                     NumberSetting numberSetting = (NumberSetting)setting;
                     boolean isBound = numberSetting.isBound();
                     if (!isBound) {
                        UnboundSlider slider = new UnboundSlider(numberSetting.getValue().doubleValue(), name, setting instanceof IntegerSetting);
                        slider.addPoof(new Slider.SliderPoof() {
                           public void execute(UnboundSlider component, Slider.SliderPoof.SliderPoofInfo info) {
                              if (setting instanceof IntegerSetting) {
                                 setting.setValue(new Integer((int)info.getNewValue()));
                              } else if (setting instanceof FloatSetting) {
                                 setting.setValue(new Float(info.getNewValue()));
                              } else if (setting instanceof DoubleSetting) {
                                 setting.setValue(info.getNewValue());
                              }

                              SettingsPanel.this.setModule(SettingsPanel.this.module);
                           }
                        });
                        if (numberSetting.getMax() != null) {
                           slider.setMax(numberSetting.getMax().doubleValue());
                        }

                        if (numberSetting.getMin() != null) {
                           slider.setMin(numberSetting.getMin().doubleValue());
                        }

                        this.addChild(new Component[]{slider});
                     } else {
                        Slider slider = new Slider(numberSetting.getValue().doubleValue(), numberSetting.getMin().doubleValue(), numberSetting.getMax().doubleValue(), Slider.getDefaultStep(numberSetting.getMin().doubleValue(), numberSetting.getMax().doubleValue()), name, setting instanceof IntegerSetting);
                        slider.addPoof(new Slider.SliderPoof() {
                           public void execute(Slider component, Slider.SliderPoof.SliderPoofInfo info) {
                              if (setting instanceof IntegerSetting) {
                                 setting.setValue(new Integer((int)info.getNewValue()));
                              } else if (setting instanceof FloatSetting) {
                                 setting.setValue(new Float(info.getNewValue()));
                              } else if (setting instanceof DoubleSetting) {
                                 setting.setValue(info.getNewValue());
                              }

                              SettingsPanel.this.setModule(SettingsPanel.this.module);
                           }
                        });
                        this.addChild(new Component[]{slider});
                     }
                  } else if (isBoolean) {
                     final CheckButton checkButton = new CheckButton(name);
                     checkButton.setToggled((Boolean)((BooleanSetting)setting).getValue());
                     checkButton.addPoof(new CheckButton.CheckButtonPoof() {
                        public void execute(CheckButton checkButton1, CheckButton.CheckButtonPoof.CheckButtonPoofInfo info) {
                           if (info.getAction() == CheckButton.CheckButtonPoof.CheckButtonPoofInfo.CheckButtonPoofInfoAction.TOGGLE) {
                              setting.setValue(checkButton.isToggled());
                              SettingsPanel.this.setModule(SettingsPanel.this.module);
                           }

                        }
                     });
                     this.addChild(new Component[]{checkButton});
                  } else if (isEnum) {
                     Class type = ((EnumSetting)setting).clazz;
                     final Object[] con = type.getEnumConstants();
                     String[] modes = (String[])Arrays.stream(con).map((o) -> {
                        return o.toString().toUpperCase();
                     }).toArray((x$0) -> {
                        return new String[x$0];
                     });
                     EnumButton enumbutton = new EnumButton(name, modes);
                     enumbutton.addPoof(new EnumButton.EnumbuttonIndexPoof() {
                        public void execute(EnumButton component, EnumButton.EnumbuttonIndexPoof.EnumbuttonInfo info) {
                           setting.setValue(con[info.getNewIndex()]);
                           SettingsPanel.this.setModule(SettingsPanel.this.module);
                        }
                     });
                     enumbutton.setIndex(Arrays.asList(con).indexOf(setting.getValue()));
                     this.addChild(new Component[]{enumbutton});
                  }
               }
            }
         }

         if (this.children.isEmpty()) {
            this.setVisible(false);
         } else {
            this.setVisible(true);
         }
      }
   }

   public void setModule(Module module) {
      this.module = module;
      this.setMinimumWidth((int)((float)this.getParent().getWidth() * 0.9F));
      this.prepare();
      this.setAffectLayout(false);
      Iterator var2 = this.children.iterator();

      while(var2.hasNext()) {
         Component component = (Component)var2.next();
         component.setWidth(this.getWidth() - 10);
         component.setX(5);
      }

   }
}
