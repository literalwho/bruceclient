package me.travis.wurstplus.gui.mc;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeMap;
import me.travis.wurstplus.wurstplusMod;
import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.command.syntax.SyntaxChunk;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.util.text.ITextComponent;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class wurstplusGuiChat extends GuiChat {
   private String startString;
   private String currentFillinLine;
   private int cursor;

   public wurstplusGuiChat(String startString, String historybuffer, int sentHistoryCursor) {
      super(startString);
      this.startString = startString;
      if (!startString.equals(Command.getCommandPrefix())) {
         this.calculateCommand(startString.substring(Command.getCommandPrefix().length()));
      }

      this.field_146410_g = historybuffer;
      this.cursor = sentHistoryCursor;
   }

   protected void func_73869_a(char typedChar, int keyCode) throws IOException {
      this.field_146416_h = this.cursor;
      super.func_73869_a(typedChar, keyCode);
      this.cursor = this.field_146416_h;
      String chatLine = this.field_146415_a.func_146179_b();
      if (!chatLine.startsWith(Command.getCommandPrefix())) {
         GuiChat newGUI = new GuiChat(chatLine) {
            int cursor;

            {
               this.cursor = wurstplusGuiChat.this.cursor;
            }

            protected void func_73869_a(char typedChar, int keyCode) throws IOException {
               this.field_146416_h = this.cursor;
               super.func_73869_a(typedChar, keyCode);
               this.cursor = this.field_146416_h;
            }
         };
         newGUI.field_146410_g = this.field_146410_g;
         this.field_146297_k.func_147108_a(newGUI);
      } else if (chatLine.equals(Command.getCommandPrefix())) {
         this.currentFillinLine = "";
      } else {
         this.calculateCommand(chatLine.substring(Command.getCommandPrefix().length()));
      }
   }

   protected void calculateCommand(String line) {
      String[] args = line.split(" (?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
      HashMap options = new HashMap();
      if (args.length != 0) {
         Iterator var4 = wurstplusMod.getInstance().getCommandManager().getCommands().iterator();

         while(true) {
            Command alphaCommand;
            do {
               if (!var4.hasNext()) {
                  if (options.isEmpty()) {
                     this.currentFillinLine = "";
                     return;
                  }

                  TreeMap map = new TreeMap(options);
                  alphaCommand = (Command)map.firstEntry().getValue();
                  this.currentFillinLine = alphaCommand.getLabel().substring(args[0].length());
                  if (alphaCommand.getSyntaxChunks() != null && alphaCommand.getSyntaxChunks().length != 0) {
                     if (!line.endsWith(" ")) {
                        this.currentFillinLine = this.currentFillinLine + " ";
                     }

                     SyntaxChunk[] chunks = alphaCommand.getSyntaxChunks();
                     boolean cutSpace = false;

                     for(int i = 0; i < chunks.length; ++i) {
                        if (i + 1 >= args.length - 1) {
                           SyntaxChunk c = chunks[i];
                           String result = c.getChunk(chunks, c, args, i + 1 == args.length - 1 ? args[i + 1] : null);
                           if (result != "" && (!result.startsWith("<") || !result.endsWith(">")) && (!result.startsWith("[") || !result.endsWith("]"))) {
                              cutSpace = true;
                           }

                           this.currentFillinLine = this.currentFillinLine + result + (result == "" ? "" : " ") + "";
                        }
                     }

                     if (cutSpace) {
                        this.currentFillinLine = this.currentFillinLine.substring(1);
                     }

                     return;
                  }

                  return;
               }

               alphaCommand = (Command)var4.next();
            } while((!alphaCommand.getLabel().startsWith(args[0]) || line.endsWith(" ")) && !alphaCommand.getLabel().equals(args[0]));

            options.put(alphaCommand.getLabel(), alphaCommand);
         }
      }
   }

   public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
      func_73734_a(2, this.field_146295_m - 14, this.field_146294_l - 2, this.field_146295_m - 2, Integer.MIN_VALUE);
      int x = this.field_146415_a.field_146211_a.func_78256_a(this.field_146415_a.func_146179_b() + "") + 4;
      int y = this.field_146415_a.func_146181_i() ? this.field_146415_a.field_146210_g + (this.field_146415_a.field_146219_i - 8) / 2 : this.field_146415_a.field_146210_g;
      this.field_146415_a.field_146211_a.func_175063_a(this.currentFillinLine, (float)x, (float)y, 6710886);
      this.field_146415_a.func_146194_f();
      ITextComponent itextcomponent = this.field_146297_k.field_71456_v.func_146158_b().func_146236_a(Mouse.getX(), Mouse.getY());
      if (itextcomponent != null && itextcomponent.func_150256_b().func_150210_i() != null) {
         this.func_175272_a(itextcomponent, mouseX, mouseY);
      }

      boolean a = GL11.glIsEnabled(3042);
      boolean b = GL11.glIsEnabled(3553);
      GL11.glDisable(3042);
      GL11.glDisable(3553);
      GL11.glColor3f(0.66F, 0.33F, 0.0F);
      GL11.glBegin(1);
      GL11.glVertex2f((float)(this.field_146415_a.field_146209_f - 2), (float)(this.field_146415_a.field_146210_g - 2));
      GL11.glVertex2f((float)(this.field_146415_a.field_146209_f + this.field_146415_a.func_146200_o() - 2), (float)(this.field_146415_a.field_146210_g - 2));
      GL11.glVertex2f((float)(this.field_146415_a.field_146209_f + this.field_146415_a.func_146200_o() - 2), (float)(this.field_146415_a.field_146210_g - 2));
      GL11.glVertex2f((float)(this.field_146415_a.field_146209_f + this.field_146415_a.func_146200_o() - 2), (float)(this.field_146415_a.field_146210_g + this.field_146415_a.field_146219_i - 2));
      GL11.glVertex2f((float)(this.field_146415_a.field_146209_f + this.field_146415_a.func_146200_o() - 2), (float)(this.field_146415_a.field_146210_g + this.field_146415_a.field_146219_i - 2));
      GL11.glVertex2f((float)(this.field_146415_a.field_146209_f - 2), (float)(this.field_146415_a.field_146210_g + this.field_146415_a.field_146219_i - 2));
      GL11.glVertex2f((float)(this.field_146415_a.field_146209_f - 2), (float)(this.field_146415_a.field_146210_g + this.field_146415_a.field_146219_i - 2));
      GL11.glVertex2f((float)(this.field_146415_a.field_146209_f - 2), (float)(this.field_146415_a.field_146210_g - 2));
      GL11.glEnd();
      if (a) {
         GL11.glEnable(3042);
      }

      if (b) {
         GL11.glEnable(3553);
      }

   }
}
