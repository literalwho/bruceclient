package me.travis.wurstplus.gui.rgui.poof;

import me.travis.wurstplus.gui.rgui.component.Component;

public interface IPoof {
   void execute(Component var1, PoofInfo var2);

   Class getComponentClass();

   Class getInfoClass();
}
