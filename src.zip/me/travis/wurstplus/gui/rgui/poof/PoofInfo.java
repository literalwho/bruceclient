package me.travis.wurstplus.gui.rgui.poof;

public class PoofInfo {
}
