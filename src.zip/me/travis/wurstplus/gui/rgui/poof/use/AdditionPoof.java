package me.travis.wurstplus.gui.rgui.poof.use;

public abstract class AdditionPoof extends Poof {
}
