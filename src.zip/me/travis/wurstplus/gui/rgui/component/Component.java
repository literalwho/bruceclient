package me.travis.wurstplus.gui.rgui.component;

import java.util.ArrayList;
import me.travis.wurstplus.gui.rgui.component.container.Container;
import me.travis.wurstplus.gui.rgui.component.listen.KeyListener;
import me.travis.wurstplus.gui.rgui.component.listen.MouseListener;
import me.travis.wurstplus.gui.rgui.component.listen.RenderListener;
import me.travis.wurstplus.gui.rgui.component.listen.TickListener;
import me.travis.wurstplus.gui.rgui.component.listen.UpdateListener;
import me.travis.wurstplus.gui.rgui.poof.IPoof;
import me.travis.wurstplus.gui.rgui.poof.PoofInfo;
import me.travis.wurstplus.gui.rgui.render.ComponentUI;
import me.travis.wurstplus.gui.rgui.render.theme.Theme;

public interface Component {
   int getX();

   int getY();

   int getWidth();

   int getHeight();

   void setX(int var1);

   void setY(int var1);

   void setWidth(int var1);

   void setHeight(int var1);

   Component setMinimumWidth(int var1);

   Component setMaximumWidth(int var1);

   Component setMinimumHeight(int var1);

   Component setMaximumHeight(int var1);

   int getMinimumWidth();

   int getMaximumWidth();

   int getMinimumHeight();

   int getMaximumHeight();

   float getOpacity();

   void setOpacity(float var1);

   boolean doAffectLayout();

   void setAffectLayout(boolean var1);

   Container getParent();

   void setParent(Container var1);

   boolean liesIn(Component var1);

   boolean isVisible();

   void setVisible(boolean var1);

   void setFocussed(boolean var1);

   boolean isFocussed();

   ComponentUI getUI();

   Theme getTheme();

   void setTheme(Theme var1);

   boolean isHovered();

   boolean isPressed();

   ArrayList getMouseListeners();

   void addMouseListener(MouseListener var1);

   ArrayList getRenderListeners();

   void addRenderListener(RenderListener var1);

   ArrayList getKeyListeners();

   void addKeyListener(KeyListener var1);

   ArrayList getUpdateListeners();

   void addUpdateListener(UpdateListener var1);

   ArrayList getTickListeners();

   void addTickListener(TickListener var1);

   void addPoof(IPoof var1);

   void callPoof(Class var1, PoofInfo var2);

   int getPriority();

   void kill();
}
