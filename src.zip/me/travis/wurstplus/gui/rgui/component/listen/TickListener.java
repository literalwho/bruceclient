package me.travis.wurstplus.gui.rgui.component.listen;

public interface TickListener {
   void onTick();
}
