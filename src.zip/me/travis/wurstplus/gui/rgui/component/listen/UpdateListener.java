package me.travis.wurstplus.gui.rgui.component.listen;

import me.travis.wurstplus.gui.rgui.component.Component;

public interface UpdateListener {
   void updateSize(Component var1, int var2, int var3);

   void updateLocation(Component var1, int var2, int var3);
}
