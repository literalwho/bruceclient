package me.travis.wurstplus.gui.rgui.component.listen;

public interface RenderListener {
   void onPreRender();

   void onPostRender();
}
