package me.travis.wurstplus.gui.rgui.component.container;

import java.util.ArrayList;
import me.travis.wurstplus.gui.rgui.component.Component;

public interface Container extends Component {
   ArrayList getChildren();

   Component getComponentAt(int var1, int var2);

   Container addChild(Component... var1);

   Container removeChild(Component var1);

   boolean hasChild(Component var1);

   void renderChildren();

   int getOriginOffsetX();

   int getOriginOffsetY();

   boolean penetrateTest(int var1, int var2);
}
