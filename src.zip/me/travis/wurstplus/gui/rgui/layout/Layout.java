package me.travis.wurstplus.gui.rgui.layout;

import me.travis.wurstplus.gui.rgui.component.container.Container;

public interface Layout {
   void organiseContainer(Container var1);
}
