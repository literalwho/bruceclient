package me.travis.wurstplus.gui.rgui.layout;

import me.travis.wurstplus.gui.rgui.component.container.Container;

public class UselessLayout implements Layout {
   public void organiseContainer(Container container) {
   }
}
