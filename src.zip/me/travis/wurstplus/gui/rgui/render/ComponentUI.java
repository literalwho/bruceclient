package me.travis.wurstplus.gui.rgui.render;

import me.travis.wurstplus.gui.rgui.component.Component;
import me.travis.wurstplus.gui.rgui.component.container.Container;
import me.travis.wurstplus.gui.rgui.render.font.FontRenderer;

public interface ComponentUI {
   void renderComponent(Component var1, FontRenderer var2);

   void handleMouseDown(Component var1, int var2, int var3, int var4);

   void handleMouseRelease(Component var1, int var2, int var3, int var4);

   void handleMouseDrag(Component var1, int var2, int var3, int var4);

   void handleScroll(Component var1, int var2, int var3, int var4, boolean var5);

   void handleKeyDown(Component var1, int var2);

   void handleKeyUp(Component var1, int var2);

   void handleAddComponent(Component var1, Container var2);

   void handleSizeComponent(Component var1);

   Class getHandledClass();
}
