package me.travis.wurstplus.gui.rgui.render.theme;

import me.travis.wurstplus.gui.rgui.component.Component;
import me.travis.wurstplus.gui.rgui.render.ComponentUI;
import me.travis.wurstplus.gui.rgui.render.font.FontRenderer;

public interface Theme {
   ComponentUI getUIForComponent(Component var1);

   FontRenderer getFontRenderer();
}
