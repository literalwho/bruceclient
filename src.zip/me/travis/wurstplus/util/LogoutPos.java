package me.travis.wurstplus.util;

import java.util.UUID;
import net.minecraft.util.math.Vec3d;

public class LogoutPos {
   final UUID id;
   final String name;
   final Vec3d maxs;
   final Vec3d mins;

   public LogoutPos(UUID uuid, String name, Vec3d maxs, Vec3d mins) {
      this.id = uuid;
      this.name = name;
      this.maxs = maxs;
      this.mins = mins;
   }

   public UUID getId() {
      return this.id;
   }

   public String getName() {
      return this.name;
   }

   public Vec3d getMaxs() {
      return this.maxs;
   }

   public Vec3d getMins() {
      return this.mins;
   }

   public Vec3d getTopVec() {
      return new Vec3d((this.getMins().field_72450_a + this.getMaxs().field_72450_a) / 2.0D, this.getMaxs().field_72448_b, (this.getMins().field_72449_c + this.getMaxs().field_72449_c) / 2.0D);
   }

   public boolean equals(Object other) {
      return this == other || other instanceof LogoutPos && this.getId().equals(((LogoutPos)other).getId());
   }

   public int hashCode() {
      return this.getId().hashCode();
   }
}
