package me.travis.wurstplus.util;

public class Tuple {
   public final Object x;
   public final Object y;

   public Tuple(Object x, Object y) {
      this.x = x;
      this.y = y;
   }
}
