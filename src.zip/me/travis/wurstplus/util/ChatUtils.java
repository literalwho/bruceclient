package me.travis.wurstplus.util;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ChatUtils {
   public static String getChatTimestamp() {
      String timestamp = ChatFormatting.GRAY + "§6<" + (new SimpleDateFormat("k:mm a")).format(new Date()) + ">" + ChatFormatting.RESET + " ";
      return timestamp;
   }
}
