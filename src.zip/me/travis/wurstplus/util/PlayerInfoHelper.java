package me.travis.wurstplus.util;

import com.google.common.collect.Maps;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.ListeningExecutorService;
import com.google.common.util.concurrent.MoreExecutors;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import joptsimple.internal.Strings;
import net.minecraft.client.Minecraft;

public class PlayerInfoHelper {
   private static final int THREAD_COUNT = 1;
   public static final int MAX_NAME_LENGTH = 16;
   private static final ListeningExecutorService EXECUTOR_SERVICE = MoreExecutors.listeningDecorator(Executors.newFixedThreadPool(Math.max(1, 1)));
   private static final Map NAME_TO_INFO = Maps.newConcurrentMap();
   private static final Map UUID_TO_INFO = Maps.newConcurrentMap();

   private static PlayerInfo register(String name) throws IOException {
      if (!Strings.isNullOrEmpty(name) && name.length() <= 16) {
         PlayerInfo info = new PlayerInfo(name);
         NAME_TO_INFO.put(info.getName().toLowerCase(), info);
         UUID_TO_INFO.put(info.getId(), info);
         return info;
      } else {
         return null;
      }
   }

   private static PlayerInfo register(UUID uuid) throws IOException {
      PlayerInfo info = new PlayerInfo(uuid);
      NAME_TO_INFO.put(info.getName().toLowerCase(), info);
      UUID_TO_INFO.put(info.getId(), info);
      return info;
   }

   private static PlayerInfo offlineUser(String name) {
      return name.length() > 16 ? null : new PlayerInfo(name, true);
   }

   public static PlayerInfo get(String name) {
      return Strings.isNullOrEmpty(name) ? null : (PlayerInfo)NAME_TO_INFO.get(name.toLowerCase());
   }

   public static PlayerInfo get(UUID uuid) {
      return uuid == null ? null : (PlayerInfo)UUID_TO_INFO.get(uuid);
   }

   public static List getPlayers() {
      return Immutables.copyToList(UUID_TO_INFO.values());
   }

   public static List getOnlinePlayers() {
      return Minecraft.func_71410_x().func_147114_u() == null ? Collections.emptyList() : (List)Minecraft.func_71410_x().func_147114_u().func_175106_d().stream().map((info) -> {
         PlayerInfo pl = get(info.func_178845_a().getName());
         return pl == null ? offlineUser(info.func_178845_a().getName()) : pl;
      }).collect(Collectors.toList());
   }

   public static PlayerInfo lookup(String name) throws IOException {
      PlayerInfo info = get(name);
      return info == null ? register(name) : info;
   }

   public static PlayerInfo lookup(UUID uuid) throws IOException {
      PlayerInfo info = get(uuid);
      return info == null ? register(uuid) : info;
   }

   public static boolean registerWithCallback(String name, FutureCallback callback) {
      PlayerInfo info = get(name);
      if (info == null) {
         Futures.addCallback(EXECUTOR_SERVICE.submit(() -> {
            return register(name);
         }), callback);
         return true;
      } else {
         Futures.addCallback(Futures.immediateFuture(info), callback);
         return false;
      }
   }

   public static boolean registerWithCallback(UUID uuid, FutureCallback callback) {
      PlayerInfo info = get(uuid);
      if (info == null) {
         Futures.addCallback(EXECUTOR_SERVICE.submit(() -> {
            return register(uuid);
         }), callback);
         return true;
      } else {
         Futures.addCallback(Futures.immediateFuture(info), callback);
         return false;
      }
   }

   public static boolean registerWithCallback(UUID uuid, final String name, final FutureCallback callback) {
      return registerWithCallback(uuid, new FutureCallback() {
         public void onSuccess(@Nullable PlayerInfo result) {
            callback.onSuccess(result);
         }

         public void onFailure(Throwable t) {
            PlayerInfoHelper.registerWithCallback(name, callback);
         }
      });
   }

   public static boolean generateOfflineWithCallback(String name, FutureCallback callback) {
      ListenableFuture future = Futures.immediateFuture(offlineUser(name));
      Futures.addCallback(future, callback);
      return false;
   }

   public static UUID getIdFromString(String uuid) {
      return uuid.contains("-") ? UUID.fromString(uuid) : UUID.fromString(uuid.replaceFirst("(\\p{XDigit}{8})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}+)", "$1-$2-$3-$4-$5"));
   }

   public static String getIdNoHyphens(UUID uuid) {
      return uuid.toString().replaceAll("-", "");
   }

   static {
      Runtime.getRuntime().addShutdownHook(new Thread(() -> {
         EXECUTOR_SERVICE.shutdown();

         while(!EXECUTOR_SERVICE.isShutdown()) {
            try {
               EXECUTOR_SERVICE.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
            } catch (InterruptedException var1) {
            }
         }

      }));
   }
}
