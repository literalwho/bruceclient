package me.travis.wurstplus.util;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.ImmutableList.Builder;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collector;
import java.util.stream.Collector.Characteristics;
import javax.annotation.Nullable;

public class Immutables {
   public static Collection copy(@Nullable Collection collection) {
      return copyToList(collection);
   }

   public static List copyToList(@Nullable Collection collection) {
      if (collection != null && !collection.isEmpty()) {
         if (collection instanceof ImmutableList) {
            return (List)collection;
         } else {
            return (List)(collection.size() == 1 ? Collections.singletonList(collection.iterator().next()) : ImmutableList.copyOf(collection));
         }
      } else {
         return Collections.emptyList();
      }
   }

   public static Set copyToSet(@Nullable Collection collection) {
      if (collection != null && !collection.isEmpty()) {
         return (Set)(collection.size() == 1 ? Collections.singleton(collection.iterator().next()) : ImmutableSet.copyOf(collection));
      } else {
         return Collections.emptySet();
      }
   }

   public static Collector toImmutableSet() {
      return new Immutables.ImmutableSetCollector();
   }

   public static Collector toImmutableList() {
      return new Immutables.ImmutableListCollector();
   }

   private static class ImmutableListCollector implements Collector {
      private ImmutableListCollector() {
      }

      public Supplier supplier() {
         return ImmutableList::builder;
      }

      public BiConsumer accumulator() {
         return Builder::add;
      }

      public BinaryOperator combiner() {
         return (l, r) -> {
            l.addAll(r.build());
            return l;
         };
      }

      public Function finisher() {
         return Builder::build;
      }

      public Set characteristics() {
         return Collections.emptySet();
      }

      // $FF: synthetic method
      ImmutableListCollector(Object x0) {
         this();
      }
   }

   private static class ImmutableSetCollector implements Collector {
      private ImmutableSetCollector() {
      }

      public Supplier supplier() {
         return ImmutableSet::builder;
      }

      public BiConsumer accumulator() {
         return com.google.common.collect.ImmutableSet.Builder::add;
      }

      public BinaryOperator combiner() {
         return (l, r) -> {
            l.addAll(r.build());
            return l;
         };
      }

      public Function finisher() {
         return com.google.common.collect.ImmutableSet.Builder::build;
      }

      public Set characteristics() {
         return EnumSet.of(Characteristics.UNORDERED);
      }

      // $FF: synthetic method
      ImmutableSetCollector(Object x0) {
         this();
      }
   }
}
