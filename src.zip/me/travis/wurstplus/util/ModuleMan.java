package me.travis.wurstplus.util;

import me.travis.wurstplus.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;

public class ModuleMan {
   public Integer totems;
   private String holeType = "§4 0";
   private BlockPos pos;

   public ModuleMan() {
      this.getPlayerPos();
   }

   public Boolean getPlayerPos() {
      try {
         this.pos = new BlockPos(Math.floor(Minecraft.func_71410_x().field_71439_g.field_70165_t), Math.floor(Minecraft.func_71410_x().field_71439_g.field_70163_u), Math.floor(Minecraft.func_71410_x().field_71439_g.field_70161_v));
         return false;
      } catch (Exception var2) {
         return true;
      }
   }

   public String getHoleType() {
      if (this.getPlayerPos()) {
         return "§4 0";
      } else {
         this.getPlayerPos();
         if (Minecraft.func_71410_x().field_71441_e.func_180495_p(this.pos.func_177982_a(0, -1, 0)).func_177230_c() == Blocks.field_150357_h && Minecraft.func_71410_x().field_71441_e.func_180495_p(this.pos.func_177982_a(1, 0, 0)).func_177230_c() == Blocks.field_150357_h && Minecraft.func_71410_x().field_71441_e.func_180495_p(this.pos.func_177982_a(0, 0, 1)).func_177230_c() == Blocks.field_150357_h && Minecraft.func_71410_x().field_71441_e.func_180495_p(this.pos.func_177982_a(-1, 0, 0)).func_177230_c() == Blocks.field_150357_h && Minecraft.func_71410_x().field_71441_e.func_180495_p(this.pos.func_177982_a(0, 0, -1)).func_177230_c() == Blocks.field_150357_h) {
            this.holeType = "§a Safe";
            return this.holeType;
         } else if (Minecraft.func_71410_x().field_71441_e.func_180495_p(this.pos.func_177982_a(0, -1, 0)).func_177230_c() == Blocks.field_150357_h | Minecraft.func_71410_x().field_71441_e.func_180495_p(this.pos.func_177982_a(0, -1, 0)).func_177230_c() == Blocks.field_150343_Z && Minecraft.func_71410_x().field_71441_e.func_180495_p(this.pos.func_177982_a(1, 0, 0)).func_177230_c() == Blocks.field_150357_h | Minecraft.func_71410_x().field_71441_e.func_180495_p(this.pos.func_177982_a(1, 0, 0)).func_177230_c() == Blocks.field_150343_Z && Minecraft.func_71410_x().field_71441_e.func_180495_p(this.pos.func_177982_a(0, 0, 1)).func_177230_c() == Blocks.field_150357_h | Minecraft.func_71410_x().field_71441_e.func_180495_p(this.pos.func_177982_a(0, 0, 1)).func_177230_c() == Blocks.field_150343_Z && Minecraft.func_71410_x().field_71441_e.func_180495_p(this.pos.func_177982_a(-1, 0, 0)).func_177230_c() == Blocks.field_150357_h | Minecraft.func_71410_x().field_71441_e.func_180495_p(this.pos.func_177982_a(-1, 0, 0)).func_177230_c() == Blocks.field_150343_Z && Minecraft.func_71410_x().field_71441_e.func_180495_p(this.pos.func_177982_a(0, 0, -1)).func_177230_c() == Blocks.field_150357_h | Minecraft.func_71410_x().field_71441_e.func_180495_p(this.pos.func_177982_a(0, 0, -1)).func_177230_c() == Blocks.field_150343_Z) {
            this.holeType = "§3 Unsafe";
            return this.holeType;
         } else {
            this.holeType = "§4 None";
            return this.holeType;
         }
      }
   }

   public String isAura() {
      try {
         return ModuleManager.getModuleByName("Travis Aura").isEnabled() ? "§a 1" : "§4 0";
      } catch (Exception var2) {
         return "lack of games: " + var2;
      }
   }

   public String isTrap() {
      try {
         return ModuleManager.getModuleByName("AutoTrap").isEnabled() ? "§a 1" : "§4 0";
      } catch (Exception var2) {
         return "lack of games: " + var2;
      }
   }

   public String isSurround() {
      try {
         return ModuleManager.getModuleByName("Surround").isEnabled() ? "§a 1" : "§4 0";
      } catch (Exception var2) {
         return "lack of games: " + var2;
      }
   }

   public String isFill() {
      try {
         return ModuleManager.getModuleByName("HoleFill").isEnabled() ? "§a 1" : "§4 0";
      } catch (Exception var2) {
         return "lack of games: " + var2;
      }
   }

   public int getTotemsInt() {
      return this.offhand() + Minecraft.func_71410_x().field_71439_g.field_71071_by.field_70462_a.stream().filter((itemStack) -> {
         return itemStack.func_77973_b() == Items.field_190929_cY;
      }).mapToInt(ItemStack::func_190916_E).sum();
   }

   public String getTotems() {
      try {
         this.totems = this.offhand() + Minecraft.func_71410_x().field_71439_g.field_71071_by.field_70462_a.stream().filter((itemStack) -> {
            return itemStack.func_77973_b() == Items.field_190929_cY;
         }).mapToInt(ItemStack::func_190916_E).sum();
         return this.totems > 1 ? "§a " + this.totems : "§4 " + this.totems;
      } catch (Exception var2) {
         return "0";
      }
   }

   public Integer offhand() {
      return Minecraft.func_71410_x().field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY ? 1 : 0;
   }
}
