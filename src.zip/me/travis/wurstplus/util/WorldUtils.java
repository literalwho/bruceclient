package me.travis.wurstplus.util;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.network.play.client.CPacketPlayer.Rotation;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class WorldUtils {
   public static void placeBlockMainHand(BlockPos pos) {
      placeBlock(EnumHand.MAIN_HAND, pos);
   }

   public static void placeBlock(EnumHand hand, BlockPos pos) {
      Vec3d eyesPos = new Vec3d(Minecraft.func_71410_x().field_71439_g.field_70165_t, Minecraft.func_71410_x().field_71439_g.field_70163_u + (double)Minecraft.func_71410_x().field_71439_g.func_70047_e(), Minecraft.func_71410_x().field_71439_g.field_70161_v);
      EnumFacing[] var3 = EnumFacing.values();
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         EnumFacing side = var3[var5];
         BlockPos neighbor = pos.func_177972_a(side);
         EnumFacing side2 = side.func_176734_d();
         if (Minecraft.func_71410_x().field_71441_e.func_180495_p(neighbor).func_177230_c().func_176209_a(Minecraft.func_71410_x().field_71441_e.func_180495_p(neighbor), false)) {
            Vec3d hitVec = (new Vec3d(neighbor)).func_72441_c(0.5D, 0.5D, 0.5D).func_178787_e((new Vec3d(side2.func_176730_m())).func_186678_a(0.5D));
            if (eyesPos.func_72436_e(hitVec) <= 18.0625D) {
               double diffX = hitVec.field_72450_a - eyesPos.field_72450_a;
               double diffY = hitVec.field_72448_b - eyesPos.field_72448_b;
               double diffZ = hitVec.field_72449_c - eyesPos.field_72449_c;
               double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
               float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
               float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)));
               float[] rotations = new float[]{Minecraft.func_71410_x().field_71439_g.field_70177_z + MathHelper.func_76142_g(yaw - Minecraft.func_71410_x().field_71439_g.field_70177_z), Minecraft.func_71410_x().field_71439_g.field_70125_A + MathHelper.func_76142_g(pitch - Minecraft.func_71410_x().field_71439_g.field_70125_A)};
               Minecraft.func_71410_x().field_71439_g.field_71174_a.func_147297_a(new Rotation(rotations[0], rotations[1], Minecraft.func_71410_x().field_71439_g.field_70122_E));
               Minecraft.func_71410_x().field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(Minecraft.func_71410_x().field_71439_g, Action.START_SNEAKING));
               Minecraft.func_71410_x().field_71442_b.func_187099_a(Minecraft.func_71410_x().field_71439_g, Minecraft.func_71410_x().field_71441_e, neighbor, side2, hitVec, hand);
               Minecraft.func_71410_x().field_71439_g.func_184609_a(hand);
               Minecraft.func_71410_x().field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(Minecraft.func_71410_x().field_71439_g, Action.STOP_SNEAKING));
               return;
            }
         }
      }

   }

   public static int findBlock(Block block) {
      return findItem((new ItemStack(block)).func_77973_b());
   }

   public static int findItem(Item item) {
      try {
         for(int i = 0; i < 9; ++i) {
            ItemStack stack = Minecraft.func_71410_x().field_71439_g.field_71071_by.func_70301_a(i);
            if (item == stack.func_77973_b()) {
               return i;
            }
         }
      } catch (Exception var3) {
      }

      return -1;
   }

   public static double[] calculateLookAt(double px, double py, double pz, EntityPlayer me) {
      double dirx = me.field_70165_t - px;
      double diry = me.field_70163_u - py;
      double dirz = me.field_70161_v - pz;
      double len = Math.sqrt(dirx * dirx + diry * diry + dirz * dirz);
      dirx /= len;
      diry /= len;
      dirz /= len;
      double pitch = Math.asin(diry);
      double yaw = Math.atan2(dirz, dirx);
      pitch = pitch * 180.0D / 3.141592653589793D;
      yaw = yaw * 180.0D / 3.141592653589793D;
      yaw += 90.0D;
      return new double[]{yaw, pitch};
   }

   public static void rotate(float yaw, float pitch) {
      Minecraft.func_71410_x().field_71439_g.field_70177_z = yaw;
      Minecraft.func_71410_x().field_71439_g.field_70125_A = pitch;
   }

   public static void rotate(double[] rotations) {
      Minecraft.func_71410_x().field_71439_g.field_70177_z = (float)rotations[0];
      Minecraft.func_71410_x().field_71439_g.field_70125_A = (float)rotations[1];
   }

   public static void lookAtBlock(BlockPos blockToLookAt) {
      rotate(calculateLookAt((double)blockToLookAt.func_177958_n(), (double)blockToLookAt.func_177956_o(), (double)blockToLookAt.func_177952_p(), Minecraft.func_71410_x().field_71439_g));
   }

   public static BlockPos getRelativeBlockPos(EntityPlayer player, int ChangeX, int ChangeY, int ChangeZ) {
      int[] playerCoords = new int[]{(int)player.field_70165_t, (int)player.field_70163_u, (int)player.field_70161_v};
      BlockPos pos;
      if (player.field_70165_t < 0.0D && player.field_70161_v < 0.0D) {
         pos = new BlockPos(playerCoords[0] + ChangeX - 1, playerCoords[1] + ChangeY, playerCoords[2] + ChangeZ - 1);
      } else if (player.field_70165_t < 0.0D && player.field_70161_v > 0.0D) {
         pos = new BlockPos(playerCoords[0] + ChangeX - 1, playerCoords[1] + ChangeY, playerCoords[2] + ChangeZ);
      } else if (player.field_70165_t > 0.0D && player.field_70161_v < 0.0D) {
         pos = new BlockPos(playerCoords[0] + ChangeX, playerCoords[1] + ChangeY, playerCoords[2] + ChangeZ - 1);
      } else {
         pos = new BlockPos(playerCoords[0] + ChangeX, playerCoords[1] + ChangeY, playerCoords[2] + ChangeZ);
      }

      return pos;
   }

   public static String vectorToString(Vec3d vector, boolean... includeY) {
      boolean reallyIncludeY = includeY.length <= 0 || includeY[0];
      StringBuilder builder = new StringBuilder();
      builder.append('(');
      builder.append((int)Math.floor(vector.field_72450_a));
      builder.append(", ");
      if (reallyIncludeY) {
         builder.append((int)Math.floor(vector.field_72448_b));
         builder.append(", ");
      }

      builder.append((int)Math.floor(vector.field_72449_c));
      builder.append(")");
      return builder.toString();
   }

   public static String vectorToString(BlockPos pos) {
      return vectorToString(new Vec3d(pos));
   }
}
