package me.travis.wurstplus.util;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;
import java.util.UUID;
import javax.net.ssl.HttpsURLConnection;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;

public class PlayerInfo implements GsonConstant {
   private final UUID id;
   private final UUID offlineId;
   private final boolean isOfflinePlayer;
   private final List names;

   public PlayerInfo(UUID id) throws IOException {
      Objects.requireNonNull(id);
      this.id = id;
      this.names = ImmutableList.copyOf(lookupNames(id));
      this.offlineId = EntityPlayerSP.func_175147_b(this.getName());
      this.isOfflinePlayer = false;
   }

   public PlayerInfo(String name) throws IOException, NullPointerException {
      Objects.requireNonNull(name);
      JsonArray ar = new JsonArray();
      ar.add(name);
      JsonArray array = getResources(new URL("https://api.mojang.com/profiles/minecraft"), "POST", ar).getAsJsonArray();
      JsonObject node = array.get(0).getAsJsonObject();
      UUID uuid = PlayerInfoHelper.getIdFromString(node.get("id").getAsString());
      Objects.requireNonNull(uuid);
      this.id = uuid;
      this.names = ImmutableList.copyOf(lookupNames(uuid));
      this.offlineId = EntityPlayerSP.func_175147_b(name);
      this.isOfflinePlayer = false;
   }

   public PlayerInfo(String name, boolean dummy) {
      this.id = EntityPlayerSP.func_175147_b(name);
      this.names = Collections.singletonList(new PlayerInfo.Name(name));
      this.offlineId = this.id;
      this.isOfflinePlayer = true;
   }

   private static List lookupNames(UUID id) throws IOException {
      JsonArray array = getResources(new URL("https://api.mojang.com/user/profiles/" + PlayerInfoHelper.getIdNoHyphens(id) + "/names"), "GET").getAsJsonArray();
      List temp = Lists.newArrayList();
      Iterator var3 = array.iterator();

      while(var3.hasNext()) {
         JsonElement e = (JsonElement)var3.next();
         JsonObject node = e.getAsJsonObject();
         String name = node.get("name").getAsString();
         long changedAt = node.has("changedToAt") ? node.get("changedToAt").getAsLong() : 0L;
         temp.add(new PlayerInfo.Name(name, changedAt));
      }

      Collections.sort(temp);
      return temp;
   }

   public UUID getId() {
      return this.id;
   }

   public UUID getOfflineId() {
      return this.offlineId;
   }

   public boolean isOfflinePlayer() {
      return this.isOfflinePlayer;
   }

   public String getName() {
      return !this.names.isEmpty() ? ((PlayerInfo.Name)this.names.get(0)).getName() : null;
   }

   public List getNameHistory() {
      return this.names;
   }

   public String getNameHistoryAsString() {
      StringBuilder builder = new StringBuilder();
      if (!this.names.isEmpty()) {
         Iterator it = this.names.iterator();
         it.next();

         while(it.hasNext()) {
            PlayerInfo.Name next = (PlayerInfo.Name)it.next();
            builder.append(next.getName());
            if (it.hasNext()) {
               builder.append(", ");
            }
         }
      }

      return builder.toString();
   }

   public boolean isLocalPlayer() {
      return String.CASE_INSENSITIVE_ORDER.compare(this.getName(), Minecraft.func_71410_x().field_71439_g.func_70005_c_()) == 0;
   }

   public boolean matches(UUID otherId) {
      return otherId != null && (otherId.equals(this.getOfflineId()) || otherId.equals(this.getId()));
   }

   public boolean equals(Object obj) {
      return obj instanceof PlayerInfo && this.id.equals(((PlayerInfo)obj).id);
   }

   public int hashCode() {
      return this.id.hashCode();
   }

   public String toString() {
      return this.id.toString();
   }

   private static JsonElement getResources(URL url, String request, JsonElement element) throws IOException {
      HttpsURLConnection connection = null;

      try {
         connection = (HttpsURLConnection)url.openConnection();
         connection.setDoOutput(true);
         connection.setRequestMethod(request);
         connection.setRequestProperty("Content-Type", "application/json");
         if (element != null) {
            DataOutputStream output = new DataOutputStream(connection.getOutputStream());
            output.writeBytes(GSON.toJson(element));
            output.close();
         }

         Scanner scanner = new Scanner(connection.getInputStream());
         StringBuilder builder = new StringBuilder();

         while(scanner.hasNextLine()) {
            builder.append(scanner.nextLine());
            builder.append('\n');
         }

         scanner.close();
         String json = builder.toString();
         JsonElement data = PARSER.parse(json);
         return data;
      } finally {
         if (connection != null) {
            connection.disconnect();
         }

      }
   }

   private static JsonElement getResources(URL url, String request) throws IOException {
      return getResources(url, request, (JsonElement)null);
   }

   public static class Name implements Comparable {
      private final String name;
      private final long changedAt;

      public Name(String name, long changedAt) {
         this.name = name;
         this.changedAt = changedAt;
      }

      public Name(String name) {
         this(name, 0L);
      }

      public String getName() {
         return this.name;
      }

      public long getTimeChanged() {
         return this.changedAt;
      }

      public int compareTo(PlayerInfo.Name o) {
         return Long.compare(o.changedAt, this.changedAt);
      }

      public boolean equals(Object obj) {
         return obj instanceof PlayerInfo.Name && this.name.equalsIgnoreCase(((PlayerInfo.Name)obj).getName()) && this.changedAt == ((PlayerInfo.Name)obj).changedAt;
      }

      public int hashCode() {
         return Objects.hash(new Object[]{this.name, this.changedAt});
      }
   }
}
