package me.travis.wurstplus.util;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.BufferedWriter;
import java.io.FileWriter;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector4f;

public class Utils {
   private static Minecraft mc = Minecraft.func_71410_x();

   public static String vectorToString(Vec3d vector, boolean... includeY) {
      boolean reallyIncludeY = includeY.length <= 0 || includeY[0];
      StringBuilder builder = new StringBuilder();
      builder.append('(');
      builder.append((int)Math.floor(vector.field_72450_a));
      builder.append(", ");
      if (reallyIncludeY) {
         builder.append((int)Math.floor(vector.field_72448_b));
         builder.append(", ");
      }

      builder.append((int)Math.floor(vector.field_72449_c));
      builder.append(")");
      return builder.toString();
   }

   public static String vectorToString(BlockPos pos) {
      return vectorToString(new Vec3d(pos));
   }

   public static void drawRainbowString(String string, int x, int y, float brightness) {
      int thisX = x;
      char[] var5 = string.toCharArray();
      int var6 = var5.length;

      for(int var7 = 0; var7 < var6; ++var7) {
         char c = var5[var7];
         String s = String.valueOf(c);
         thisX += x;
      }

   }

   public static Color rainbowColour(long offset, float fade) {
      float hue = (float)(System.nanoTime() + offset) / 1.0E10F % 1.0F;
      Color c = new Color((int)Long.parseLong(Integer.toHexString(Color.HSBtoRGB(hue, 1.0F, 1.0F)), 16));
      return new Color((float)c.getRed() / 255.0F * fade, (float)c.getGreen() / 255.0F * fade, (float)c.getBlue() / 255.0F * fade, (float)c.getAlpha() / 255.0F);
   }

   public static double roundDouble(double value, int places) {
      double scale = Math.pow(10.0D, (double)places);
      return (double)Math.round(value * scale) / scale;
   }

   public static void copyToClipboard(String s) {
      StringSelection selection = new StringSelection(s);
      Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
      clipboard.setContents(selection, selection);
   }

   public static boolean writeFile(String file, String contents) {
      try {
         BufferedWriter writer = new BufferedWriter(new FileWriter(file));
         writer.write(contents);
         writer.close();
         return true;
      } catch (Exception var3) {
         var3.printStackTrace();
         return false;
      }
   }

   private static void vecByMatrix(Vector4f vec, Matrix4f matrix) {
      float x = vec.x;
      float y = vec.y;
      float z = vec.z;
      vec.x = x * matrix.m00 + y * matrix.m10 + z * matrix.m20 + matrix.m30;
      vec.y = x * matrix.m01 + y * matrix.m11 + z * matrix.m21 + matrix.m31;
      vec.z = x * matrix.m02 + y * matrix.m12 + z * matrix.m22 + matrix.m32;
      vec.w = x * matrix.m03 + y * matrix.m13 + z * matrix.m23 + matrix.m33;
   }

   public static float getPlayerDirection() {
      float var1 = mc.field_71439_g.field_70177_z;
      if (mc.field_71439_g.field_191988_bg < 0.0F) {
         var1 += 180.0F;
      }

      float forward = 1.0F;
      if (mc.field_71439_g.field_191988_bg < 0.0F) {
         forward = -0.5F;
      } else if (mc.field_71439_g.field_191988_bg > 0.0F) {
         forward = 0.5F;
      }

      if (mc.field_71439_g.field_70702_br > 0.0F) {
         var1 -= 90.0F * forward;
      }

      if (mc.field_71439_g.field_70702_br < 0.0F) {
         var1 += 90.0F * forward;
      }

      var1 *= 0.017453292F;
      return var1;
   }
}
