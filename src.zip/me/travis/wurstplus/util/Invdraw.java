package me.travis.wurstplus.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;

public final class Invdraw {
   public void drawInventory(Integer x, Integer y, EntityPlayerSP player) {
      NonNullList inventory = Minecraft.func_71410_x().field_71439_g.field_71071_by.field_70462_a;
      GlStateManager.func_179094_E();
      GlStateManager.func_179118_c();
      GlStateManager.func_179086_m(256);
      GlStateManager.func_179147_l();
      Minecraft.func_71410_x().field_71446_o.func_110577_a(new ResourceLocation("textures/gui/container/shulker_box.png"));
      GlStateManager.func_179124_c(1.0F, 1.0F, 1.0F);
      Minecraft.func_71410_x().field_71456_v.func_73729_b(x - 8, y + 1, 0, 0, 176, 76);
      GlStateManager.func_179084_k();
      GlStateManager.func_179097_i();
      GlStateManager.func_179140_f();
      GlStateManager.func_179126_j();
      GlStateManager.func_179141_d();
      GlStateManager.func_179121_F();

      for(int i = 9; i < inventory.size(); ++i) {
         GlStateManager.func_179094_E();
         GlStateManager.func_179086_m(256);
         GlStateManager.func_179097_i();
         GlStateManager.func_179126_j();
         RenderHelper.func_74519_b();
         GlStateManager.func_179152_a(1.0F, 1.0F, 0.01F);
         Minecraft.func_71410_x().func_175599_af().func_180450_b((ItemStack)inventory.get(i), x + i % 9 * 18, (i / 9 + 1) * 18 + y + 1 - 18);
         Minecraft.func_71410_x().func_175599_af().func_175030_a(Minecraft.func_71410_x().field_71466_p, (ItemStack)inventory.get(i), x + i % 9 * 18, (i / 9 + 1) * 18 + y + 1 - 18);
         GlStateManager.func_179152_a(1.0F, 1.0F, 1.0F);
         RenderHelper.func_74518_a();
         GlStateManager.func_179141_d();
         GlStateManager.func_179084_k();
         GlStateManager.func_179140_f();
         GlStateManager.func_179139_a(0.5D, 0.5D, 0.5D);
         GlStateManager.func_179097_i();
         GlStateManager.func_179126_j();
         GlStateManager.func_179152_a(2.0F, 2.0F, 2.0F);
         GlStateManager.func_179121_F();
      }

   }
}
