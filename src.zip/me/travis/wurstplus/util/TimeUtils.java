package me.travis.wurstplus.util;

import java.time.Duration;
import java.time.Instant;

public class TimeUtils {
   public static boolean hasTimePassed(Instant start, Instant current, int seconds) {
      return Duration.between(start, current).getSeconds() >= (long)seconds;
   }
}
