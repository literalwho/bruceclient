package me.travis.wurstplus.util;

public final class Timer {
   private long lastCheck = getSystemTime();

   public boolean hasReach(int targetTime) {
      return this.getTimePassed() >= (long)targetTime;
   }

   public long getTimePassed() {
      return getSystemTime() - this.lastCheck;
   }

   public void reset() {
      this.lastCheck = getSystemTime();
   }

   public static long getSystemTime() {
      return System.nanoTime() / 1000000L;
   }
}
