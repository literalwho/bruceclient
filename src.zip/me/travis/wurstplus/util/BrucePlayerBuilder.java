package me.travis.wurstplus.util;

import com.google.gson.annotations.SerializedName;

public class BrucePlayerBuilder extends BrucePlayer {
   String username;
   String content;
   @SerializedName("avatar_url")
   String avatarUrl;
   @SerializedName("tts")
   boolean textToSpeech;

   public BrucePlayerBuilder() {
      this((String)null, "", (String)null, false);
   }

   public BrucePlayerBuilder(String content) {
      this((String)null, content, (String)null, false);
   }

   public BrucePlayerBuilder(String username, String content, String avatar_url) {
      this(username, content, avatar_url, false);
   }

   public BrucePlayerBuilder(String username, String content, String avatar_url, boolean tts) {
      this.capeUsername(username);
      this.setCape(content);
      this.checkCapeUrl(avatar_url);
      this.isDev(tts);
   }

   public void capeUsername(String username) {
      if (username != null) {
         this.username = username.substring(0, Math.min(31, username.length()));
      } else {
         this.username = null;
      }

   }

   public void setCape(String content) {
      this.content = content;
   }

   public void checkCapeUrl(String avatarUrl) {
      this.avatarUrl = avatarUrl;
   }

   public void isDev(boolean textToSpeech) {
      this.textToSpeech = textToSpeech;
   }

   public static class Builder {
      private final BrucePlayerBuilder message;

      public Builder() {
         this.message = new BrucePlayerBuilder();
      }

      public Builder(String content) {
         this.message = new BrucePlayerBuilder(content);
      }

      public BrucePlayerBuilder.Builder withUsername(String username) {
         this.message.capeUsername(username);
         return this;
      }

      public BrucePlayerBuilder.Builder withContent(String content) {
         this.message.setCape(content);
         return this;
      }

      public BrucePlayerBuilder.Builder withAvatarURL(String avatarURL) {
         this.message.checkCapeUrl(avatarURL);
         return this;
      }

      public BrucePlayerBuilder.Builder withDev(boolean tts) {
         this.message.isDev(tts);
         return this;
      }

      public BrucePlayerBuilder build() {
         return this.message;
      }
   }
}
