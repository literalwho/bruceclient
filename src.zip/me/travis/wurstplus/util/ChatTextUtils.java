package me.travis.wurstplus.util;

import java.util.Random;

public class ChatTextUtils {
   public static final String CHAT_SUFFIX = " ⏐ Bruce Client";
   public static final String SECTIONSIGN = "§";
   private static Random rand = new Random();

   public static String appendChatSuffix(String message) {
      message = cropMaxLengthMessage(message, " ⏐ Bruce Client".length());
      message = message + " ⏐ Bruce Client";
      return cropMaxLengthMessage(message);
   }

   public static String appendChatSuffix(String message, String suffix) {
      message = cropMaxLengthMessage(message, suffix.length());
      message = message + suffix;
      return cropMaxLengthMessage(message);
   }

   public static String generateRandomHexSuffix(int n) {
      StringBuffer sb = new StringBuffer();
      sb.append("[");
      sb.append(Integer.toHexString((rand.nextInt() + 11) * rand.nextInt()).substring(0, n));
      sb.append(']');
      return sb.toString();
   }

   public static String cropMaxLengthMessage(String s, int i) {
      if (s.length() > 255 - i) {
         s = s.substring(0, 255 - i);
      }

      return s;
   }

   public static String cropMaxLengthMessage(String s) {
      return cropMaxLengthMessage(s, 0);
   }

   public static String transformPlainToFancy(String input) {
      String output = input.toLowerCase();
      output = output.replace("a", "ᴀ");
      output = output.replace("b", "ʙ");
      output = output.replace("c", "ᴄ");
      output = output.replace("d", "ᴅ");
      output = output.replace("e", "ᴇ");
      output = output.replace("f", "ғ");
      output = output.replace("g", "ɢ");
      output = output.replace("h", "ʜ");
      output = output.replace("i", "ɪ");
      output = output.replace("j", "ᴊ");
      output = output.replace("k", "ᴋ");
      output = output.replace("l", "ʟ");
      output = output.replace("m", "ᴍ");
      output = output.replace("n", "ɴ");
      output = output.replace("o", "ᴏ");
      output = output.replace("p", "ᴘ");
      output = output.replace("q", "ǫ");
      output = output.replace("r", "ʀ");
      output = output.replace("s", "ѕ");
      output = output.replace("t", "ᴛ");
      output = output.replace("u", "ᴜ");
      output = output.replace("v", "ᴠ");
      output = output.replace("w", "ᴡ");
      output = output.replace("x", "х");
      output = output.replace("y", "ʏ");
      output = output.replace("z", "ᴢ");
      return output;
   }
}
