package me.travis.wurstplus.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParser;

interface GsonConstant {
   Gson GSON = new Gson();
   Gson GSON_PRETTY = (new GsonBuilder()).setPrettyPrinting().create();
   JsonParser PARSER = new JsonParser();
}
