package me.travis.wurstplus.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.client.Minecraft;

public class OnlineFriends {
   public static List entities = new ArrayList();

   public static List getFriends() {
      entities.clear();
      entities.addAll((Collection)Minecraft.func_71410_x().field_71441_e.field_73010_i.stream().filter((entityPlayer) -> {
         return Friends.isFriend(entityPlayer.func_70005_c_());
      }).collect(Collectors.toList()));
      return entities;
   }
}
