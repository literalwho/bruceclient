package me.travis.wurstplus;

import net.arikia.dev.drpc.DiscordEventHandlers;
import net.arikia.dev.drpc.DiscordRPC;
import net.arikia.dev.drpc.DiscordRichPresence;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraftforge.fml.common.FMLLog;

public class DiscordPresence {
   public static Minecraft mc = Minecraft.func_71410_x();
   private static final String APP_ID = "739167888832856126";
   private static DiscordRichPresence presence = new DiscordRichPresence();
   private static boolean hasStarted = false;
   public static String details;
   public static String state;
   public static int players;
   public static int maxPlayers;
   public static ServerData svr;
   public static String[] popInfo;
   public static int players2;
   public static int maxPlayers2;

   public static boolean start() {
      FMLLog.log.info("Starting Discord RPC");
      if (hasStarted) {
         return false;
      } else {
         hasStarted = true;
         DiscordEventHandlers handlers = new DiscordEventHandlers();
         handlers.disconnected = (var1, var2) -> {
            System.out.println("Discord RPC disconnected, var1: " + String.valueOf(var1) + ", var2: " + var2);
         };
         DiscordRPC.discordInitialize("739167888832856126", handlers, true, "");
         presence.startTimestamp = System.currentTimeMillis() / 1000L;
         presence.details = "Bruce";
         presence.state = "Bruce ontop wtf?";
         presence.largeImageKey = "monkey";
         DiscordRPC.discordUpdatePresence(presence);
         (new Thread(() -> {
            while(!Thread.currentThread().isInterrupted()) {
               try {
                  DiscordRPC.discordRunCallbacks();
                  details = "";
                  state = "";
                  players = 0;
                  maxPlayers = 0;
                  if (mc.func_71387_A()) {
                     details = "Singleplayer";
                  } else if (mc.func_147104_D() != null) {
                     svr = mc.func_147104_D();
                     if (!svr.field_78845_b.equals("")) {
                        details = "With the boys";
                        state = svr.field_78845_b;
                        if (svr.field_78846_c != null) {
                           popInfo = svr.field_78846_c.split("/");
                           if (popInfo.length > 2) {
                              players2 = Integer.valueOf(popInfo[0]);
                              maxPlayers2 = Integer.valueOf(popInfo[1]);
                           }
                        }

                        if (state.contains("2b2t.org")) {
                           try {
                              if (wurstplusMod.lastChat.startsWith("Position in queue: ")) {
                                 state = state + " " + Integer.parseInt(wurstplusMod.lastChat.substring(19)) + " in queue";
                              }
                           } catch (Throwable var2) {
                              var2.printStackTrace();
                           }
                        }
                     }
                  } else {
                     details = "Vibing";
                     state = "Listening to Bruce Willis";
                  }

                  if (!details.equals(presence.details) || !state.equals(presence.state)) {
                     presence.startTimestamp = System.currentTimeMillis() / 1000L;
                  }

                  presence.details = details;
                  presence.state = state;
                  DiscordRPC.discordUpdatePresence(presence);
               } catch (Exception var3) {
                  var3.printStackTrace();
               }

               try {
                  Thread.sleep(5000L);
               } catch (InterruptedException var1) {
                  var1.printStackTrace();
               }
            }

         }, "Discord-RPC-Callback-Handler")).start();
         FMLLog.log.info("Discord RPC initialised succesfully");
         return true;
      }
   }

   private static void lambdastart() {
      while(!Thread.currentThread().isInterrupted()) {
         try {
            DiscordRPC.discordRunCallbacks();
            String details = "";
            String state = "";
            int players = false;
            int maxPlayers = false;
            if (mc.func_71387_A()) {
               details = "Lonely monkey";
            } else if (mc.func_147104_D() != null) {
               ServerData svr = mc.func_147104_D();
               if (!svr.field_78845_b.equals("")) {
                  details = "With The Boys";
                  state = svr.field_78845_b;
                  if (svr.field_78846_c != null) {
                     String[] popInfo = svr.field_78846_c.split("/");
                     if (popInfo.length > 2) {
                        int players = Integer.valueOf(popInfo[0]);
                        int var10 = Integer.valueOf(popInfo[1]);
                     }
                  }

                  if (state.contains("2b2t.org")) {
                     try {
                        if (wurstplusMod.lastChat.startsWith("Queue simulator: ")) {
                           state = state + " " + Integer.parseInt(wurstplusMod.lastChat.substring(19)) + " people infront";
                        }
                     } catch (Throwable var7) {
                        var7.printStackTrace();
                     }
                  }
               }
            } else {
               details = "Vibing";
               state = "Listening to Bruce WIllis";
            }

            if (!details.equals(presence.details) || !state.equals(presence.state)) {
               presence.startTimestamp = System.currentTimeMillis() / 1000L;
            }

            presence.details = details;
            presence.state = state;
            DiscordRPC.discordUpdatePresence(presence);
         } catch (Exception var8) {
            var8.printStackTrace();
         }

         try {
            Thread.sleep(5000L);
         } catch (InterruptedException var6) {
            var6.printStackTrace();
         }
      }

   }

   private static void lambdastart(int var1, String var2) {
      System.out.println("Discord RPC disconnected, var1: " + String.valueOf(var1) + ", var2: " + var2);
   }

   public static void shutdown() {
      DiscordRPC.discordShutdown();
   }
}
