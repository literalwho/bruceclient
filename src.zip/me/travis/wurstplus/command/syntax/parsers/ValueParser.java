package me.travis.wurstplus.command.syntax.parsers;

import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeMap;
import me.travis.wurstplus.command.syntax.SyntaxChunk;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.module.ModuleManager;
import me.travis.wurstplus.setting.Setting;

public class ValueParser extends AbstractParser {
   int moduleIndex;

   public ValueParser(int moduleIndex) {
      this.moduleIndex = moduleIndex;
   }

   public String getChunk(SyntaxChunk[] chunks, SyntaxChunk thisChunk, String[] values, String chunkValue) {
      if (this.moduleIndex <= values.length - 1 && chunkValue != null) {
         String module = values[this.moduleIndex];
         Module m = ModuleManager.getModuleByName(module);
         if (m == null) {
            return "";
         } else {
            HashMap possibilities = new HashMap();
            Iterator var8 = m.settingList.iterator();

            Setting aV;
            while(var8.hasNext()) {
               aV = (Setting)var8.next();
               if (aV.getName().toLowerCase().startsWith(chunkValue.toLowerCase())) {
                  possibilities.put(aV.getName(), aV);
               }
            }

            if (possibilities.isEmpty()) {
               return "";
            } else {
               TreeMap p = new TreeMap(possibilities);
               aV = (Setting)p.firstEntry().getValue();
               return aV.getName().substring(chunkValue.length());
            }
         }
      } else {
         return this.getDefaultChunk(thisChunk);
      }
   }
}
