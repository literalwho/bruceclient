package me.travis.wurstplus.command.syntax.parsers;

import java.util.ArrayList;
import java.util.Collections;
import me.travis.wurstplus.command.syntax.SyntaxChunk;

public class EnumParser extends AbstractParser {
   String[] modes;

   public EnumParser(String[] modes) {
      this.modes = modes;
   }

   public String getChunk(SyntaxChunk[] chunks, SyntaxChunk thisChunk, String[] values, String chunkValue) {
      String[] var6;
      int var7;
      int var8;
      String s;
      if (chunkValue != null) {
         ArrayList possibilities = new ArrayList();
         var6 = this.modes;
         var7 = var6.length;

         for(var8 = 0; var8 < var7; ++var8) {
            s = var6[var8];
            if (s.toLowerCase().startsWith(chunkValue.toLowerCase())) {
               possibilities.add(s);
            }
         }

         if (possibilities.isEmpty()) {
            return "";
         } else {
            Collections.sort(possibilities);
            String s = (String)possibilities.get(0);
            return s.substring(chunkValue.length());
         }
      } else {
         String s = "";
         var6 = this.modes;
         var7 = var6.length;

         for(var8 = 0; var8 < var7; ++var8) {
            s = var6[var8];
            s = s + s + ":";
         }

         s = s.substring(0, s.length() - 1);
         return (thisChunk.isHeadless() ? "" : thisChunk.getHead()) + (thisChunk.isNecessary() ? "<" : "[") + s + (thisChunk.isNecessary() ? ">" : "]");
      }
   }
}
