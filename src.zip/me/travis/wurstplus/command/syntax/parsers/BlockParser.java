package me.travis.wurstplus.command.syntax.parsers;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;
import me.travis.wurstplus.command.syntax.SyntaxChunk;
import net.minecraft.block.Block;
import net.minecraft.util.ResourceLocation;

public class BlockParser extends AbstractParser {
   private static HashMap blockNames = new HashMap();

   public BlockParser() {
      if (blockNames.isEmpty()) {
         Iterator var1 = Block.field_149771_c.func_148742_b().iterator();

         while(var1.hasNext()) {
            ResourceLocation resourceLocation = (ResourceLocation)var1.next();
            blockNames.put(resourceLocation.toString().replace("minecraft:", "").replace("_", ""), Block.field_149771_c.func_82594_a(resourceLocation));
         }

      }
   }

   public String getChunk(SyntaxChunk[] chunks, SyntaxChunk thisChunk, String[] values, String chunkValue) {
      try {
         if (chunkValue == null) {
            return (thisChunk.isHeadless() ? "" : thisChunk.getHead()) + (thisChunk.isNecessary() ? "<" : "[") + thisChunk.getType() + (thisChunk.isNecessary() ? ">" : "]");
         } else {
            HashMap possibilities = new HashMap();
            Iterator var6 = blockNames.keySet().iterator();

            while(var6.hasNext()) {
               String s = (String)var6.next();
               if (s.toLowerCase().startsWith(chunkValue.toLowerCase().replace("minecraft:", "").replace("_", ""))) {
                  possibilities.put(s, blockNames.get(s));
               }
            }

            if (possibilities.isEmpty()) {
               return "";
            } else {
               TreeMap p = new TreeMap(possibilities);
               Entry e = p.firstEntry();
               return ((String)e.getKey()).substring(chunkValue.length());
            }
         }
      } catch (Exception var8) {
         return "";
      }
   }

   public static Block getBlockFromName(String name) {
      return !blockNames.containsKey(name) ? null : (Block)blockNames.get(name);
   }

   public static Object getKeyFromValue(Map hm, Object value) {
      Iterator var2 = hm.keySet().iterator();

      Object o;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         o = var2.next();
      } while(!hm.get(o).equals(value));

      return o;
   }

   public static String getNameFromBlock(Block b) {
      return !blockNames.containsValue(b) ? null : (String)getKeyFromValue(blockNames, b);
   }
}
