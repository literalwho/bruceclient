package me.travis.wurstplus.command.syntax.parsers;

import me.travis.wurstplus.command.syntax.SyntaxChunk;

public class DependantParser extends AbstractParser {
   int dependantIndex;
   private DependantParser.Dependency dependancy;

   public DependantParser(int dependantIndex, DependantParser.Dependency dependancy) {
      this.dependantIndex = dependantIndex;
      this.dependancy = dependancy;
   }

   protected String getDefaultChunk(SyntaxChunk chunk) {
      return this.dependancy.getEscape();
   }

   public String getChunk(SyntaxChunk[] chunks, SyntaxChunk thisChunk, String[] values, String chunkValue) {
      if (chunkValue != null && !chunkValue.equals("")) {
         return "";
      } else if (values.length <= this.dependantIndex) {
         return this.getDefaultChunk(thisChunk);
      } else {
         return values[this.dependantIndex] != null && !values[this.dependantIndex].equals("") ? this.dependancy.feed(values[this.dependantIndex]) : "";
      }
   }

   public static class Dependency {
      String[][] map = new String[0][];
      String escape;

      public Dependency(String[][] map, String escape) {
         this.map = map;
         this.escape = escape;
      }

      private String[] containsKey(String[][] map, String key) {
         String[][] var3 = map;
         int var4 = map.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            String[] s = var3[var5];
            if (s[0].equals(key)) {
               return s;
            }
         }

         return null;
      }

      public String feed(String food) {
         String[] entry = this.containsKey(this.map, food);
         return entry != null ? entry[1] : this.getEscape();
      }

      public String[][] getMap() {
         return this.map;
      }

      public String getEscape() {
         return this.escape;
      }
   }
}
