package me.travis.wurstplus.command.syntax;

public interface SyntaxParser {
   String getChunk(SyntaxChunk[] var1, SyntaxChunk var2, String[] var3, String var4);
}
