package me.travis.wurstplus.command;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import me.travis.wurstplus.wurstplusMod;
import me.travis.wurstplus.command.commands.BindCommand;
import me.travis.wurstplus.util.ClassFinder;

public class CommandManager {
   private ArrayList commands = new ArrayList();

   public CommandManager() {
      Set classList = ClassFinder.findClasses(BindCommand.class.getPackage().getName(), Command.class);
      Iterator var2 = classList.iterator();

      while(var2.hasNext()) {
         Class s = (Class)var2.next();
         if (Command.class.isAssignableFrom(s)) {
            try {
               Command command = (Command)s.getConstructor().newInstance();
               this.commands.add(command);
            } catch (Exception var5) {
               var5.printStackTrace();
               System.err.println("Couldn't initiate command " + s.getSimpleName() + "! Err: " + var5.getClass().getSimpleName() + ", message: " + var5.getMessage());
            }
         }
      }

      wurstplusMod.log.info("Commands initialised");
   }

   public void callCommand(String command) {
      String[] parts = command.split(" (?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
      String label = parts[0].substring(1);
      String[] args = removeElement(parts, 0);

      for(int i = 0; i < args.length; ++i) {
         if (args[i] != null) {
            args[i] = strip(args[i], "\"");
         }
      }

      Iterator var7 = this.commands.iterator();

      Command c;
      do {
         if (!var7.hasNext()) {
            Command.sendChatMessage("Unknown command. try 'commands' for a list of commands.");
            return;
         }

         c = (Command)var7.next();
      } while(!c.getLabel().equalsIgnoreCase(label));

      c.call(parts);
   }

   public static String[] removeElement(String[] input, int indexToDelete) {
      List result = new LinkedList();

      for(int i = 0; i < input.length; ++i) {
         if (i != indexToDelete) {
            result.add(input[i]);
         }
      }

      return (String[])((String[])result.toArray(input));
   }

   private static String strip(String str, String key) {
      return str.startsWith(key) && str.endsWith(key) ? str.substring(key.length(), str.length() - key.length()) : str;
   }

   public Command getCommandByLabel(String commandLabel) {
      Iterator var2 = this.commands.iterator();

      Command c;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         c = (Command)var2.next();
      } while(!c.getLabel().equals(commandLabel));

      return c;
   }

   public ArrayList getCommands() {
      return this.commands;
   }
}
