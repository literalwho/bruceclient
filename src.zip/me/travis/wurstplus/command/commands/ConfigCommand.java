package me.travis.wurstplus.command.commands;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import me.travis.wurstplus.wurstplusMod;
import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.command.syntax.ChunkBuilder;
import me.travis.wurstplus.command.syntax.parsers.DependantParser;
import me.travis.wurstplus.command.syntax.parsers.EnumParser;
import me.travis.wurstplus.gui.wurstplus.wurstplusGUI;

public class ConfigCommand extends Command {
   public ConfigCommand() {
      super("config", (new ChunkBuilder()).append("mode", true, new EnumParser(new String[]{"reload", "save", "path"})).append("path", true, new DependantParser(0, new DependantParser.Dependency(new String[][]{{"path", "path"}}, ""))).build());
   }

   public void call(String[] args) {
      if (args[0] == null) {
         Command.sendChatMessage("Missing argument &bmode&r: Choose from reload, save or path");
      } else {
         String var2 = args[0].toLowerCase();
         byte var3 = -1;
         switch(var2.hashCode()) {
         case -934641255:
            if (var2.equals("reload")) {
               var3 = 0;
            }
            break;
         case 3433509:
            if (var2.equals("path")) {
               var3 = 2;
            }
            break;
         case 3522941:
            if (var2.equals("save")) {
               var3 = 1;
            }
         }

         switch(var3) {
         case 0:
            this.reload();
            break;
         case 1:
            try {
               wurstplusMod.saveConfigurationUnsafe();
               Command.sendChatMessage("Saved configuration!");
            } catch (IOException var18) {
               var18.printStackTrace();
               Command.sendChatMessage("Failed to save! " + var18.getMessage());
            }
            break;
         case 2:
            if (args[1] == null) {
               Path file = Paths.get(wurstplusMod.getConfigName());
               Command.sendChatMessage("Path to configuration: &b" + file.toAbsolutePath().toString());
            } else {
               String newPath = args[1];
               if (!wurstplusMod.isFilenameValid(newPath)) {
                  Command.sendChatMessage("&b" + newPath + "&r is not a valid path");
               } else {
                  try {
                     BufferedWriter writer = Files.newBufferedWriter(Paths.get("BruceClientLastConfig.txt"));
                     Throwable var6 = null;

                     try {
                        writer.write(newPath);
                        this.reload();
                        Command.sendChatMessage("Configuration path set to &b" + newPath + "&r!");
                     } catch (Throwable var17) {
                        var6 = var17;
                        throw var17;
                     } finally {
                        if (writer != null) {
                           if (var6 != null) {
                              try {
                                 writer.close();
                              } catch (Throwable var16) {
                                 var6.addSuppressed(var16);
                              }
                           } else {
                              writer.close();
                           }
                        }

                     }
                  } catch (IOException var20) {
                     var20.printStackTrace();
                     Command.sendChatMessage("Couldn't set path: " + var20.getMessage());
                  }
               }
            }
            break;
         default:
            Command.sendChatMessage("Incorrect mode, please choose from: reload, save or path");
         }

      }
   }

   private void reload() {
      wurstplusMod.getInstance().guiManager = new wurstplusGUI();
      wurstplusMod.getInstance().guiManager.initializeGUI();
      wurstplusMod.loadConfiguration();
      Command.sendChatMessage("Configuration reloaded!");
   }
}
