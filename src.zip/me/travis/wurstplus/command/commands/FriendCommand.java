package me.travis.wurstplus.command.commands;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.util.UUIDTypeAdapter;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.command.syntax.ChunkBuilder;
import me.travis.wurstplus.command.syntax.parsers.EnumParser;
import me.travis.wurstplus.util.Friends;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetworkPlayerInfo;

public class FriendCommand extends Command {
   public FriendCommand() {
      super("friend", (new ChunkBuilder()).append("mode", true, new EnumParser(new String[]{"add", "del"})).append("name").build());
   }

   public void call(String[] args) {
      Friends var10000;
      if (args[0] != null) {
         if (args[1] == null) {
            Command.sendChatMessage(String.format(Friends.isFriend(args[0]) ? "Yes, %s is your friend." : "No, %s isn't a friend of yours.", args[0]));
            Command.sendChatMessage(String.format(Friends.isFriend(args[0]) ? "Yes, %s is your friend." : "No, %s isn't a friend of yours.", args[0]));
         } else if (!args[0].equalsIgnoreCase("add") && !args[0].equalsIgnoreCase("new")) {
            if (!args[0].equalsIgnoreCase("del") && !args[0].equalsIgnoreCase("remove") && !args[0].equalsIgnoreCase("delete")) {
               Command.sendChatMessage("Please specify either &6add&r or &6remove");
            } else if (!Friends.isFriend(args[1])) {
               Command.sendChatMessage("That player isn't your friend.");
            } else {
               var10000 = Friends.INSTANCE;
               Friends.Friend friend = (Friends.Friend)((ArrayList)Friends.friends.getValue()).stream().filter((friend1) -> {
                  return friend1.getUsername().equalsIgnoreCase(args[1]);
               }).findFirst().get();
               var10000 = Friends.INSTANCE;
               ((ArrayList)Friends.friends.getValue()).remove(friend);
               Command.sendChatMessage("&b" + friend.getUsername() + "&r has been unfriended.");
            }
         } else if (Friends.isFriend(args[1])) {
            Command.sendChatMessage("That player is already your friend.");
         } else {
            (new Thread(() -> {
               Friends.Friend f = getFriendByName(args[1]);
               if (f == null) {
                  Command.sendChatMessage("Failed to find UUID of " + args[1]);
               } else {
                  Friends var10000 = Friends.INSTANCE;
                  ((ArrayList)Friends.friends.getValue()).add(f);
                  Command.sendChatMessage("&b" + f.getUsername() + "&r has been friended.");
               }
            })).start();
         }
      } else {
         var10000 = Friends.INSTANCE;
         if (((ArrayList)Friends.friends.getValue()).isEmpty()) {
            Command.sendChatMessage("You currently don't have any friends added. &bfriend add <name>&r to add one.");
         } else {
            String f = "";
            var10000 = Friends.INSTANCE;

            Friends.Friend friend;
            for(Iterator var3 = ((ArrayList)Friends.friends.getValue()).iterator(); var3.hasNext(); f = f + friend.getUsername() + ", ") {
               friend = (Friends.Friend)var3.next();
            }

            f = f.substring(0, f.length() - 2);
            Command.sendChatMessage("Your friends: " + f);
         }
      }
   }

   public static Friends.Friend getFriendByName(String input) {
      ArrayList infoMap = new ArrayList(Minecraft.func_71410_x().func_147114_u().func_175106_d());
      NetworkPlayerInfo profile = (NetworkPlayerInfo)infoMap.stream().filter((networkPlayerInfo) -> {
         return networkPlayerInfo.func_178845_a().getName().equalsIgnoreCase(input);
      }).findFirst().orElse((Object)null);
      if (profile != null) {
         Friends.Friend f = new Friends.Friend(profile.func_178845_a().getName(), profile.func_178845_a().getId());
         return f;
      } else {
         Command.sendChatMessage("Player isn't online. Looking up UUID..");
         String s = requestIDs("[\"" + input + "\"]");
         if (s != null && !s.isEmpty()) {
            JsonElement element = (new JsonParser()).parse(s);
            if (element.getAsJsonArray().size() == 0) {
               Command.sendChatMessage("Couldn't find player ID. (1)");
            } else {
               try {
                  String id = element.getAsJsonArray().get(0).getAsJsonObject().get("id").getAsString();
                  String username = element.getAsJsonArray().get(0).getAsJsonObject().get("name").getAsString();
                  Friends.Friend friend = new Friends.Friend(username, UUIDTypeAdapter.fromString(id));
                  return friend;
               } catch (Exception var8) {
                  var8.printStackTrace();
                  Command.sendChatMessage("Couldn't find player ID. (2)");
               }
            }
         } else {
            Command.sendChatMessage("Couldn't find player ID. Are you connected to the internet? (0)");
         }

         return null;
      }
   }

   private static String requestIDs(String data) {
      try {
         String query = "https://api.mojang.com/profiles/minecraft";
         URL url = new URL(query);
         HttpURLConnection conn = (HttpURLConnection)url.openConnection();
         conn.setConnectTimeout(5000);
         conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
         conn.setDoOutput(true);
         conn.setDoInput(true);
         conn.setRequestMethod("POST");
         OutputStream os = conn.getOutputStream();
         os.write(data.getBytes("UTF-8"));
         os.close();
         InputStream in = new BufferedInputStream(conn.getInputStream());
         String res = convertStreamToString(in);
         in.close();
         conn.disconnect();
         return res;
      } catch (Exception var8) {
         return null;
      }
   }

   private static String convertStreamToString(InputStream is) {
      Scanner s = (new Scanner(is)).useDelimiter("\\A");
      String r = s.hasNext() ? s.next() : "/";
      return r;
   }
}
