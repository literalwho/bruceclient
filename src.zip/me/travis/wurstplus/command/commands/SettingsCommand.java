package me.travis.wurstplus.command.commands;

import java.util.List;
import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.command.syntax.ChunkBuilder;
import me.travis.wurstplus.command.syntax.parsers.ModuleParser;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.module.ModuleManager;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.impl.EnumSetting;

public class SettingsCommand extends Command {
   public SettingsCommand() {
      super("settings", (new ChunkBuilder()).append("module", true, new ModuleParser()).build());
   }

   public void call(String[] args) {
      if (args[0] == null) {
         Command.sendChatMessage("Please specify a module to display the settings of.");
      } else {
         Module m = ModuleManager.getModuleByName(args[0]);
         if (m == null) {
            Command.sendChatMessage("Couldn't find a module &b" + args[0] + "!");
         } else {
            List settings = m.settingList;
            String[] result = new String[settings.size()];

            for(int i = 0; i < settings.size(); ++i) {
               Setting setting = (Setting)settings.get(i);
               result[i] = "&b" + setting.getName() + "&3(=" + setting.getValue() + ")  &ftype: &3" + setting.getValue().getClass().getSimpleName();
               if (setting instanceof EnumSetting) {
                  result[i] = result[i] + "  (";
                  Enum[] enums = (Enum[])((Enum[])((EnumSetting)setting).clazz.getEnumConstants());
                  Enum[] var8 = enums;
                  int var9 = enums.length;

                  for(int var10 = 0; var10 < var9; ++var10) {
                     Enum e = var8[var10];
                     result[i] = result[i] + e.name() + ", ";
                  }

                  result[i] = result[i].substring(0, result[i].length() - 2) + ")";
               }
            }

            Command.sendStringChatMessage(result);
         }
      }
   }
}
