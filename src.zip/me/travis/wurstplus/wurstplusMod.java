package me.travis.wurstplus;

import com.google.common.base.Converter;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Optional;
import java.util.Map.Entry;
import java.util.stream.Stream;
import me.travis.wurstplus.command.Command;
import me.travis.wurstplus.command.CommandManager;
import me.travis.wurstplus.event.ForgeEventProcessor;
import me.travis.wurstplus.gui.rgui.component.AlignedComponent;
import me.travis.wurstplus.gui.rgui.component.container.use.Frame;
import me.travis.wurstplus.gui.rgui.util.ContainerHelper;
import me.travis.wurstplus.gui.rgui.util.Docking;
import me.travis.wurstplus.gui.wurstplus.wurstplusGUI;
import me.travis.wurstplus.module.Module;
import me.travis.wurstplus.module.ModuleManager;
import me.travis.wurstplus.module.modules.chat.Announcer;
import me.travis.wurstplus.module.modules.misc.MiddleClickFriend;
import me.travis.wurstplus.setting.Setting;
import me.travis.wurstplus.setting.Settings;
import me.travis.wurstplus.setting.SettingsRegister;
import me.travis.wurstplus.setting.config.Configuration;
import me.travis.wurstplus.util.Friends;
import me.travis.wurstplus.util.LagCompensator;
import me.travis.wurstplus.util.Wrapper;
import me.zero.alpine.EventBus;
import me.zero.alpine.EventManager;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.FMLLog;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(
   modid = "bruceclient",
   name = "bruceclient",
   version = "r.73b"
)
public class wurstplusMod {
   public static final String MODID = "bruceclient";
   public static final String MODNAME = "bruceclient";
   public static final String MODVER = "r.73b";
   public static final String wurstplus_HIRAGANA = "bruceclient";
   public static final String wurstplus_KATAKANA = "bruceclient";
   public static final String wurstplus_KANJI = "bruceclient";
   public static final String NAME_UNICODE = "Bruce Client";
   public static String lastChat = "";
   private static final String wurstplus_CONFIG_NAME_DEFAULT = "WurstPlusConfig.json";
   public static final Logger log = LogManager.getLogger("WurstPlus");
   public static final EventBus EVENT_BUS = new EventManager();
   @Instance
   private static wurstplusMod INSTANCE;
   public wurstplusGUI guiManager;
   public static final char colour = '§';
   public CommandManager commandManager;
   private Setting guiStateSetting = Settings.custom("gui", new JsonObject(), new Converter() {
      protected JsonObject doForward(JsonObject jsonObject) {
         return jsonObject;
      }

      protected JsonObject doBackward(JsonObject jsonObject) {
         return jsonObject;
      }
   }).buildAndRegister("");

   @EventHandler
   public void preInit(FMLPreInitializationEvent event) {
      FMLLog.log.info("Loading bruceclient...");
      DiscordPresence.start();
   }

   @EventHandler
   public void init(FMLInitializationEvent event) {
      log.info("\n\nInitializing bruceclient r.73b");
      ModuleManager.initialize();
      Stream var10000 = ModuleManager.getModules().stream().filter((module) -> {
         return module.alwaysListening;
      });
      EventBus var10001 = EVENT_BUS;
      var10000.forEach(var10001::subscribe);
      MinecraftForge.EVENT_BUS.register(new ForgeEventProcessor());
      MinecraftForge.EVENT_BUS.register(new Announcer());
      MinecraftForge.EVENT_BUS.register(new MiddleClickFriend());
      LagCompensator.INSTANCE = new LagCompensator();
      Wrapper.init();
      this.guiManager = new wurstplusGUI();
      this.guiManager.initializeGUI();
      this.commandManager = new CommandManager();
      Friends.initFriends();
      SettingsRegister.register("commandPrefix", Command.commandPrefix);
      loadConfiguration();
      log.info("Settings loaded");
      ModuleManager.updateLookup();
      ModuleManager.getModules().stream().filter(Module::isEnabled).forEach(Module::enable);
      log.info("BruceClient initialized!\n");
   }

   @SubscribeEvent
   public void onChatRecieved(ClientChatReceivedEvent event) {
      lastChat = event.getMessage().func_150260_c();
   }

   public static String getConfigName() {
      Path config = Paths.get("WurstPlusLastConfig.txt");
      String WurstPlusConfigName = "WurstPlusConfig.json";

      try {
         BufferedReader reader = Files.newBufferedReader(config);
         Throwable var39 = null;

         try {
            WurstPlusConfigName = reader.readLine();
            if (!isFilenameValid(WurstPlusConfigName)) {
               WurstPlusConfigName = "WurstPlusConfig.json";
            }
         } catch (Throwable var33) {
            var39 = var33;
            throw var33;
         } finally {
            if (reader != null) {
               if (var39 != null) {
                  try {
                     reader.close();
                  } catch (Throwable var32) {
                     var39.addSuppressed(var32);
                  }
               } else {
                  reader.close();
               }
            }

         }
      } catch (NoSuchFileException var37) {
         try {
            BufferedWriter writer = Files.newBufferedWriter(config);
            Throwable var4 = null;

            try {
               writer.write("WurstPlusConfig.json");
            } catch (Throwable var31) {
               var4 = var31;
               throw var31;
            } finally {
               if (writer != null) {
                  if (var4 != null) {
                     try {
                        writer.close();
                     } catch (Throwable var30) {
                        var4.addSuppressed(var30);
                     }
                  } else {
                     writer.close();
                  }
               }

            }
         } catch (IOException var35) {
            var35.printStackTrace();
         }
      } catch (IOException var38) {
         var38.printStackTrace();
      }

      return WurstPlusConfigName;
   }

   public static void loadConfiguration() {
      try {
         loadConfigurationUnsafe();
      } catch (IOException var1) {
         var1.printStackTrace();
      }

   }

   public static void loadConfigurationUnsafe() throws IOException {
      String WurstPlusConfigName = getConfigName();
      Path WurstPlusConfig = Paths.get(WurstPlusConfigName);
      if (Files.exists(WurstPlusConfig, new LinkOption[0])) {
         Configuration.loadConfiguration(WurstPlusConfig);
         JsonObject gui = (JsonObject)INSTANCE.guiStateSetting.getValue();
         Iterator var3 = gui.entrySet().iterator();

         while(var3.hasNext()) {
            Entry entry = (Entry)var3.next();
            Optional optional = INSTANCE.guiManager.getChildren().stream().filter((component) -> {
               return component instanceof Frame;
            }).filter((component) -> {
               return ((Frame)component).getTitle().equals(entry.getKey());
            }).findFirst();
            if (optional.isPresent()) {
               JsonObject object = ((JsonElement)entry.getValue()).getAsJsonObject();
               Frame frame = (Frame)optional.get();
               frame.setX(object.get("x").getAsInt());
               frame.setY(object.get("y").getAsInt());
               Docking docking = Docking.values()[object.get("docking").getAsInt()];
               if (docking.isLeft()) {
                  ContainerHelper.setAlignment(frame, AlignedComponent.Alignment.LEFT);
               } else if (docking.isRight()) {
                  ContainerHelper.setAlignment(frame, AlignedComponent.Alignment.RIGHT);
               } else if (docking.isCenterVertical()) {
                  ContainerHelper.setAlignment(frame, AlignedComponent.Alignment.CENTER);
               }

               frame.setDocking(docking);
               frame.setMinimized(object.get("minimized").getAsBoolean());
               frame.setPinned(object.get("pinned").getAsBoolean());
            } else {
               System.err.println("Found GUI config entry for " + (String)entry.getKey() + ", but found no frame with that name");
            }
         }

         getInstance().getGuiManager().getChildren().stream().filter((component) -> {
            return component instanceof Frame && ((Frame)component).isPinneable() && component.isVisible();
         }).forEach((component) -> {
            component.setOpacity(0.0F);
         });
      }
   }

   public static void saveConfiguration() {
      try {
         saveConfigurationUnsafe();
      } catch (IOException var1) {
         var1.printStackTrace();
      }

   }

   public static void saveConfigurationUnsafe() throws IOException {
      JsonObject object = new JsonObject();
      INSTANCE.guiManager.getChildren().stream().filter((component) -> {
         return component instanceof Frame;
      }).map((component) -> {
         return (Frame)component;
      }).forEach((frame) -> {
         JsonObject frameObject = new JsonObject();
         frameObject.add("x", new JsonPrimitive(frame.getX()));
         frameObject.add("y", new JsonPrimitive(frame.getY()));
         frameObject.add("docking", new JsonPrimitive(Arrays.asList(Docking.values()).indexOf(frame.getDocking())));
         frameObject.add("minimized", new JsonPrimitive(frame.isMinimized()));
         frameObject.add("pinned", new JsonPrimitive(frame.isPinned()));
         object.add(frame.getTitle(), frameObject);
      });
      INSTANCE.guiStateSetting.setValue(object);
      Path outputFile = Paths.get(getConfigName());
      if (!Files.exists(outputFile, new LinkOption[0])) {
         Files.createFile(outputFile);
      }

      Configuration.saveConfiguration(outputFile);
      ModuleManager.getModules().forEach(Module::destroy);
   }

   public static boolean isFilenameValid(String file) {
      File f = new File(file);

      try {
         f.getCanonicalPath();
         return true;
      } catch (IOException var3) {
         return false;
      }
   }

   public static wurstplusMod getInstance() {
      return INSTANCE;
   }

   public wurstplusGUI getGuiManager() {
      return this.guiManager;
   }

   public CommandManager getCommandManager() {
      return this.commandManager;
   }
}
